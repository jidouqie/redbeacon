# RedBeacon_test installer wrapper (Windows).
$ErrorActionPreference = "Stop"
function Pause-OnFailure(){
  if($env:CI -eq "true" -or $env:GITHUB_ACTIONS -eq "true" -or $env:REDBEACON_NO_PAUSE -eq "1"){ return }
  try { Read-Host "Press Enter to close this window" | Out-Null } catch {}
}
trap {
  Write-Host ""
  Write-Host "xx RedBeacon_test installer bootstrap failed. Details:" -ForegroundColor Red
  Write-Host $_.Exception.Message -ForegroundColor Red
  Pause-OnFailure
  exit 1
}
$oss = if($env:REDBEACON_OSS){ $env:REDBEACON_OSS } else { "https://bytestaff-redbeacon.oss-cn-shanghai.aliyuncs.com" }
$previousChannel = [Environment]::GetEnvironmentVariable("REDBEACON_CHANNEL", "Process")
try {
  [Environment]::SetEnvironmentVariable("REDBEACON_CHANNEL", "test", "Process")
  irm "$oss/install.ps1" -TimeoutSec 60 | iex
}
finally {
  [Environment]::SetEnvironmentVariable("REDBEACON_CHANNEL", $previousChannel, "Process")
}
