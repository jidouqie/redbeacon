#!/usr/bin/env python3
"""Fingerprint root-repository files that must match a desktop build marker."""
from __future__ import annotations

import hashlib
from pathlib import Path


ROOT = Path(__file__).resolve().parent.parent
EXACT_FILES = (
    "tools/build_desktop_local.sh",
    "tools/build_channel_skills.py",
    "tools/check_browser_mirrors.py",
    "tools/check_release_contracts.py",
    "tools/gen_latest.py",
    "tools/release.sh",
    "tools/release_source_fingerprint.py",
    "tools/smoke_unix_install_transaction.py",
    "tools/smoke_windows_install_transaction.ps1",
)


def release_files() -> list[Path]:
    files = [ROOT / rel for rel in EXACT_FILES]
    files.extend(sorted((ROOT / "install").glob("install*.ps1")))
    files.extend(sorted((ROOT / "install").glob("install*.sh")))
    files.extend(sorted((ROOT / "install").glob("uninstall*.ps1")))
    files.extend(sorted((ROOT / "install").glob("uninstall*.sh")))
    files.extend(sorted((ROOT / ".claude" / "commands").glob("redbeacon*.md")))
    missing = [path for path in files if not path.is_file()]
    if missing:
        names = ", ".join(str(path.relative_to(ROOT)) for path in missing)
        raise SystemExit(f"missing release source file(s): {names}")
    return sorted(set(files), key=lambda path: path.relative_to(ROOT).as_posix())


def fingerprint() -> str:
    digest = hashlib.sha256()
    for path in release_files():
        rel = path.relative_to(ROOT).as_posix().encode("utf-8")
        data = path.read_bytes()
        digest.update(len(rel).to_bytes(4, "big"))
        digest.update(rel)
        digest.update(len(data).to_bytes(8, "big"))
        digest.update(data)
    return digest.hexdigest()


if __name__ == "__main__":
    print(fingerprint())
