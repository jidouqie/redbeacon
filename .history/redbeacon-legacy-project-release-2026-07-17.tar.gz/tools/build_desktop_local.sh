#!/usr/bin/env bash
# Build macOS arm64 locally and Windows x64 in the SSH-connected Windows VM.
# Both packages come from the same committed CLI source archive. Versioned OSS
# packages are uploaded only after both platform smokes pass; latest*.json is
# still switched separately by tools/release.sh.
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
CLI_ROOT="$ROOT/cli"
CHANNEL="test"
WINDOWS_HOST="${REDBEACON_WINDOWS_BUILD_HOST:-diaojiawang@10.211.55.3}"
OUTPUT_ROOT="${REDBEACON_LOCAL_BUILD_OUTPUT:-$ROOT/dist/local-build}"
UPLOAD=1

usage() {
  cat <<'EOF'
Usage:
  tools/build_desktop_local.sh [--channel test|stable] [--windows-host USER@IP] [--no-upload]

Stable builds require REDBEACON_STABLE_APPROVED=1 after the test build is approved.
EOF
}

while [ "$#" -gt 0 ]; do
  case "$1" in
    --channel)
      CHANNEL="$2"
      shift 2
      ;;
    --windows-host)
      WINDOWS_HOST="$2"
      shift 2
      ;;
    --output-dir)
      OUTPUT_ROOT="$2"
      shift 2
      ;;
    --no-upload)
      UPLOAD=0
      shift
      ;;
    -h|--help)
      usage
      exit 0
      ;;
    *)
      echo "Unknown argument: $1" >&2
      usage >&2
      exit 2
      ;;
  esac
done

case "$CHANNEL" in
  test|testing|beta) CHANNEL="test" ;;
  stable) CHANNEL="stable" ;;
  *) echo "Channel must be stable or test" >&2; exit 2 ;;
esac
if [ "$CHANNEL" = "stable" ] && [ "${REDBEACON_STABLE_APPROVED:-}" != "1" ]; then
  echo "Stable build blocked: publish and approve the test build first." >&2
  echo "Then run with REDBEACON_STABLE_APPROVED=1." >&2
  exit 1
fi

for command_name in git python3 uv ssh scp tar shasum; do
  command -v "$command_name" >/dev/null 2>&1 || {
    echo "Missing local build command: $command_name" >&2
    exit 1
  }
done
if [ "$(uname -s)" != "Darwin" ] || [ "$(uname -m)" != "arm64" ]; then
  echo "The dual-platform orchestrator must run on an Apple Silicon Mac." >&2
  exit 1
fi
if [ ! -d "$CLI_ROOT/.git" ]; then
  echo "CLI repository not found: $CLI_ROOT" >&2
  exit 1
fi
CLI_STATUS="$(git -C "$CLI_ROOT" status --porcelain)"
if [ -n "$CLI_STATUS" ]; then
  echo "CLI worktree must be clean so both platforms receive exactly one committed snapshot:" >&2
  printf '%s\n' "$CLI_STATUS" >&2
  exit 1
fi

cd "$ROOT"
python3 tools/check_release_contracts.py

SSH_OPTIONS=(
  -o BatchMode=yes
  -o ConnectTimeout=10
  -o ServerAliveInterval=30
  -o ServerAliveCountMax=6
)
SCP_OPTIONS=(
  -o BatchMode=yes
  -o ConnectTimeout=10
  -o ServerAliveInterval=30
  -o ServerAliveCountMax=6
)

echo "==> Checking Windows build VM: $WINDOWS_HOST"
ssh "${SSH_OPTIONS[@]}" "$WINDOWS_HOST" 'cmd.exe /d /c "where uv.exe && uv --version"'

WORK="$(mktemp -d)"
trap 'rm -rf "$WORK"' EXIT
CLI_ARCHIVE="$WORK/redbeacon-cli.tar"
RELEASE_ARCHIVE="$WORK/redbeacon-release-source.tar"
MAC_SOURCE="$WORK/mac-source"
mkdir -p "$MAC_SOURCE" "$OUTPUT_ROOT"

git -C "$CLI_ROOT" archive --format=tar HEAD -o "$CLI_ARCHIVE"
tar -xf "$CLI_ARCHIVE" -C "$MAC_SOURCE"
tar -cf "$RELEASE_ARCHIVE" \
  install \
  tools/smoke_windows_install_transaction.ps1

CLI_COMMIT="$(git -C "$CLI_ROOT" rev-parse HEAD)"
ROOT_COMMIT="$(git -C "$ROOT" rev-parse HEAD)"
SOURCE_SHA="$(shasum -a 256 "$CLI_ARCHIVE" | awk '{print $1}')"
RELEASE_SOURCE_SHA="$(python3 tools/release_source_fingerprint.py)"
VERSION="$(python3 -c "import pathlib,re; print(re.search(r'__version__\\s*=\\s*\"([^\"]+)\"', pathlib.Path('$MAC_SOURCE/src/redbeacon/__init__.py').read_text()).group(1))")"
APP_NAME="RedBeacon"
APP_PREFIX="app"
if [ "$CHANNEL" = "test" ]; then
  APP_NAME="RedBeacon_test"
  APP_PREFIX="app/test"
fi
LOCAL_OUT="$OUTPUT_ROOT/$CHANNEL/$VERSION"
mkdir -p "$LOCAL_OUT"

echo "==> Running macOS installer transaction smoke"
python3 tools/smoke_unix_install_transaction.py

echo "==> Building macOS arm64 from CLI commit $CLI_COMMIT"
bash "$MAC_SOURCE/packaging/build_macos_local.sh" \
  --channel "$CHANNEL" \
  --output-dir "$LOCAL_OUT"

echo "==> Sending the identical CLI source snapshot to Windows"
ssh "${SSH_OPTIONS[@]}" "$WINDOWS_HOST" \
  'cmd.exe /d /c "if not exist RedBeaconBuild\incoming mkdir RedBeaconBuild\incoming"'
scp "${SCP_OPTIONS[@]}" "$CLI_ARCHIVE" \
  "${WINDOWS_HOST}:RedBeaconBuild/incoming/redbeacon-cli.tar"
scp "${SCP_OPTIONS[@]}" "$RELEASE_ARCHIVE" \
  "${WINDOWS_HOST}:RedBeaconBuild/incoming/redbeacon-release-source.tar"
scp "${SCP_OPTIONS[@]}" "$MAC_SOURCE/packaging/build_windows_local.ps1" \
  "${WINDOWS_HOST}:RedBeaconBuild/incoming/build_windows_local.ps1"

echo "==> Building Windows x64 inside the Windows 11 ARM64 VM"
ssh "${SSH_OPTIONS[@]}" "$WINDOWS_HOST" \
  "powershell.exe -NoProfile -NonInteractive -ExecutionPolicy Bypass -File RedBeaconBuild\\incoming\\build_windows_local.ps1 -SourceArchive RedBeaconBuild\\incoming\\redbeacon-cli.tar -ReleaseSourceArchive RedBeaconBuild\\incoming\\redbeacon-release-source.tar -Channel $CHANNEL -OutputDir RedBeaconBuild\\out -WorkingRoot RedBeaconBuild"
scp "${SCP_OPTIONS[@]}" \
  "${WINDOWS_HOST}:RedBeaconBuild/out/${APP_NAME}-win-x64.zip" \
  "$LOCAL_OUT/${APP_NAME}-win-x64.zip"

MAC_PACKAGE="$LOCAL_OUT/${APP_NAME}-mac-arm64.zip"
WINDOWS_PACKAGE="$LOCAL_OUT/${APP_NAME}-win-x64.zip"
test -s "$MAC_PACKAGE"
test -s "$WINDOWS_PACKAGE"

if [ "$UPLOAD" -eq 0 ]; then
  echo "==> Local dual-platform build passed; upload intentionally skipped."
  echo "    $MAC_PACKAGE"
  echo "    $WINDOWS_PACKAGE"
  exit 0
fi

OU="${OSSUTIL:-$HOME/.local/bin/ossutil}"
PROFILE="${OSS_PROFILE:-redbeacon-release}"
BUCKET="${OSS_BUCKET:-bytestaff-redbeacon}"
if [ ! -x "$OU" ]; then
  echo "ossutil not found or not executable: $OU" >&2
  exit 1
fi

BUILD_PREFIX="$APP_PREFIX/releases/$VERSION"
echo "==> Uploading immutable dual-platform packages to OSS"
"$OU" cp "$MAC_PACKAGE" \
  "oss://$BUCKET/$BUILD_PREFIX/${APP_NAME}-mac-arm64.zip" \
  --profile "$PROFILE" -f >/dev/null
"$OU" cp "$WINDOWS_PACKAGE" \
  "oss://$BUCKET/$BUILD_PREFIX/${APP_NAME}-win-x64.zip" \
  --profile "$PROFILE" -f >/dev/null

# Parse the single build-version source from the exact snapshot that was built.
# shellcheck disable=SC1090
source "$MAC_SOURCE/packaging/build-versions.env"
MARKER="$LOCAL_OUT/build-complete.json"
python3 - "$MARKER" "$CHANNEL" "$VERSION" "$CLI_COMMIT" "$ROOT_COMMIT" \
  "$SOURCE_SHA" "$RELEASE_SOURCE_SHA" "$UV_VERSION" "$PYTHON_VERSION" <<'PY'
import datetime
import json
import pathlib
import sys

(
    path,
    channel,
    version,
    commit,
    root_commit,
    source_sha,
    release_source_sha,
    uv_version,
    python_version,
) = sys.argv[1:]
payload = {
    "channel": channel,
    "version": version,
    "commit": commit,
    "root_commit": root_commit,
    "builder": "local-dual-host",
    "platforms": ["mac-arm64", "win-x64"],
    "source_sha256": source_sha,
    "release_source_sha256": release_source_sha,
    "uv_version": uv_version,
    "python_version": python_version,
    "created_at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
}
pathlib.Path(path).write_text(
    json.dumps(payload, ensure_ascii=True, separators=(",", ":")) + "\n",
    encoding="utf-8",
)
PY
"$OU" cp "$MARKER" "oss://$BUCKET/$BUILD_PREFIX/build-complete.json" \
  --profile "$PROFILE" -f >/dev/null

echo "==> Dual-platform build complete. Release marker uploaded last."
echo "    channel=$CHANNEL version=$VERSION commit=$CLI_COMMIT"
echo "    packages=$BUILD_PREFIX/{${APP_NAME}-mac-arm64.zip,${APP_NAME}-win-x64.zip}"
