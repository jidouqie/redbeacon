"""Playwright Chromium engine setup with progress callbacks.

The desktop bundle includes Playwright's Python package and node driver, but not
the large Chromium browser binary. Installers prewarm it; the UI can also repair
the missing cache before QR login and show progress instead of a silent timeout.

Readiness is tied to Playwright's exact bundled browser revision. An executable
from an older cache is useful diagnostic information, but it must never satisfy
the current runtime: Playwright refuses to launch a mismatched revision.
"""
from __future__ import annotations

import os
import re
import shutil
import sys
import subprocess
import time
import uuid
from contextlib import contextmanager
from collections.abc import Callable
from pathlib import Path
from typing import Any
from urllib.parse import urlparse

from redbeacon.services.browser_downloads import (
    BrowserDownloadLocalError,
    DownloadSource,
    download_resumable,
    place_cached_archive,
    remove_cached_archive,
)
from redbeacon.utils.logger import get_logger
from redbeacon.utils.paths import default_data_dir

log = get_logger("browser.engine")

# RedBeacon's public Shanghai OSS is the controlled mainland path and must be
# first. Public mirrors and Microsoft's CDN are fallbacks only.
PLAYWRIGHT_OSS_HOST = "https://bytestaff-redbeacon.oss-cn-shanghai.aliyuncs.com/playwright"
PLAYWRIGHT_HOSTS = (
    PLAYWRIGHT_OSS_HOST,
    "https://registry.npmmirror.com/-/binary/playwright",
    "https://cdn.npmmirror.com/binaries/playwright",
    "",
)

CLOAKBROWSER_OSS_HOST = "https://bytestaff-redbeacon.oss-cn-shanghai.aliyuncs.com/cloakbrowser"
CLOAKBROWSER_WINDOWS_ARM64_ALIASES = ("ARM64", "arm64", "AARCH64", "aarch64")

Progress = Callable[[dict[str, Any]], None]


def _emit(progress: Progress | None, *, message: str, percent: int | None = None,
          phase: str = "setup") -> None:
    if progress is None:
        return
    payload: dict[str, Any] = {"phase": phase, "message": message}
    if percent is not None:
        payload["progress"] = max(0, min(100, int(percent)))
    progress(payload)


def _clean_line(line: str, limit: int = 180) -> str:
    text = re.sub(r"\x1b\[[0-9;]*[A-Za-z]", "", line or "")
    text = text.replace("\r", " ").replace("\n", " ")
    text = re.sub(r"\s+", " ", text).strip()
    if len(text) > limit:
        return text[:limit - 1].rstrip() + "…"
    return text


def _channel_root() -> Path:
    data_env = os.environ.get("REDBEACON_DATA_DIR")
    if data_env:
        return Path(data_env).expanduser().resolve().parent
    return default_data_dir().parent


def playwright_cache_dir() -> Path:
    override = os.environ.get("REDBEACON_PLAYWRIGHT_DIR")
    if override:
        return Path(override).expanduser().resolve()
    return (_channel_root() / "browser" / "ms-playwright").resolve()


def cloakbrowser_cache_dir() -> Path:
    override = os.environ.get("REDBEACON_CLOAKBROWSER_DIR")
    if override:
        return Path(override).expanduser().resolve()
    return (_channel_root() / "browser" / "cloakbrowser").resolve()


def _patch_cloakbrowser_platform_aliases() -> None:
    """Let Windows ARM64 machines use the Windows x64 CloakBrowser binary.

    RedBeacon currently ships a Windows x64 desktop bundle. On Windows ARM64 it
    runs through the system x64 emulation layer, but CloakBrowser's platform
    table only recognizes AMD64/x86_64 and raises before it can download the
    x64 browser archive. Mapping ARM64 to windows-x64 keeps installation and QR
    login on the same supported bundle path.
    """
    try:
        from cloakbrowser import config as cb_config
    except Exception:  # noqa: BLE001
        return

    supported = getattr(cb_config, "SUPPORTED_PLATFORMS", None)
    if isinstance(supported, dict):
        for machine in CLOAKBROWSER_WINDOWS_ARM64_ALIASES:
            supported.setdefault(("Windows", machine), "windows-x64")


def configure_runtime_environment(*, cloakbrowser_download_url: str | None = None) -> dict[str, str]:
    """Pin all browser-related caches to RedBeacon-owned channel directories.

    Playwright and CloakBrowser normally use different user-level defaults
    (`ms-playwright` and `~/.cloakbrowser`). On Windows that is fragile because
    PowerShell, Explorer, services, and Codex-like sandboxes may resolve HOME or
    LOCALAPPDATA differently. RedBeacon always prepares and launches from the
    same channel-scoped cache so setup, QR login, publishing, and card rendering
    agree on the exact binary locations.
    """
    _patch_cloakbrowser_platform_aliases()
    pw_dir = str(playwright_cache_dir())
    cb_dir = str(cloakbrowser_cache_dir())
    os.environ["PLAYWRIGHT_BROWSERS_PATH"] = pw_dir
    os.environ["CLOAKBROWSER_CACHE_DIR"] = cb_dir
    os.environ["CLOAKBROWSER_AUTO_UPDATE"] = "false"

    # A previous shell, another automation project, or a corporate bootstrap
    # script may point Playwright at a stale/foreign mirror. Frozen RedBeacon
    # always owns source selection; developers can use the REDBEACON_* override.
    for key in (
        "PLAYWRIGHT_DOWNLOAD_HOST",
        "PLAYWRIGHT_CHROMIUM_DOWNLOAD_HOST",
        "PLAYWRIGHT_DOWNLOAD_CONNECTION_TIMEOUT",
    ):
        os.environ.pop(key, None)

    # These variables can redirect CloakBrowser to unrelated or incompatible
    # binaries. RedBeacon uses REDBEACON_* overrides above instead.
    for key in ("CLOAKBROWSER_BINARY_PATH", "CLOAKBROWSER_VERSION", "CLOAKBROWSER_SKIP_CHECKSUM"):
        os.environ.pop(key, None)
    if cloakbrowser_download_url:
        os.environ["CLOAKBROWSER_DOWNLOAD_URL"] = cloakbrowser_download_url.rstrip("/")
    else:
        os.environ.pop("CLOAKBROWSER_DOWNLOAD_URL", None)

    return {
        "PLAYWRIGHT_BROWSERS_PATH": pw_dir,
        "CLOAKBROWSER_CACHE_DIR": cb_dir,
        "CLOAKBROWSER_AUTO_UPDATE": os.environ["CLOAKBROWSER_AUTO_UPDATE"],
    }


def _runtime_env() -> dict[str, str]:
    configure_runtime_environment()
    env = dict(os.environ)
    env["PLAYWRIGHT_BROWSERS_PATH"] = str(playwright_cache_dir())
    env["CLOAKBROWSER_CACHE_DIR"] = str(cloakbrowser_cache_dir())
    env["CLOAKBROWSER_AUTO_UPDATE"] = "false"
    return env


def runtime_environment() -> dict[str, str]:
    """Return a child-process environment pinned to this RedBeacon channel."""
    return _runtime_env()


def _progress_from_line(line: str) -> int | None:
    match = re.search(r"(\d{1,3})\s*%", line or "")
    if not match:
        return None
    value = int(match.group(1))
    if 0 <= value <= 100:
        return value
    return None


def _cache_roots(expected_executable: str = "") -> list[Path]:
    roots: list[Path] = []
    roots.append(playwright_cache_dir())
    env_root = os.environ.get("PLAYWRIGHT_BROWSERS_PATH")
    if env_root and env_root != "0":
        roots.append(Path(env_root))

    local = os.environ.get("LOCALAPPDATA")
    if local:
        roots.append(Path(local) / "ms-playwright")
    if sys.platform == "darwin":
        roots.append(Path.home() / "Library" / "Caches" / "ms-playwright")
    else:
        roots.append(Path.home() / ".cache" / "ms-playwright")

    if expected_executable:
        p = Path(expected_executable)
        for parent in p.parents:
            if parent.name == "ms-playwright":
                roots.append(parent)
                break

    out: list[Path] = []
    seen: set[str] = set()
    for root in roots:
        key = str(root)
        if key not in seen:
            seen.add(key)
            out.append(root)
    return out


def _browser_patterns() -> tuple[str, ...]:
    if sys.platform == "win32":
        return (
            "chromium-*/**/chrome.exe",
            "chromium_headless_shell-*/**/headless_shell.exe",
        )
    if sys.platform == "darwin":
        return (
            "chromium-*/**/Google Chrome for Testing",
            "chromium-*/**/Chromium",
            "chromium_headless_shell-*/**/headless_shell",
        )
    return (
        "chromium-*/**/chrome",
        "chromium-*/**/chromium",
        "chromium_headless_shell-*/**/headless_shell",
    )


def _find_cached_browser(expected_executable: str = "", roots: list[Path] | None = None) -> str:
    if expected_executable and Path(expected_executable).exists():
        return expected_executable

    for root in roots if roots is not None else _cache_roots(expected_executable):
        if not root.exists():
            continue
        for pattern in _browser_patterns():
            for path in sorted(root.glob(pattern), reverse=True):
                if path.is_file():
                    return str(path)
    return ""


def _verify_playwright_launch(browser_type: Any, executable: str) -> tuple[bool, str]:
    """Launch the exact managed Chromium and execute one offline page operation."""
    browser = None
    try:
        browser = browser_type.launch(headless=True, executable_path=executable)
        page = browser.new_page()
        page.set_content("<html><body><p id='ready'>ready</p></body></html>")
        if page.text_content("#ready") != "ready":
            raise RuntimeError("browser page verification returned unexpected content")
        return True, ""
    except Exception as exc:  # noqa: BLE001
        return False, _clean_line(str(exc), limit=240)
    finally:
        if browser is not None:
            try:
                browser.close()
            except Exception:  # noqa: BLE001
                pass


def playwright_status(*, verify_launch: bool = False) -> dict[str, Any]:
    configure_runtime_environment()
    exe = ""
    try:
        from playwright.sync_api import sync_playwright

        with sync_playwright() as p:
            exe = p.chromium.executable_path
            expected_exists = bool(exe and Path(exe).is_file())
            launch_verified = False
            launch_error = ""
            if expected_exists and verify_launch:
                launch_verified, launch_error = _verify_playwright_launch(p.chromium, exe)

        # Never use an arbitrary chromium-* executable as readiness. Keep the
        # newest mismatched binary only as a diagnostic for stale-cache repairs.
        stale = "" if expected_exists else _find_cached_browser(
            "", roots=[playwright_cache_dir()]
        )
        ok = expected_exists and (launch_verified if verify_launch else True)
        if ok:
            message = "浏览器内核已就绪"
        elif expected_exists:
            message = "当前浏览器内核存在但启动校验失败"
        elif stale:
            message = "检测到旧版浏览器内核，正在准备当前版本"
        else:
            message = "当前版本浏览器内核还没有下载完成"
        return {
            "ok": ok,
            "chromium_executable": exe if expected_exists else "",
            "chromium_expected_executable": exe,
            "chromium_executable_exists": expected_exists,
            "chromium_launch_verified": launch_verified,
            "chromium_launch_error": launch_error,
            "stale_chromium_executable": stale,
            "cache_dir": str(playwright_cache_dir()),
            "message": message,
        }
    except Exception as exc:  # noqa: BLE001
        return {
            "ok": False,
            "chromium_executable": "",
            "chromium_expected_executable": exe,
            "chromium_executable_exists": False,
            "chromium_launch_verified": False,
            "chromium_launch_error": _clean_line(str(exc), limit=240),
            "stale_chromium_executable": "",
            "cache_dir": str(playwright_cache_dir()),
            "message": f"浏览器内核检测失败：{_clean_line(str(exc))}",
        }


def cloakbrowser_status() -> dict[str, Any]:
    configure_runtime_environment()
    try:
        from cloakbrowser.download import binary_info

        info = binary_info()
        exe = str(info.get("binary_path") or "")
        ok = bool(exe and Path(exe).exists())
        return {
            "ok": ok,
            "chromium_executable": exe,
            "chromium_executable_exists": ok,
            "cache_dir": str(cloakbrowser_cache_dir()),
            "platform": info.get("platform"),
            "version": info.get("version"),
            "download_url": info.get("download_url"),
            "message": "小红书自动化浏览器已就绪" if ok else "小红书自动化浏览器还没有下载完成",
        }
    except Exception as exc:  # noqa: BLE001
        return {
            "ok": False,
            "chromium_executable": "",
            "chromium_executable_exists": False,
            "cache_dir": str(cloakbrowser_cache_dir()),
            "message": f"小红书自动化浏览器检测失败：{_clean_line(str(exc))}",
        }


def browser_status() -> dict[str, Any]:
    pw = playwright_status()
    cb = cloakbrowser_status()
    ok = bool(pw.get("ok") and cb.get("ok"))
    return {
        "ok": ok,
        "playwright": pw,
        "cloakbrowser": cb,
        "chromium_executable": pw.get("chromium_executable", ""),
        "chromium_expected_executable": pw.get("chromium_expected_executable", ""),
        "chromium_executable_exists": bool(pw.get("chromium_executable_exists")),
        "cloakbrowser_executable": cb.get("chromium_executable", ""),
        "cloakbrowser_executable_exists": bool(cb.get("chromium_executable_exists")),
        "browser_cache_root": str(_channel_root() / "browser"),
        "message": "自动化浏览器内核已就绪" if ok else "自动化浏览器内核还没有全部准备好",
    }


def _playwright_install_cmd(
    *,
    force: bool = False,
    no_shell: bool = False,
    dry_run: bool = False,
) -> list[str]:
    from playwright._impl._driver import compute_driver_executable

    driver_executable, driver_cli = compute_driver_executable()
    cmd = [driver_executable, driver_cli, "install", "chromium"]
    if no_shell:
        cmd.append("--no-shell")
    if dry_run:
        cmd.append("--dry-run")
    if force:
        cmd.append("--force")
    return cmd


def _hidden_subprocess_kwargs() -> dict[str, int]:
    if sys.platform == "win32":
        return {"creationflags": int(getattr(subprocess, "CREATE_NO_WINDOW", 0))}
    return {}


def _playwright_archive_url(host: str | None) -> str:
    """Ask the bundled Playwright driver for this platform's full Chromium URL."""
    env = _runtime_env()
    env.pop("PLAYWRIGHT_DOWNLOAD_HOST", None)
    env.pop("PLAYWRIGHT_CHROMIUM_DOWNLOAD_HOST", None)
    if host:
        env["PLAYWRIGHT_DOWNLOAD_HOST"] = host.rstrip("/")
    proc = subprocess.run(
        _playwright_install_cmd(no_shell=True, dry_run=True),
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
        env=env,
        timeout=30,
        **_hidden_subprocess_kwargs(),
    )
    if proc.returncode != 0:
        raise RuntimeError(_clean_line(proc.stderr or proc.stdout, limit=300))
    for line in proc.stdout.splitlines():
        match = re.search(r"Download url:\s*(https?://\S+)", line)
        if not match:
            continue
        url = match.group(1)
        if "/builds/cft/" in url and "headless-shell" not in url:
            return url
    raise RuntimeError("Playwright did not report a full Chromium archive URL")


def _playwright_archive_plan() -> tuple[list[DownloadSource], Path, str]:
    override = os.environ.get("REDBEACON_PLAYWRIGHT_DOWNLOAD_URL", "").rstrip("/")
    primary_host = override or PLAYWRIGHT_OSS_HOST
    primary_url = _playwright_archive_url(primary_host)
    primary_path = urlparse(primary_url).path
    host_path = urlparse(primary_host).path.rstrip("/") + "/"
    if not primary_path.startswith(host_path):
        raise RuntimeError(f"Playwright archive is outside configured host: {primary_url}")
    relative = primary_path[len(host_path):].lstrip("/")
    if not relative:
        raise RuntimeError("Playwright archive path is empty")

    sources = [
        DownloadSource(
            primary_url,
            "RedBeacon 上海 OSS（直连）" if not override else "指定下载源（直连）",
        ),
        DownloadSource(
            primary_url,
            "RedBeacon 上海 OSS（系统网络）" if not override else "指定下载源（系统网络）",
            trust_env=True,
        ),
    ]
    if not override:
        for host, label in (
            (PLAYWRIGHT_HOSTS[1], "npmmirror 备用节点 1"),
            (PLAYWRIGHT_HOSTS[2], "npmmirror 备用节点 2"),
        ):
            sources.append(DownloadSource(f"{host}/{relative}", label))
        official_url = _playwright_archive_url(None)
        sources.append(DownloadSource(official_url, "Playwright 官方源", trust_env=True))

    destination = _channel_root() / "browser" / "downloads" / "playwright" / relative
    return sources, destination, relative


def _playwright_browser_directory(expected_executable: str) -> tuple[Path, Path]:
    cache = playwright_cache_dir().resolve()
    expected = Path(expected_executable).resolve()
    try:
        relative = expected.relative_to(cache)
    except ValueError as exc:
        raise RuntimeError(f"Playwright executable is outside channel cache: {expected}") from exc
    if not relative.parts or not relative.parts[0].startswith("chromium-"):
        raise RuntimeError(f"Unexpected Playwright executable path: {expected}")
    browser_dir = cache / relative.parts[0]
    return browser_dir, Path(*relative.parts[1:])


def _replace_directory_with_retry(source: Path, destination: Path) -> None:
    """Rename a prepared runtime directory despite short-lived Windows locks."""
    last_error: OSError | None = None
    for attempt in range(12):
        try:
            os.replace(source, destination)
            return
        except OSError as exc:
            last_error = exc
            if attempt == 11:
                break
            time.sleep(0.25)
    assert last_error is not None
    raise last_error


def _remove_tree_with_retry(path: Path, *, required: bool = True) -> bool:
    """Remove a runtime tree after browser processes release their handles."""
    if not path.exists():
        return True
    last_error: OSError | None = None
    for attempt in range(12):
        try:
            shutil.rmtree(path)
            return True
        except FileNotFoundError:
            return True
        except OSError as exc:
            last_error = exc
            if attempt == 11:
                break
            time.sleep(0.25)
    if required and last_error is not None:
        raise last_error
    return False


def _extract_playwright_archive(archive: Path, expected_executable: str) -> None:
    """Use Playwright's bundled extractor, then atomically place the revision."""
    from playwright._impl._driver import compute_driver_executable
    from playwright.sync_api import sync_playwright

    browser_dir, executable_relative = _playwright_browser_directory(expected_executable)
    transaction_id = f"{os.getpid()}.{uuid.uuid4().hex[:8]}"
    staging = browser_dir.with_name(f".{browser_dir.name}.installing.{transaction_id}")
    backup = browser_dir.with_name(f".{browser_dir.name}.backup.{transaction_id}")

    node, driver_cli = compute_driver_executable()
    core_bundle = Path(driver_cli).parent / "lib" / "coreBundle.js"
    staging_executable = staging / executable_relative
    script = r"""
const fs = require('fs');
const core = require(process.argv[1]);
const archive = process.argv[2];
const target = process.argv[3];
const executable = process.argv[4];
(async () => {
  await core.utils.extractZip(archive, { dir: target });
  if (process.platform !== 'win32') await fs.promises.chmod(executable, 0o755);
  await fs.promises.writeFile(core.registry.browserDirectoryToMarkerFilePath(target), '');
})().catch(error => { console.error(error); process.exit(1); });
"""
    proc = subprocess.run(
        [
            str(node),
            "-e",
            script,
            str(core_bundle),
            str(archive),
            str(staging),
            str(staging_executable),
        ],
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
        timeout=180,
        **_hidden_subprocess_kwargs(),
    )
    if proc.returncode != 0 or not staging_executable.is_file():
        _remove_tree_with_retry(staging, required=False)
        detail = _clean_line(proc.stderr or proc.stdout or "archive extraction failed", limit=300)
        raise RuntimeError(detail)

    old_browser_moved = False
    new_browser_placed = False
    try:
        # Place the new revision before launching it. Windows can retain an
        # executable handle briefly after browser.close(); renaming a directory
        # that has just been launched from it is therefore unreliable.
        if browser_dir.exists():
            _replace_directory_with_retry(browser_dir, backup)
            old_browser_moved = True
        _replace_directory_with_retry(staging, browser_dir)
        new_browser_placed = True

        installed_executable = browser_dir / executable_relative
        with sync_playwright() as playwright:
            verified, error = _verify_playwright_launch(
                playwright.chromium, str(installed_executable)
            )
        if not verified:
            raise RuntimeError(f"downloaded Chromium failed launch verification: {error}")

        if old_browser_moved and not _remove_tree_with_retry(backup, required=False):
            log.warning("Could not remove stale Playwright backup yet: %s", backup)
    except Exception:
        if new_browser_placed:
            _remove_tree_with_retry(browser_dir)
        if old_browser_moved and backup.exists() and not browser_dir.exists():
            _replace_directory_with_retry(backup, browser_dir)
        _remove_tree_with_retry(staging, required=False)
        raise


def _format_download_speed(value: int) -> str:
    if value >= 1024 * 1024:
        return f"{value / (1024 * 1024):.1f} MB/s"
    return f"{value / 1024:.0f} KB/s"


def _map_progress(progress: Progress | None, start: int, span: int) -> Progress | None:
    if progress is None:
        return None

    def _mapped(payload: dict[str, Any]) -> None:
        pct = payload.get("progress")
        mapped = None if pct is None else start + int(int(pct) * span / 100)
        _emit(
            progress,
            message=str(payload.get("message") or ""),
            percent=mapped,
            phase=str(payload.get("phase") or "setup"),
        )

    return _mapped


def _ensure_playwright_engine(progress: Progress | None = None) -> dict[str, Any]:
    configure_runtime_environment()
    status = playwright_status(verify_launch=True)
    if status.get("ok"):
        _emit(progress, message="Playwright 浏览器内核已就绪", percent=100, phase="ready")
        return {
            "ok": True,
            "chromium_installed": True,
            **status,
            "next": "",
        }

    playwright_cache_dir().mkdir(parents=True, exist_ok=True)
    _emit(progress, message="正在准备卡片渲染浏览器内核…", percent=3)
    try:
        sources, archive_path, artifact_key = _playwright_archive_plan()
    except Exception as exc:  # noqa: BLE001
        msg = f"Playwright 下载信息不完整：{_clean_line(str(exc))}"
        _emit(progress, message=msg, percent=100, phase="error")
        return {
            **status,
            "ok": False,
            "chromium_installed": False,
            "last_error": msg,
            "next": "Reinstall RedBeacon so the Playwright driver is included.",
        }

    active_source = ""

    def download_progress(payload: dict[str, Any]) -> None:
        nonlocal active_source
        source = str(payload.get("source") or "下载节点")
        active_source = source
        phase = str(payload.get("phase") or "")
        if phase in {"source_error", "local_error"}:
            _emit(
                progress,
                message=str(payload.get("message") or "下载节点不可用，正在切换…"),
                percent=None,
            )
            return
        if phase == "source":
            _emit(progress, message=str(payload.get("message") or f"正在连接 {source}…"), percent=5)
            return
        if phase == "verify":
            _emit(progress, message="浏览器内核下载完成，正在校验…", percent=88)
            return
        pct = int(payload.get("progress") or 0)
        downloaded = int(payload.get("downloaded") or 0)
        total = int(payload.get("total") or 0)
        speed = _format_download_speed(int(payload.get("speed_bps") or 0))
        _emit(
            progress,
            message=(
                f"{source} 下载中 {pct}% "
                f"({downloaded // (1024 * 1024)}/{max(1, total // (1024 * 1024))} MB，{speed})"
            ),
            percent=5 + int(pct * 80 / 100),
        )

    installed = False
    last_error = ""
    local_failure = False
    try:
        log.info("Preparing Playwright Chromium from RedBeacon OSS with resumable ranges")
        archive = download_resumable(
            sources,
            archive_path,
            artifact_key=artifact_key,
            progress=download_progress,
        )
        _emit(progress, message="正在解压并启动校验浏览器内核…", percent=90)
        _extract_playwright_archive(
            archive,
            str(status.get("chromium_expected_executable") or ""),
        )
        installed = True
    except BrowserDownloadLocalError as exc:
        local_failure = True
        last_error = _clean_line(str(exc), limit=300)
        log.warning(f"Chromium setup stopped by a local storage error: {exc}")
    except Exception as exc:  # noqa: BLE001
        last_error = _clean_line(str(exc), limit=300)
        log.warning(f"Chromium setup failed: {exc}")

    _emit(progress, message="正在校验浏览器内核…", percent=96)
    status = playwright_status(verify_launch=True)
    ok = bool(status.get("ok"))
    if ok:
        remove_cached_archive(archive_path)
        _emit(progress, message="Playwright 浏览器内核已准备好", percent=100, phase="ready")
    else:
        error_message = (
            last_error
            if local_failure
            else "Playwright 浏览器内核准备失败，请检查网络后重试"
        )
        _emit(progress, message=error_message, percent=100, phase="error")
    return {
        **status,
        "ok": ok,
        "chromium_installed": installed,
        "local_failure": local_failure,
        "download_source": active_source,
        "last_error": "" if ok else (status.get("chromium_launch_error") or last_error),
        "next": "" if ok else "Browser engine is incomplete. Re-run: redbeacon setup",
    }


def ensure_playwright_engine(progress: Progress | None = None) -> dict[str, Any]:
    """Ensure and launch-verify the card-rendering browser for this channel."""
    return _ensure_playwright_engine(progress=progress)


@contextmanager
def _cloakbrowser_progress(progress: Progress | None):
    try:
        from cloakbrowser import download as cb_download
    except Exception:  # noqa: BLE001
        yield
        return

    original = cb_download._download_file

    def _download_file(url: str, dest: Path, headers: dict[str, str] | None = None) -> None:
        parsed = urlparse(url)
        relative = parsed.path.lstrip("/") or Path(parsed.path).name
        cache_path = _channel_root() / "browser" / "downloads" / "cloakbrowser" / relative
        is_oss = "bytestaff-redbeacon.oss-cn-shanghai.aliyuncs.com" in parsed.netloc
        label = "RedBeacon 上海 OSS" if is_oss else "CloakBrowser 官方源"

        def on_progress(payload: dict[str, Any]) -> None:
            phase = str(payload.get("phase") or "")
            if phase in {"source", "source_error", "local_error", "verify"}:
                _emit(progress, message=str(payload.get("message") or ""), percent=None)
                return
            pct = int(payload.get("progress") or 0)
            downloaded = int(payload.get("downloaded") or 0)
            total = int(payload.get("total") or 0)
            speed = _format_download_speed(int(payload.get("speed_bps") or 0))
            _emit(
                progress,
                message=(
                    f"小红书自动化浏览器下载中 {pct}% "
                    f"({downloaded // (1024 * 1024)}/{max(1, total // (1024 * 1024))} MB，{speed})"
                ),
                percent=5 + int(pct * 75 / 100),
            )

        archive = download_resumable(
            [
                DownloadSource(url, f"{label}（直连）"),
                DownloadSource(url, f"{label}（系统网络）", trust_env=True),
            ],
            cache_path,
            artifact_key=relative,
            headers=headers,
            progress=on_progress,
        )
        place_cached_archive(archive, dest)
        remove_cached_archive(archive)
        _emit(progress, message="正在解压小红书自动化浏览器…", percent=88)

    cb_download._download_file = _download_file
    try:
        yield
    finally:
        cb_download._download_file = original


def _ensure_cloakbrowser_engine(progress: Progress | None = None) -> dict[str, Any]:
    configure_runtime_environment()
    status = cloakbrowser_status()
    if status.get("ok"):
        _emit(progress, message="小红书自动化浏览器已就绪", percent=100, phase="ready")
        return {"ok": True, "cloakbrowser_installed": True, **status, "next": ""}

    cloakbrowser_cache_dir().mkdir(parents=True, exist_ok=True)
    _emit(progress, message="正在准备小红书自动化浏览器…", percent=3)

    preset = os.environ.get("REDBEACON_CLOAKBROWSER_DOWNLOAD_URL")
    sources: list[str] = []
    if preset:
        sources.append(preset.rstrip("/"))
    # Try our China OSS mirror directly. A separate HEAD preflight used to
    # time out occasionally even when the object was healthy, which silently
    # sent users to the much slower GitHub redirect path.
    if CLOAKBROWSER_OSS_HOST not in sources:
        sources.append(CLOAKBROWSER_OSS_HOST)
    sources.append("")

    last_error = ""
    local_failure = False
    for idx, source in enumerate(sources, start=1):
        source_name = source or "官方源"
        _emit(progress, message=f"正在从 {source_name} 准备小红书自动化浏览器…", percent=5 + idx * 5)
        configure_runtime_environment(cloakbrowser_download_url=source or None)
        cb_download = None
        cb_config = None
        original_base_url = ""
        original_config_base_url = ""
        try:
            from cloakbrowser import config as cb_config
            from cloakbrowser import download as cb_download

            # CloakBrowser imports get_download_url() from config.py. Patching
            # download.DOWNLOAD_BASE_URL alone looks correct in diagnostics but
            # leaves the actual request on the official URL, because the
            # function resolves config.DOWNLOAD_BASE_URL in its own module.
            # Patch both modules so OSS-first is the real wire behavior.
            original_base_url = cb_download.DOWNLOAD_BASE_URL
            original_config_base_url = cb_config.DOWNLOAD_BASE_URL
            if source:
                cb_download.DOWNLOAD_BASE_URL = source
                cb_config.DOWNLOAD_BASE_URL = source
            with _cloakbrowser_progress(progress):
                binary = cb_download.ensure_binary()
            configure_runtime_environment()
            status = cloakbrowser_status()
            if binary and status.get("ok"):
                _emit(progress, message="小红书自动化浏览器已准备好", percent=100, phase="ready")
                return {
                    "ok": True,
                    "cloakbrowser_installed": True,
                    **status,
                    "last_error": "",
                    "next": "",
                }
        except BrowserDownloadLocalError as exc:
            local_failure = True
            last_error = _clean_line(str(exc))
            log.warning(f"CloakBrowser setup stopped by a local storage error: {exc}")
            break
        except Exception as exc:  # noqa: BLE001
            last_error = _clean_line(str(exc))
            log.warning(f"CloakBrowser setup failed from {source_name}: {exc}")
            continue
        finally:
            if cb_download is not None and original_base_url:
                cb_download.DOWNLOAD_BASE_URL = original_base_url
            if cb_config is not None and original_config_base_url:
                cb_config.DOWNLOAD_BASE_URL = original_config_base_url

    configure_runtime_environment()
    status = cloakbrowser_status()
    error_message = (
        last_error
        if local_failure
        else "小红书自动化浏览器准备失败，请检查网络后重试"
    )
    _emit(progress, message=error_message, percent=100, phase="error")
    return {
        **status,
        "ok": False,
        "cloakbrowser_installed": False,
        "local_failure": local_failure,
        "last_error": last_error,
        "next": "" if status.get("ok") else "Browser engine is incomplete. Re-run: redbeacon setup",
    }


def ensure_browser_engine(
    progress: Progress | None = None,
    *,
    verify_launch: bool = False,
) -> dict[str, Any]:
    status = browser_status()
    if status.get("ok") and not verify_launch:
        _emit(progress, message="自动化浏览器内核已就绪", percent=100, phase="ready")
        return {"ok": True, "chromium_installed": True, "cloakbrowser_installed": True, **status, "next": ""}

    _emit(progress, message="开始准备 RedBeacon 自动化浏览器内核…", percent=1)
    pw = _ensure_playwright_engine(progress=_map_progress(progress, 0, 45))
    if pw.get("local_failure"):
        cb_status = cloakbrowser_status()
        cb = {
            **cb_status,
            "ok": False,
            "cloakbrowser_installed": bool(cb_status.get("ok")),
            "local_failure": True,
            "last_error": pw.get("last_error") or "",
            "next": "",
        }
    else:
        cb = _ensure_cloakbrowser_engine(progress=_map_progress(progress, 45, 55))
    final_status = browser_status()
    ok = bool(pw.get("ok") and cb.get("ok") and final_status.get("ok"))
    last_error = cb.get("last_error") or pw.get("last_error") or ""
    local_failure = bool(pw.get("local_failure") or cb.get("local_failure"))
    if ok:
        _emit(progress, message="自动化浏览器内核已全部准备好", percent=100, phase="ready")
    else:
        error_message = (
            str(last_error)
            if local_failure and last_error
            else "自动化浏览器内核准备失败，请检查网络后重试"
        )
        _emit(progress, message=error_message, percent=100, phase="error")
    return {
        **final_status,
        "ok": ok,
        "chromium_installed": bool(pw.get("ok")),
        "cloakbrowser_installed": bool(cb.get("ok")),
        "playwright": pw,
        "cloakbrowser": cb,
        "last_error": last_error,
        "next": "" if ok else "Browser engine is incomplete. Re-run: redbeacon setup",
    }
