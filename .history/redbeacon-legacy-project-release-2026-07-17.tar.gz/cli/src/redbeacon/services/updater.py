"""升级服务：版本检查 + 客户端整包替换 + skill 刷新 + 兼容 wheel 自升级。

分发架构（见 memory oss-release-pipeline）：唯一分发源 = 阿里云 OSS，零 GitHub/官网依赖。
  - PyInstaller 自包含客户端走 OSS app/RedBeacon-<plat>.zip；
    测试版走 app/test/RedBeacon_test-<plat>.zip。
  - 安装 / 更新统一执行 OSS install 脚本：脚本先拉 manifest 判断版本，
    旧版才下载整包覆盖；最新版只刷新浏览器内核和 skill，跳过大包下载。
  - skill 走 OSS 版本化 skill tarball，由 install 脚本校验 SHA 后事务式刷新
    AI 助手命令目录和 Codex SKILL.md；不得让新客户端配到旧 skill，反之亦然。
  - latest.json / latest-test.json 也托管在 OSS 当版本清单（单一事实源），形如：
      {
        "version": "0.2.0",
        "notes": "本次更新说明（人话，给用户看）",
        "skill_version": "0.2.0",
        "skill_bundle_url": "https://bytestaff-redbeacon.oss-cn-shanghai.aliyuncs.com/skill/releases/0.2.0/redbeacon-skill.tar.gz",
        "skill_sha256": "...",
        "skill_raw_base": "https://bytestaff-redbeacon.oss-cn-shanghai.aliyuncs.com/skill/releases/0.2.0/commands",
        "skill_files": ["redbeacon.md", "redbeacon-accounts.md", ...]
      }

设计要点：
  - 所有联网都**有超时、失败静默**：拉不到清单绝不能卡住正常使用，最多就是"查不到新版"。
  - readiness 走**缓存优先 + 每日一次紧超时刷新**，不在热路径上做阻塞网络调用。
  - Windows 上客户端不能可靠覆盖正在运行的 exe，所以 update 入口只唤起
    独立 PowerShell 安装脚本窗口并让当前客户端退出；脚本负责停旧进程和覆盖目录。
  - 所有 update 入口都执行同一套全量更新：客户端整包、CLI 命令入口、skill、
    Playwright 浏览器内核。开发态也走安装脚本，等同于补装客户端。
"""
from __future__ import annotations

import json
import os
import platform
import hashlib
import shutil
import subprocess
import sys
import time
import zipfile
from pathlib import Path
from typing import Callable, Optional

import httpx

from redbeacon import __version__
from redbeacon import build_meta
from redbeacon import config as cfg
from redbeacon.config_keys import CK_UPDATE_MANIFEST_URL, CK_SKILL_INSTALL_DIR
from redbeacon.utils.logger import get_logger
from redbeacon.utils.paths import default_data_dir

log = get_logger("service.updater")

_CACHE_TTL = 24 * 3600          # readiness 自动刷新间隔：24h
_CACHE_NAME = "update_check.json"
_LIVE_TIMEOUT = 6.0             # 用户主动 update --check 的超时
_BG_TIMEOUT = 2.5              # readiness 后台刷新的紧超时（不拖慢热路径）
_BUNDLE_TIMEOUT = 600.0
_OSS_BASE = "https://bytestaff-redbeacon.oss-cn-shanghai.aliyuncs.com"


def _app_filename(plat: str) -> str:
    return f"{build_meta.app_name()}-{plat}.zip"


def _app_prefix() -> str:
    return "app/test" if build_meta.is_test() else "app"


# ── 版本号比较 ──────────────────────────────────────────────────────────────

def _parse_ver(s: str) -> tuple:
    """宽松解析 'a.b.c' → (a, b, c)；非数字段按 0，缺段补 0。"""
    parts = (s or "").strip().lstrip("vV").split(".")
    out = []
    for p in parts[:3]:
        num = "".join(ch for ch in p if ch.isdigit())
        out.append(int(num) if num else 0)
    while len(out) < 3:
        out.append(0)
    return tuple(out)


def is_newer(latest: str, current: str) -> bool:
    return _parse_ver(latest) > _parse_ver(current)


# ── 清单获取 ────────────────────────────────────────────────────────────────

def _manifest_url() -> str:
    # 环境变量优先（测试 / 临时切源用）。持久化配置里若残留早期 GitHub raw 源，
    # 自动回落到 OSS，避免旧机器被废弃分发通道带偏。
    if os.environ.get("REDBEACON_UPDATE_URL"):
        return os.environ["REDBEACON_UPDATE_URL"]
    try:
        configured = (cfg.get(CK_UPDATE_MANIFEST_URL) or "").strip()
    except Exception:
        configured = ""
    stable_default = "https://bytestaff-redbeacon.oss-cn-shanghai.aliyuncs.com/latest.json"
    if configured and "githubusercontent.com/jidouqie/redbeacon" not in configured and not (
        build_meta.is_test() and configured == stable_default
    ):
        return configured
    return build_meta.update_manifest_url()


def fetch_manifest(timeout: float = _LIVE_TIMEOUT) -> Optional[dict]:
    """拉版本清单。任何异常都返回 None（失败静默，绝不抛给上层）。"""
    url = _manifest_url()
    try:
        r = httpx.get(url, timeout=timeout, follow_redirects=True)
        r.raise_for_status()
        data = r.json()
        if isinstance(data, dict) and data.get("version"):
            return data
        log.warning("版本清单格式异常：%s", url)
    except Exception as e:
        log.info("拉取版本清单失败（静默忽略）：%s", e)
    return None


def _distribution_base() -> str:
    if os.environ.get("REDBEACON_OSS"):
        return os.environ["REDBEACON_OSS"].rstrip("/")
    url = _manifest_url()
    for manifest_name in ("/latest-test.json", "/latest.json"):
        if url.endswith(manifest_name):
            return url[:-len(manifest_name)].rstrip("/")
    return _OSS_BASE


# ── PyInstaller 客户端整包升级 ─────────────────────────────────────────────

def is_frozen_app() -> bool:
    return bool(getattr(sys, "frozen", False))


def bundle_platform() -> Optional[str]:
    if sys.platform == "win32":
        return "win-x64"
    if sys.platform == "darwin":
        machine = platform.machine().lower()
        return "mac-arm64" if machine in ("arm64", "aarch64") else None
    # Linux and Intel macOS distribution are currently paused. Keep the
    # implementation code available for future work, but do not offer a stale
    # bundle or updater path until native builds and smokes are restored.
    return None


def _manifest_app_entry(manifest: Optional[dict], plat: str) -> dict:
    if not isinstance(manifest, dict):
        return {}
    app = manifest.get("app") or {}
    if isinstance(app, dict):
        entry = app.get(plat) or {}
        if isinstance(entry, dict):
            return entry
    return {}


def _expected_bundle_sha(manifest: Optional[dict], plat: Optional[str] = None) -> str:
    plat = plat or bundle_platform()
    if not plat or not isinstance(manifest, dict):
        return ""
    entry = _manifest_app_entry(manifest, plat)
    sha = entry.get("sha256") or ""
    hashes = manifest.get("app_sha256") or {}
    if not sha and isinstance(hashes, dict):
        sha = hashes.get(plat) or ""
    sha = str(sha).strip().lower()
    return sha if len(sha) == 64 and all(c in "0123456789abcdef" for c in sha) else ""


def _verify_sha256(path: Path, expected: str) -> None:
    expected = (expected or "").strip().lower()
    if not expected:
        return
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    actual = h.hexdigest()
    if actual != expected:
        raise RuntimeError("客户端包校验失败：下载内容与版本清单不一致，请稍后重试")


def bundle_url(manifest: Optional[dict] = None) -> Optional[str]:
    plat = bundle_platform()
    if not plat:
        return None
    entry = _manifest_app_entry(manifest, plat)
    if entry.get("url"):
        return str(entry["url"])
    return f"{_distribution_base()}/{_app_prefix()}/{_app_filename(plat)}"


def frozen_install_root() -> Optional[Path]:
    """Return the installed app directory that should be replaced as a unit."""
    if not is_frozen_app():
        return None
    exe = Path(sys.executable).resolve()
    if sys.platform == "darwin":
        for p in (exe, *exe.parents):
            if p.suffix == ".app":
                return p
        return None
    return exe.parent


def installed_bundle_root() -> Optional[Path]:
    """Locate the installed desktop bundle even when update is invoked from CLI/uv.

    A bundled `redbeacon-cli` reports `sys.frozen=True`, but users can also run a
    wheel/uv command while the desktop client is installed. Update must still
    replace that desktop client so every entry point has the same "full update"
    semantics.
    """
    frozen_root = frozen_install_root()
    if frozen_root is not None:
        return frozen_root

    override = os.environ.get("REDBEACON_INSTALL_ROOT")
    if override:
        p = Path(os.path.expanduser(override))
        return p if p.exists() else None

    home = Path(os.path.expanduser("~"))
    app_name = build_meta.app_name()
    cli_name = build_meta.cli_exe_name()
    if sys.platform == "darwin":
        p = home / "Applications" / f"{app_name}.app"
        return p if (p / "Contents" / "MacOS" / cli_name).exists() else None
    if sys.platform == "win32":
        base = os.environ.get("LOCALAPPDATA")
        if not base:
            return None
        p = Path(base) / "Programs" / app_name
        return p if (p / f"{cli_name}.exe").exists() else None
    if sys.platform.startswith("linux"):
        p = home / ".local" / "share" / build_meta.command_name() / app_name
        return p if (p / cli_name).exists() else None
    return None


def supports_bundle_update() -> bool:
    return bundle_platform() is not None and installer_url() is not None


def installer_url() -> Optional[str]:
    """Return the one-click installer URL for the current release channel."""
    if bundle_platform() is None:
        return None
    name = "install-test.ps1" if build_meta.is_test() and sys.platform == "win32" else ""
    if not name:
        if sys.platform == "win32":
            name = "install.ps1"
        else:
            name = "install-test.sh" if build_meta.is_test() else "install.sh"
    return f"{_distribution_base()}/{name}"


def _installer_command(url: str) -> list[str]:
    if sys.platform == "win32":
        command = f"irm {ps_quote(url)} | iex"
        return ["powershell.exe", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", command]
    return ["/bin/sh", "-lc", f"curl -fsSL {shlex_quote(url)} | bash"]


def _spawn_installer(url: str) -> None:
    env = os.environ.copy()
    if build_meta.is_test():
        env["REDBEACON_CHANNEL"] = "test"
    safe_cwd = os.path.expanduser("~")
    if sys.platform == "win32":
        flags = 0
        if hasattr(subprocess, "CREATE_NEW_CONSOLE"):
            flags |= subprocess.CREATE_NEW_CONSOLE
        subprocess.Popen(_installer_command(url), cwd=safe_cwd, env=env, creationflags=flags)
        return

    shell_command = (
        f"curl -fsSL --connect-timeout 10 --max-time 60 {shlex_quote(url)} | bash; "
        "rc=$?; printf '\\n'; "
        "if [ $rc -eq 0 ]; then echo 'RedBeacon update completed.'; "
        "else echo 'RedBeacon update failed. Please keep this window and retry the install command.'; fi; "
        "printf 'Press Enter to close...'; read _; exit $rc"
    )
    if sys.platform == "darwin" and shutil.which("osascript"):
        script = f'tell application "Terminal" to do script {json.dumps(shell_command)}'
        subprocess.Popen(["osascript", "-e", script], cwd=safe_cwd, env=env, start_new_session=True)
        return

    terminal_commands = (
        ("x-terminal-emulator", ["x-terminal-emulator", "-e", "sh", "-lc", shell_command]),
        ("gnome-terminal", ["gnome-terminal", "--", "sh", "-lc", shell_command]),
        ("konsole", ["konsole", "-e", "sh", "-lc", shell_command]),
    )
    for executable, command in terminal_commands:
        if shutil.which(executable):
            subprocess.Popen(command, cwd=safe_cwd, env=env, start_new_session=True)
            return

    # Minimal Linux environments may have no terminal emulator. Keep update
    # functional there, while logs remain available to the calling CLI.
    subprocess.Popen(
        _installer_command(url),
        stdin=subprocess.DEVNULL,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        cwd=safe_cwd,
        env=env,
        start_new_session=True,
    )


def launch_installer_update(progress: Optional[ProgressCallback] = None) -> dict:
    """Start the channel installer. The installer owns version skip/replace logic."""
    url = installer_url()
    if not url:
        return {"ok": False, "skipped": True, "reason": f"暂不支持当前平台：{sys.platform}"}
    _emit(progress, step="installer", message="正在启动安装更新脚本…", percent=8)
    _spawn_installer(url)
    return {
        "ok": True,
        "scheduled": True,
        "restart_required": True,
        "installer_url": url,
        "message": (
            "已在独立更新窗口启动当前通道的安装脚本。脚本会先判断本机版本；"
            "旧版会关闭 RedBeacon 并覆盖安装，最新版会跳过大包下载。"
        ),
    }


ProgressCallback = Callable[[dict], None]


def _emit(progress: Optional[ProgressCallback], **payload) -> None:
    if progress is None:
        return
    try:
        progress(payload)
    except Exception:
        pass


def _download_file(
    url: str,
    dest: Path,
    timeout: float = _BUNDLE_TIMEOUT,
    progress: Optional[ProgressCallback] = None,
) -> None:
    with httpx.stream("GET", url, timeout=timeout, follow_redirects=True) as resp:
        resp.raise_for_status()
        total = int(resp.headers.get("content-length") or 0)
        done = 0
        with dest.open("wb") as f:
            for chunk in resp.iter_bytes():
                if chunk:
                    f.write(chunk)
                    done += len(chunk)
                    if total:
                        _emit(progress, step="download", message="正在下载客户端包…", downloaded=done, total=total,
                              percent=max(1, min(95, int(done * 100 / total))))
        _emit(progress, step="download", message="客户端包下载完成", downloaded=done, total=total, percent=95)


def _stage_bundle(zip_path: Path, stage_dir: Path) -> Path:
    extract_dir = stage_dir / "extract"
    extract_dir.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(zip_path) as zf:
        zf.extractall(extract_dir)
    expected = f"{build_meta.app_name()}.app" if sys.platform == "darwin" else build_meta.app_name()
    staged = extract_dir / expected
    if not staged.exists():
        matches = list(extract_dir.glob("RedBeacon*"))
        if len(matches) == 1:
            staged = matches[0]
    if not staged.exists():
        raise RuntimeError(f"客户端包格式不对：未找到 {expected}")
    return staged


def _write_posix_updater(script: Path, *, pid: int, staged: Path, dest: Path, work: Path) -> None:
    is_linux = sys.platform.startswith("linux")
    is_macos = sys.platform == "darwin"
    desktop_block = ""
    if is_linux:
        desktop = Path(os.path.expanduser("~")) / f".local/share/applications/{build_meta.command_name()}.desktop"
        icon = dest / "_internal/assets/RedBeacon.png"
        app_name = build_meta.app_name()
        exe_name = build_meta.app_name()
        desktop_block = f"""
mkdir -p {shlex_quote(str(desktop.parent))}
cat > {shlex_quote(str(desktop))} <<'EOF'
[Desktop Entry]
Type=Application
Name={app_name}
Comment=Xiaohongshu operations digital worker
Exec={dest}/{exe_name}
Icon={icon}
Terminal=false
Categories=Office;Utility;
EOF
chmod +x {shlex_quote(str(desktop))} 2>/dev/null || true
"""
    macos_block = ""
    if is_macos:
        macos_block = """
touch "$dst" "$dst/Contents" "$dst/Contents/Info.plist" 2>/dev/null || true
lsreg="/System/Library/Frameworks/CoreServices.framework/Frameworks/LaunchServices.framework/Support/lsregister"
if [ -x "$lsreg" ]; then
  "$lsreg" -u "$dst" >/dev/null 2>&1 || true
  "$lsreg" -f "$dst" >/dev/null 2>&1 || true
fi
if command -v qlmanage >/dev/null 2>&1; then qlmanage -r cache >/dev/null 2>&1 || true; fi
killall Dock >/dev/null 2>&1 || true
"""
    script.write_text(f"""#!/bin/sh
set -eu
pid={pid}
src={shlex_quote(str(staged))}
dst={shlex_quote(str(dest))}
work={shlex_quote(str(work))}
bak="${{dst}}.previous-update"
while kill -0 "$pid" 2>/dev/null; do sleep 0.3; done
if command -v pgrep >/dev/null 2>&1; then
  if pgrep -f "$dst" >/dev/null 2>&1; then
    pkill -TERM -f "$dst" 2>/dev/null || true
    i=0
    while pgrep -f "$dst" >/dev/null 2>&1 && [ "$i" -lt 20 ]; do i=$((i+1)); sleep 0.5; done
    if pgrep -f "$dst" >/dev/null 2>&1; then pkill -KILL -f "$dst" 2>/dev/null || true; fi
  fi
fi
rm -rf "$bak"
if [ -e "$dst" ]; then mv "$dst" "$bak"; fi
mv "$src" "$dst"
if command -v xattr >/dev/null 2>&1; then xattr -dr com.apple.quarantine "$dst" 2>/dev/null || true; fi
{macos_block}
rm -rf "$bak"
{desktop_block}
(sleep 1; rm -rf "$work") >/dev/null 2>&1 &
""", encoding="utf-8")
    script.chmod(0o755)


def _write_windows_updater(script: Path, *, pid: int, staged: Path, dest: Path, work: Path) -> None:
    app_proc = build_meta.app_name()
    cli_proc = build_meta.cli_exe_name()
    script.write_text(f"""$ErrorActionPreference = "Stop"
$pidToWait = {pid}
$src = {ps_quote(str(staged))}
$dst = {ps_quote(str(dest))}
$work = {ps_quote(str(work))}
$bak = "$dst.previous-update"
try {{ Wait-Process -Id $pidToWait -ErrorAction SilentlyContinue }} catch {{}}
Start-Sleep -Milliseconds 600
$running = @(Get-Process -Name {app_proc},{cli_proc} -ErrorAction SilentlyContinue | Where-Object {{ $_.Id -ne $PID }})
if($running.Count -gt 0){{
  $running | Stop-Process -ErrorAction SilentlyContinue
  Start-Sleep -Milliseconds 1200
  $running = @(Get-Process -Name {app_proc},{cli_proc} -ErrorAction SilentlyContinue | Where-Object {{ $_.Id -ne $PID }})
  if($running.Count -gt 0){{ $running | Stop-Process -Force -ErrorAction SilentlyContinue }}
}}
Remove-Item -Recurse -Force $bak -ErrorAction SilentlyContinue
if(Test-Path $dst){{ Move-Item -Force $dst $bak }}
Move-Item -Force $src $dst
Remove-Item -Recurse -Force $bak -ErrorAction SilentlyContinue
Start-Sleep -Seconds 1
Remove-Item -Recurse -Force $work -ErrorAction SilentlyContinue
""", encoding="utf-8")


def shlex_quote(s: str) -> str:
    return "'" + s.replace("'", "'\"'\"'") + "'"


def ps_quote(s: str) -> str:
    return "'" + s.replace("'", "''") + "'"


def _spawn_replacer(script: Path) -> None:
    safe_cwd = os.path.expanduser("~")
    if sys.platform == "win32":
        flags = 0
        if hasattr(subprocess, "CREATE_NEW_PROCESS_GROUP"):
            flags |= subprocess.CREATE_NEW_PROCESS_GROUP
        if hasattr(subprocess, "DETACHED_PROCESS"):
            flags |= subprocess.DETACHED_PROCESS
        subprocess.Popen(
            ["powershell.exe", "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", str(script)],
            stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
            cwd=safe_cwd,
            creationflags=flags,
        )
    else:
        subprocess.Popen(
            ["/bin/sh", str(script)],
            stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
            cwd=safe_cwd,
            start_new_session=True,
        )


def schedule_bundle_replace(
    timeout: float = _BUNDLE_TIMEOUT,
    progress: Optional[ProgressCallback] = None,
    manifest: Optional[dict] = None,
) -> dict:
    """Download the current platform bundle and schedule whole-client replacement."""
    root = installed_bundle_root()
    plat = bundle_platform()
    url = bundle_url(manifest)
    if root is None:
        return {"ok": False, "skipped": True, "reason": f"未找到已安装的 {build_meta.app_name()} 客户端，跳过整包替换。"}
    if not url:
        return {"ok": False, "skipped": True, "reason": f"暂不支持当前平台：{sys.platform}"}

    work = Path(os.environ.get("REDBEACON_UPDATE_WORKDIR", str(default_data_dir() / "updates")))
    work = work / f"bundle-{int(time.time())}-{os.getpid()}"
    work.mkdir(parents=True, exist_ok=True)
    zip_path = work / f"{build_meta.app_name()}.zip"
    _emit(progress, step="download", message="准备下载客户端包…", percent=5)
    _download_file(url, zip_path, timeout=timeout, progress=progress)
    _emit(progress, step="verify", message="正在校验客户端包…", percent=95)
    _verify_sha256(zip_path, _expected_bundle_sha(manifest, plat))
    _emit(progress, step="extract", message="正在解压客户端包…", percent=96)
    staged = _stage_bundle(zip_path, work)

    script = work / ("replace.ps1" if sys.platform == "win32" else "replace.sh")
    if sys.platform == "win32":
        _write_windows_updater(script, pid=os.getpid(), staged=staged, dest=root, work=work)
    else:
        _write_posix_updater(script, pid=os.getpid(), staged=staged, dest=root, work=work)
    _emit(progress, step="schedule", message="正在准备替换程序…", percent=98)
    _spawn_replacer(script)
    return {
        "ok": True,
        "scheduled": True,
        "url": url,
        "install_root": str(root),
        "staging_dir": str(work),
        "restart_required": True,
        "message": f"客户端包已下载。{build_meta.app_name()} 将自动关闭并替换整个客户端；替换完成后重新打开即可。",
    }


# ── 检查结果缓存 ────────────────────────────────────────────────────────────

def _cache_path() -> Path:
    base = Path(os.environ.get("REDBEACON_DATA_DIR", str(default_data_dir())))
    return base / _CACHE_NAME


def _write_cache(result: dict) -> None:
    try:
        p = _cache_path()
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(json.dumps(result, ensure_ascii=False), encoding="utf-8")
    except Exception as e:
        log.info("写升级缓存失败（忽略）：%s", e)


def _read_cache() -> Optional[dict]:
    try:
        return json.loads(_cache_path().read_text(encoding="utf-8"))
    except Exception:
        return None


def _result_from_manifest(manifest: dict) -> dict:
    latest = str(manifest.get("version", "")).strip()
    return {
        "current": __version__,
        "latest": latest,
        "update_available": bool(latest) and is_newer(latest, __version__),
        "notes": manifest.get("notes", ""),
        "checked_at": int(time.time()),
    }


def check(timeout: float = _LIVE_TIMEOUT) -> dict:
    """主动检查（用户触发）。联网拉清单 → 比对 → 写缓存 → 返回结果。

    联网失败时返回 `available=None` 语义：current 已知，latest 为空，error 说明。
    """
    manifest = fetch_manifest(timeout=timeout)
    if manifest is None:
        return {
            "current": __version__,
            "latest": "",
            "update_available": False,
            "notes": "",
            "checked_at": int(time.time()),
            "error": "查不到版本信息（网络不通或版本源暂不可用），稍后再试即可，不影响使用。",
        }
    result = _result_from_manifest(manifest)
    _write_cache(result)
    return result


def readiness_update_info() -> Optional[dict]:
    """供 readiness 用：缓存优先，缓存过期则做一次紧超时刷新；全程不抛异常。

    返回精简字段 {update_available, latest, notes} 或 None（无任何可用信息时）。
    """
    cached = _read_cache()
    fresh = bool(cached) and (time.time() - cached.get("checked_at", 0) < _CACHE_TTL)
    if not fresh:
        manifest = fetch_manifest(timeout=_BG_TIMEOUT)
        if manifest is not None:
            cached = _result_from_manifest(manifest)
            _write_cache(cached)
    if not cached:
        return None
    return {
        "update_available": bool(cached.get("update_available")),
        "latest": cached.get("latest", ""),
        "notes": cached.get("notes", ""),
    }


# ── skill 刷新 ──────────────────────────────────────────────────────────────

def find_skill_dir() -> Optional[Path]:
    """定位 skill 命令目录：配置优先（install.sh 写入），否则探测 ~/.claude/commands。"""
    configured = cfg.get(CK_SKILL_INSTALL_DIR).strip()
    if configured:
        return Path(os.path.expanduser(configured))
    dirname = "commands-redbeacon-test" if build_meta.is_test() else "commands"
    guess = Path(os.path.expanduser("~")) / ".claude" / dirname
    return guess if guess.exists() else None


# ── Codex 端桥接（双宿主一致）────────────────────────────────────────────────
# 旧 Claude-style 命令目录用 .claude/commands/<name>.md（单文件斜杠命令）；Codex 用
# ~/.codex/skills/<name>/SKILL.md（文件夹式）。正文 harness 无关、可直接复用，只需转 frontmatter。
# skill 名两端已统一为英文（locate/strategy/diagnose/topics/panel 等），无需别名 → 派生即恒等。
# 真源始终是 .claude/commands 的 markdown；这里只从真源派生 Codex bridge。
# （保留映射结构以备将来：若再引入非 ASCII 名，可在此加 别名，正文交叉引用会自动重写。）
_CODEX_NAME_MAP: dict[str, str] = {}


def codex_skill_name(claude_stem: str) -> str:
    """源命令名（已去 .md）→ Codex skill 名（名已统一，恒等；有别名则按别名）。"""
    return _CODEX_NAME_MAP.get(claude_stem, claude_stem)


def find_codex_skill_dir() -> Optional[Path]:
    """定位 Codex 用户级 skill 目录。

    Codex only scans ~/.codex/skills. Stable/test isolation is by skill folder
    name (redbeacon* vs redbeacon-test*), not by a separate skills root.
    """
    root = Path(os.path.expanduser("~")) / ".codex"
    if not root.exists():
        return None
    skills = root / "skills"
    skills.mkdir(parents=True, exist_ok=True)
    return skills


def _yaml_escape(s: str) -> str:
    return '"' + s.replace("\\", "\\\\").replace('"', '\\"') + '"'


def claude_md_to_codex_skill(claude_stem: str, md_text: str) -> tuple[str, str]:
    """把一份 Claude 命令 markdown 转成 Codex SKILL.md 文本。
    返回 (codex_skill_name, skill_md)。正文原样保留（CLI 调用 harness 无关）。"""
    name = codex_skill_name(claude_stem)
    desc, body = "", md_text
    # 拆 YAML frontmatter（首段 --- … ---）
    if md_text.startswith("---"):
        parts = md_text.split("\n---", 1)
        if len(parts) == 2:
            head = parts[0].lstrip("-\n")
            body = parts[1].lstrip("\n")
            for line in head.splitlines():
                if line.strip().startswith("description:"):
                    desc = line.split("description:", 1)[1].strip().strip('"').strip("'")
                    break
    desc = desc or f"RedBeacon 能力：{name}"
    short = desc.split("—")[0].split(" — ")[0].strip()[:60] or name
    # 正文交叉引用重写：把中文名 skill 的斜杠引用换成 Codex 的 ASCII 别名，消除悬空引用
    # （如 `/redbeacon-定位` → `/redbeacon-locate`）。ASCII 名的 7 个本就一致，无需改。
    for zh_stem, ascii_name in _CODEX_NAME_MAP.items():
        body = body.replace("/" + zh_stem, "/" + ascii_name)
    fm = (
        "---\n"
        f"name: {name}\n"
        f"description: {_yaml_escape(desc)}\n"
        "metadata:\n"
        f"  short-description: {_yaml_escape(short)}\n"
        "---\n\n"
    )
    return name, fm + body


def _write_codex_bridge(claude_stem: str, md_text: str) -> Optional[str]:
    """把一份真源 markdown 派生写入 Codex skill 文件夹。返回写入的 skill 名或 None（没装 Codex）。"""
    cdir = find_codex_skill_dir()
    if cdir is None:
        return None
    name, skill_md = claude_md_to_codex_skill(claude_stem, md_text)
    folder = cdir / name
    folder.mkdir(parents=True, exist_ok=True)
    (folder / "SKILL.md").write_text(skill_md, encoding="utf-8")
    return name


def refresh_skill(manifest: dict, timeout: float = _LIVE_TIMEOUT) -> dict:
    """按清单的 skill_raw_base + skill_files 从 OSS 拉最新 markdown 覆盖到本地。
    Claude 端写 .claude/commands/<name>.md；若本机装了 Codex，同时派生写
    ~/.codex/skills/<name>/SKILL.md，做到双宿主一致（真源仍是同一份 markdown）。"""
    base = (manifest.get("skill_raw_base") or "").rstrip("/")
    files = manifest.get("skill_files") or []
    if not base or not files:
        return {"ok": False, "reason": "版本清单缺 skill_raw_base / skill_files，跳过 skill 刷新"}

    target = find_skill_dir()
    if target is None:
        dirname = "~/.claude/commands-redbeacon-test" if build_meta.is_test() else "~/.claude/commands"
        return {"ok": False, "reason": f"未找到 skill 命令目录（{dirname} 不存在）；可能尚未安装到 AI 助手"}
    target.mkdir(parents=True, exist_ok=True)
    codex_dir = find_codex_skill_dir()   # 没装 Codex 就是 None，整段跳过

    updated, failed, codex_updated = [], [], []
    with httpx.Client(timeout=timeout, follow_redirects=True) as client:
        for name in files:
            try:
                r = client.get(f"{base}/{name}")
                r.raise_for_status()
                (target / name).write_text(r.text, encoding="utf-8")
                updated.append(name)
                if codex_dir is not None:
                    try:
                        cn = _write_codex_bridge(name[:-3] if name.endswith(".md") else name, r.text)
                        if cn:
                            codex_updated.append(cn)
                    except Exception as e:
                        log.warning("写 Codex bridge 失败 %s：%s", name, e)
            except Exception as e:
                log.warning("刷新 skill 文件失败 %s：%s", name, e)
                failed.append(name)

    # 清理孤儿：删掉 manifest 之外的旧 redbeacon* skill（如改名后残留的旧文件名），
    # 让本地目录与真源严格一致——只动 redbeacon* 前缀，不碰用户其它命令。
    removed: list[str] = []
    if not failed:   # 仅当本轮全部拉成功才清理，避免网络抖动误删
        keep = set(files)
        for p in target.glob("redbeacon*.md"):
            if p.name not in keep:
                try:
                    p.unlink(); removed.append(p.name)
                except Exception:
                    pass

    codex_removed: list[str] = []
    if codex_dir is not None and not failed:
        keep_codex = {codex_skill_name(f[:-3] if f.endswith(".md") else f) for f in files}
        for d in codex_dir.glob("redbeacon*"):
            if build_meta.is_test() and not d.name.startswith("redbeacon-test"):
                continue
            if not build_meta.is_test() and d.name.startswith("redbeacon-test"):
                continue
            if d.is_dir() and d.name not in keep_codex:
                shutil.rmtree(d, ignore_errors=True); codex_removed.append(d.name)

    result = {
        "ok": not failed,
        "target_dir": str(target),
        "updated": updated,
        "failed": failed,
    }
    if removed:
        result["removed"] = removed
    if codex_dir is not None:
        result["codex_dir"] = str(codex_dir)
        result["codex_updated"] = codex_updated
        if codex_removed:
            result["codex_removed"] = codex_removed
    return result


# ── CLI 自升级 ──────────────────────────────────────────────────────────────

def _has_uv() -> bool:
    return shutil.which("uv") is not None


def self_upgrade(timeout: float = 600.0) -> dict:
    """用 uv 升级闭源 CLI 包。非 uv 安装环境优雅降级（给手动指引，不报错）。"""
    if build_meta.is_test():
        return {
            "ok": False,
            "skipped": True,
            "reason": "测试版使用独立整包通道，跳过正式版 uv CLI 兼容升级。",
        }
    if not _has_uv():
        return {
            "ok": False,
            "skipped": True,
            "reason": "未检测到 uv，跳过 CLI 自升级（开发态或非标准安装）。",
            "hint": "正式安装是 PyInstaller 自包含客户端；如需手动升级请重跑安装脚本。",
        }
    try:
        proc = subprocess.run(
            ["uv", "tool", "upgrade", "redbeacon"],
            capture_output=True, text=True, timeout=timeout,
        )
        ok = proc.returncode == 0
        tail = (proc.stdout + proc.stderr).strip().splitlines()[-3:]
        return {"ok": ok, "skipped": False, "log": "\n".join(tail)}
    except Exception as e:
        return {"ok": False, "skipped": False, "reason": f"uv 升级执行失败：{e}"}


def run_update(progress: Optional[ProgressCallback] = None) -> dict:
    """Full update for every entry point by delegating to the OSS installer."""
    _emit(progress, step="manifest", message="正在检查最新版本…", percent=1)
    manifest = fetch_manifest()
    if manifest is None:
        return {
            "ok": False,
            "current": __version__,
            "error": "拉不到版本清单（网络不通或版本源暂不可用），本次升级中止，当前版本仍可正常使用。",
        }
    latest = str(manifest.get("version", "")).strip()
    available = is_newer(latest, __version__)
    _write_cache(_result_from_manifest(manifest))

    client_res = launch_installer_update(progress=progress)
    delegated_ok = bool(client_res.get("ok")) or bool(client_res.get("skipped"))
    cli_res = {
        "ok": delegated_ok,
        "delegated": True,
        "reason": "命令行入口由安装更新脚本统一刷新。",
    }
    skill_res = {
        "ok": delegated_ok,
        "delegated": True,
        "reason": "skill 由安装更新脚本统一刷新。",
    }
    _emit(progress, step="done", message="更新脚本已启动", percent=100)

    return {
        "ok": delegated_ok,
        "current": __version__,
        "latest": latest,
        "was_outdated": available,
        "notes": manifest.get("notes", ""),
        "client": client_res,
        "cli": cli_res,
        "skill": skill_res,
    }
