"""Build/channel metadata.

Stable builds keep the historical RedBeacon names. Test builds are produced by
PyInstaller with a runtime hook that sets REDBEACON_CHANNEL=test before imports.
"""
from __future__ import annotations

import os


def channel() -> str:
    ch = (os.environ.get("REDBEACON_CHANNEL") or os.environ.get("REDBEACON_BUILD_CHANNEL") or "stable").strip().lower()
    return "test" if ch in {"test", "testing", "beta"} else "stable"


def is_test() -> bool:
    return channel() == "test"


def app_name() -> str:
    return "RedBeacon_test" if is_test() else "RedBeacon"


def command_name() -> str:
    return "redbeacon-test" if is_test() else "redbeacon"


def cli_exe_name() -> str:
    return "redbeacon-test-cli" if is_test() else "redbeacon-cli"


def update_manifest_url() -> str:
    suffix = "latest-test.json" if is_test() else "latest.json"
    return f"https://bytestaff-redbeacon.oss-cn-shanghai.aliyuncs.com/{suffix}"
