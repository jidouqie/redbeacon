# 归档：已废弃的旧分发方案（2026-07-07 封存）

> 这个文件夹**只是历史备案**，里面的方案**全部作废、不再使用**，别照着做、也别让它干扰当前判断。
>
> **现在唯一的分发/发版方式**见根 `CLAUDE.md`「打包/交付」章节：
> **对外分发只走阿里云 OSS 桶 `bytestaff-redbeacon`（上海·公共读）；客户端包先借助 GitHub Actions 在三端打包并上传 OSS，再由 `tools/release.sh` 发布 latest/wheel/install/skill。GitHub 不是发布源。**

---

## 现在长这样（对照记忆）

| 东西 | 现在的唯一去处（OSS） |
|---|---|
| 一键安装命令 | `curl -fsSL https://bytestaff-redbeacon.oss-cn-shanghai.aliyuncs.com/install.sh \| bash`（Win 用 `install.ps1 \| iex`） |
| 客户端自包含包 | `…/app/RedBeacon-win-x64.zip` / `…/app/RedBeacon-mac-arm64.zip` / `…/app/RedBeacon-linux-x64.zip`（GitHub Actions 构建后上传） |
| CLI 本体 wheel | `…/pip/simple/redbeacon/`（PEP503 索引） |
| 版本清单 latest.json | `…/latest.json` |
| skill | `…/skill/redbeacon-skill.tar.gz`（装机）+ `…/skill/commands/*.md`（升级） |

---

## 三条已废弃的旧通道（原本干嘛的 + 为什么废）

### 1. 官网 `redbeacon.jiomig.com`（独立营销站 + 托管 install.sh）
- **原本**：独立官网（代码在**另一个仓** `~/code/auto-redbook/redbeacon-web`，FastAPI + Caddy + Docker，`deploy.sh` rsync 到生产服务器 `106.14.178.16`），首页做营销落地，并托管一份 `install.sh` 供 `curl … | bash`。
- **为什么废**：产品介绍页**并入 bytestaff 数字员工平台**，不再单独维护官网；安装脚本改由 OSS 托管，不需要服务器。
- **现状**：`redbeacon-web` 仓保持原样、不再部署；本仓内所有指向 `redbeacon.jiomig.com` 的安装命令/链接已改成 OSS / 平台。

### 2. git-push 发布法（老 `tools/release.sh` + 仓内 `pip/simple/`）
- **原本**：发版 = 打 wheel → 塞进仓内 `pip/simple/redbeacon/`（PEP503 索引）→ `git add -A && git push origin main`；客户端 install.sh 的 `--find-links` 指向 **GitHub raw** 的这个 `pip/simple/index.html`，`redbeacon update` 也从 GitHub raw 读 `latest.json`。
- **为什么废**：把二进制 wheel 提交进 git 又慢又脏、GitHub raw 国内不稳；改成 OSS 后不再把 wheel/安装包放进 git，国内下载快。注意：当前仍需要推 `cli/ci/bundle` 或手动触发 GitHub Actions 来打客户端包。
- **现状**：`pip/simple/` 已删（commit `ca75dd9`）；`release.sh` 已重写为传 OSS。

### 3. GitHub skill 分发（tarball + raw）
- **原本**：install.sh 从 `github.com/jidouqie/redbeacon/archive/main.tar.gz` 拉 skill；`redbeacon update` 从 `raw.githubusercontent.com/jidouqie/redbeacon/main/.claude/commands/<文件>` 逐个刷 skill（配 GitHub 加速代理兜底）。
- **为什么废**：既然「唯一源 = OSS」，skill 没理由单独依赖 GitHub；国内拉 GitHub 仍是痛点。
- **现状**：skill 改由 `release.sh` 打 tarball + 散装 md 传 OSS `skill/`；install.sh / install.ps1 / `gen_latest.py` 的 skill 源已全部指向 OSS。`.claude/commands/*.md` 仍是 skill 真源（只是发布目的地变 OSS）。

---

## 注意（别踩回旧坑）
- **别再往 `pip/` 目录塞 wheel**、别把安装/skill 源指回 GitHub 或 `redbeacon.jiomig.com`。`release.sh` 只做 OSS 发布阶段，不负责触发 GitHub Actions；需要打客户端包时先推 `cli/ci/bundle` 或手动 dispatch。
- GitHub 仓/Actions 可以作为代码托管与构建机，但不作为对外分发源（不走 GitHub Release/Raw 给用户下载）。
- 唯一例外的 GitHub 依赖是 **uv 下载 Python 运行时**（python-build-standalone 在 GitHub Releases，上游工具行为、非我们的分发件），install.sh 已用国内加速代理兜底，无需处理。
