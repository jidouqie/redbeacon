@echo off
rem ============================================================================
rem  RedBeacon 操作台 · Windows 双击启动器
rem  双击本文件 -> 起本机服务 + 自动开浏览器。关掉浏览器后服务仍在，
rem  回到这个黑窗口按 Ctrl-C 或直接关窗即结束。
rem ============================================================================
title RedBeacon 操作台
chcp 65001 >nul

rem install.ps1 默认把 redbeacon.cmd shim 放在 %USERPROFILE%\.local\bin
set "PATH=%USERPROFILE%\.local\bin;%PATH%"

echo.
echo    RedBeacon · 小红书运营数字员工
echo    正在启动本机操作台……
echo.

where redbeacon >nul 2>nul
if errorlevel 1 (
  echo 没找到 redbeacon 命令。请先安装 RedBeacon，再双击本启动器。
  echo 安装： irm https://bytestaff.jiomig.com/install.ps1 ^| iex
  pause
  exit /b 1
)

redbeacon ui app

echo.
echo 操作台已退出。可关闭本窗口。
pause
