"""Build RedBeacon desktop icon assets from the selected 1024px PNG.

Outputs:
- RedBeacon_1024.png: canonical source image
- RedBeacon.ico: Windows multi-size icon
- RedBeacon.icns: macOS app icon

This intentionally uses macOS built-ins plus a tiny stdlib ICO writer so the
release flow does not depend on Pillow or ImageMagick.
"""

from __future__ import annotations

import argparse
import shutil
import struct
import subprocess
import tempfile
from pathlib import Path


SIZES = (16, 32, 48, 64, 128, 256, 512, 1024)


def run(cmd: list[str]) -> None:
    subprocess.run(cmd, check=True)


def resize_png(src: Path, dst: Path, size: int) -> None:
    run(["sips", "-z", str(size), str(size), str(src), "--out", str(dst)])


def write_png_ico(src: Path, dst: Path) -> None:
    with tempfile.TemporaryDirectory(prefix="rb-ico-") as tmp_s:
        tmp = Path(tmp_s)
        pngs: list[tuple[int, bytes]] = []
        for size in (16, 32, 48, 64, 128, 256):
            p = tmp / f"icon_{size}.png"
            resize_png(src, p, size)
            pngs.append((size, p.read_bytes()))

        header_size = 6 + 16 * len(pngs)
        offset = header_size
        entries = []
        chunks = []
        for size, data in pngs:
            width = 0 if size == 256 else size
            height = 0 if size == 256 else size
            entries.append(
                struct.pack(
                    "<BBBBHHII",
                    width,
                    height,
                    0,
                    0,
                    1,
                    32,
                    len(data),
                    offset,
                )
            )
            chunks.append(data)
            offset += len(data)

        dst.write_bytes(
            struct.pack("<HHH", 0, 1, len(pngs)) + b"".join(entries) + b"".join(chunks)
        )


def write_icns(src: Path, dst: Path) -> None:
    with tempfile.TemporaryDirectory(prefix="rb-icns-") as tmp_s:
        iconset = Path(tmp_s) / "RedBeacon.iconset"
        iconset.mkdir()
        for size in (16, 32, 128, 256, 512):
            resize_png(src, iconset / f"icon_{size}x{size}.png", size)
            resize_png(src, iconset / f"icon_{size}x{size}@2x.png", size * 2)
        run(["iconutil", "-c", "icns", str(iconset), "-o", str(dst)])


def build(src: Path, out_dir: Path) -> None:
    out_dir.mkdir(parents=True, exist_ok=True)
    canonical = out_dir / "RedBeacon_1024.png"
    shutil.copyfile(src, canonical)
    write_png_ico(canonical, out_dir / "RedBeacon.ico")
    write_icns(canonical, out_dir / "RedBeacon.icns")
    shutil.copyfile(canonical, out_dir / "RedBeacon.png")


def main() -> None:
    here = Path(__file__).resolve().parent
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--src",
        type=Path,
        default=here / "candidates" / "02-lighthouse-signal.png",
        help="Selected 1024px PNG source.",
    )
    parser.add_argument(
        "--out",
        type=Path,
        action="append",
        default=[here],
        help="Output directory. Repeat to write multiple directories.",
    )
    args = parser.parse_args()

    for out in args.out:
        build(args.src.resolve(), out.resolve())
        print(f"wrote {out.resolve()}")


if __name__ == "__main__":
    main()
