"""Render RedBeacon desktop icon candidates as deterministic SVG-backed PNGs."""

from pathlib import Path

from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parent
CANDIDATES = ROOT / "candidates"


def shell(inner: str, bg: str, border: str = "#B7943F") -> str:
    return f"""
<svg xmlns="http://www.w3.org/2000/svg" width="1024" height="1024" viewBox="0 0 1024 1024">
  <defs>
    <linearGradient id="bg" x1="0" y1="0" x2="0.4" y2="1">
      {bg}
    </linearGradient>
    <clipPath id="round"><rect x="64" y="64" width="896" height="896" rx="208"/></clipPath>
  </defs>
  <rect x="64" y="64" width="896" height="896" rx="208" fill="url(#bg)"/>
  <g clip-path="url(#round)">
    {inner}
  </g>
  <rect x="64" y="64" width="896" height="896" rx="208" fill="none"
        stroke="{border}" stroke-opacity="0.24" stroke-width="3"/>
</svg>
"""


VARIANTS = {
    "01-beacon-pulse": {
        "label": "1. Beacon Pulse",
        "svg": shell(
            """
    <defs>
      <radialGradient id="halo" cx="50%" cy="50%" r="54%">
        <stop offset="0" stop-color="#ff5a49" stop-opacity="0.55"/>
        <stop offset="0.52" stop-color="#ff3d54" stop-opacity="0.14"/>
        <stop offset="1" stop-color="#ff3d54" stop-opacity="0"/>
      </radialGradient>
      <radialGradient id="orb" cx="42%" cy="38%" r="62%">
        <stop offset="0" stop-color="#ffe6c2"/>
        <stop offset="0.32" stop-color="#ff9a3d"/>
        <stop offset="0.72" stop-color="#ff3d54"/>
        <stop offset="1" stop-color="#e21f45"/>
      </radialGradient>
    </defs>
    <rect x="64" y="64" width="896" height="896" fill="url(#halo)"/>
    <g fill="none" stroke="#ff5a49">
      <circle cx="512" cy="512" r="250" stroke-opacity="0.23" stroke-width="7"/>
      <circle cx="512" cy="512" r="340" stroke-opacity="0.12" stroke-width="6"/>
    </g>
    <circle cx="512" cy="512" r="168" fill="url(#orb)"/>
    <circle cx="480" cy="480" r="52" fill="#fff4db" opacity="0.74"/>
            """,
            """
      <stop offset="0" stop-color="#251217"/>
      <stop offset="0.55" stop-color="#140d10"/>
      <stop offset="1" stop-color="#0b0a0d"/>
            """,
        ),
    },
    "02-lighthouse-signal": {
        "label": "2. Lighthouse Signal",
        "svg": shell(
            """
    <defs>
      <linearGradient id="beam" x1="0.18" y1="0.18" x2="0.92" y2="0.82">
        <stop offset="0" stop-color="#ffd389" stop-opacity="0.92"/>
        <stop offset="0.45" stop-color="#ff5a49" stop-opacity="0.24"/>
        <stop offset="1" stop-color="#ff2d55" stop-opacity="0"/>
      </linearGradient>
      <linearGradient id="tower" x1="0" y1="0" x2="0.2" y2="1">
        <stop offset="0" stop-color="#fff0c9"/>
        <stop offset="0.46" stop-color="#ff8b43"/>
        <stop offset="1" stop-color="#e82349"/>
      </linearGradient>
    </defs>
    <path d="M454 408 L904 236 L904 654 L454 548 Z" fill="url(#beam)"/>
    <path d="M390 330 h244 a46 46 0 0 1 46 46 v44 h-336 v-44 a46 46 0 0 1 46-46z"
          fill="#ff4d4f"/>
    <circle cx="512" cy="420" r="66" fill="#fff0c9"/>
    <path d="M410 760 L452 472 h120 l42 288 z" fill="url(#tower)"/>
    <path d="M382 790 h260 a32 32 0 0 1 32 32 v18 h-324 v-18 a32 32 0 0 1 32-32z"
          fill="#ff3d54"/>
    <g fill="none" stroke="#ffcf7a" stroke-width="18" stroke-linecap="round" opacity="0.78">
      <path d="M300 332 C238 390 204 462 204 542"/>
      <path d="M724 332 C786 390 820 462 820 542"/>
    </g>
            """,
            """
      <stop offset="0" stop-color="#26151a"/>
      <stop offset="0.62" stop-color="#101217"/>
      <stop offset="1" stop-color="#09090c"/>
            """,
        ),
    },
    "03-rb-monogram": {
        "label": "3. RB Monogram",
        "svg": shell(
            """
    <defs>
      <radialGradient id="glow" cx="42%" cy="36%" r="66%">
        <stop offset="0" stop-color="#ffbd77" stop-opacity="0.72"/>
        <stop offset="0.45" stop-color="#ff3d54" stop-opacity="0.26"/>
        <stop offset="1" stop-color="#ff3d54" stop-opacity="0"/>
      </radialGradient>
      <linearGradient id="mark" x1="0" y1="0" x2="1" y2="1">
        <stop offset="0" stop-color="#fff1cb"/>
        <stop offset="0.36" stop-color="#ff9a3d"/>
        <stop offset="0.72" stop-color="#ff375f"/>
        <stop offset="1" stop-color="#d91f46"/>
      </linearGradient>
    </defs>
    <rect x="64" y="64" width="896" height="896" fill="url(#glow)"/>
    <path fill="url(#mark)" d="M278 716 V298 h218 c92 0 156 50 156 130
      c0 48-24 88-66 111 62 20 100 68 100 133 0 88-70 144-180 144H278z
      M388 476h91c39 0 63-21 63-55s-24-54-65-54h-89v109z
      M388 746h105c50 0 80-26 80-68s-31-67-82-67H388v135z"/>
    <path fill="#fff4d8" opacity="0.96" d="M262 298h140c118 0 198 60 198 162
      c0 68-34 118-94 143l129 213H504L392 624h-20v192H262V298z
      M372 536h31c52 0 83-28 83-75 0-45-31-73-83-73h-31v148z"/>
    <circle cx="732" cy="292" r="42" fill="#ffcf7a"/>
            """,
            """
      <stop offset="0" stop-color="#1b1017"/>
      <stop offset="0.56" stop-color="#15141b"/>
      <stop offset="1" stop-color="#08090f"/>
            """,
        ),
    },
    "04-spark-card": {
        "label": "4. Spark Card",
        "svg": shell(
            """
    <defs>
      <linearGradient id="card" x1="0" y1="0" x2="1" y2="1">
        <stop offset="0" stop-color="#fff1cb"/>
        <stop offset="0.42" stop-color="#ff9a3d"/>
        <stop offset="1" stop-color="#ff2d55"/>
      </linearGradient>
      <radialGradient id="hot" cx="52%" cy="44%" r="52%">
        <stop offset="0" stop-color="#fff5d8"/>
        <stop offset="0.28" stop-color="#ffb45e"/>
        <stop offset="0.68" stop-color="#ff3d54"/>
        <stop offset="1" stop-color="#d91f46"/>
      </radialGradient>
    </defs>
    <rect x="308" y="242" width="408" height="540" rx="72" fill="#09090c" opacity="0.48"/>
    <rect x="276" y="214" width="408" height="540" rx="72" fill="url(#card)"/>
    <rect x="330" y="306" width="300" height="44" rx="22" fill="#fff8e8" opacity="0.82"/>
    <rect x="330" y="384" width="244" height="36" rx="18" fill="#fff8e8" opacity="0.64"/>
    <rect x="330" y="446" width="210" height="36" rx="18" fill="#fff8e8" opacity="0.44"/>
    <circle cx="512" cy="612" r="118" fill="url(#hot)"/>
    <circle cx="480" cy="580" r="36" fill="#fff4d8" opacity="0.84"/>
    <g fill="none" stroke="#fff4d8" stroke-width="20" stroke-linecap="round" opacity="0.88">
      <path d="M704 280 l52-62"/>
      <path d="M756 382 h72"/>
      <path d="M228 664 h78"/>
    </g>
            """,
            """
      <stop offset="0" stop-color="#201117"/>
      <stop offset="0.55" stop-color="#12131a"/>
      <stop offset="1" stop-color="#08080c"/>
            """,
        ),
    },
}


def page_html(svg: str) -> str:
    return (
        "<!doctype html><html><head><style>"
        "*{box-sizing:border-box}html,body{margin:0;width:1024px;height:1024px;background:transparent}"
        "</style></head><body>"
        f"{svg}"
        "</body></html>"
    )


def overview_html() -> str:
    cards = []
    for key, meta in VARIANTS.items():
        svg = meta["svg"].replace("<svg ", '<svg style="width:360px;height:360px" ')
        cards.append(
            f"<div class='card'>{svg}<div class='label'>{meta['label']}<br><span>{key}</span></div></div>"
        )
    return f"""
<!doctype html>
<html>
<head>
<style>
  body {{
    margin: 0;
    width: 1800px;
    height: 1040px;
    background: #f5f1e9;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
    color: #251217;
  }}
  .wrap {{
    padding: 74px 80px;
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 36px;
  }}
  .card {{
    height: 820px;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    gap: 42px;
  }}
  .label {{
    text-align: center;
    font-size: 36px;
    font-weight: 760;
    line-height: 1.18;
  }}
  .label span {{
    display: inline-block;
    margin-top: 16px;
    font-size: 22px;
    font-weight: 560;
    color: #7b4d40;
  }}
</style>
</head>
<body><div class="wrap">{''.join(cards)}</div></body>
</html>
"""


def render() -> None:
    CANDIDATES.mkdir(parents=True, exist_ok=True)
    with sync_playwright() as p:
        browser = p.chromium.launch()
        page = browser.new_page(viewport={"width": 1024, "height": 1024}, device_scale_factor=1)
        for key, meta in VARIANTS.items():
            page.set_content(page_html(meta["svg"]))
            page.screenshot(path=str(CANDIDATES / f"{key}.png"), omit_background=True)

        overview = browser.new_page(viewport={"width": 1800, "height": 1040}, device_scale_factor=1)
        overview.set_content(overview_html())
        overview.screenshot(path=str(CANDIDATES / "overview.png"))
        browser.close()

    print(f"wrote {CANDIDATES}")


if __name__ == "__main__":
    render()
