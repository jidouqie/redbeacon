#!/usr/bin/env bash
# ──────────────────────────────────────────────────────────────────────────────
# RedBeacon 操作台 · Mac 双击启动器
# 双击本文件（Finder 里它会在「终端」里运行）→ 起本机服务 + 自动开浏览器。
# 关掉浏览器后服务仍在；回到这个终端窗口按 Ctrl-C 或直接关窗即结束。
#
# 首次双击若提示「无法打开，因为来自身份不明的开发者」：
#   右键本文件 → 打开 → 在弹窗里再点「打开」（只需一次）。
# ──────────────────────────────────────────────────────────────────────────────
set -euo pipefail

# install.sh 默认把 redbeacon shim 放在 ~/.local/bin；homebrew 在 /opt/homebrew/bin。
# 双击启动的 shell 不一定加载用户 profile，这里把常见目录补进 PATH。
export PATH="$HOME/.local/bin:/opt/homebrew/bin:/usr/local/bin:$PATH"

clear
printf '\033[38;5;131m'
cat <<'BANNER'
   ◗  RedBeacon · 小红书运营数字员工
      正在启动本机操作台……
BANNER
printf '\033[0m\n'

if ! command -v redbeacon >/dev/null 2>&1; then
  printf '\033[31m没找到 redbeacon 命令。\033[0m\n'
  printf '请先安装：在终端粘贴一行\n'
  printf '  \033[36mcurl -fsSL https://bytestaff.jiomig.com/install.sh | bash\033[0m\n'
  printf '装好后再双击本启动器。\n\n按回车关闭。'
  read -r _
  exit 1
fi

# 起服务（阻塞常驻，redbeacon 自己会等端口起来再开浏览器）。
redbeacon ui app

printf '\n操作台已退出。可关闭本窗口。\n'
