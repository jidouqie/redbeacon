# RedBeacon 双击启动器

让用户**不开终端、不装 AI 助手**也能打开操作台（独立 UI 第一刀）。

| 平台 | 文件 | 用法 |
|---|---|---|
| macOS | `RedBeacon.command` | 双击（在「终端」里运行）。首次若被 Gatekeeper 拦：右键→打开→再点「打开」（只一次）。 |
| Windows | `RedBeacon.bat` | 双击。 |

两者都只做一件事：把 `redbeacon` CLI shim（安装脚本会放在 `~/.local/bin`）补进 PATH，然后跑
`redbeacon ui app` —— 引擎起本机 FastAPI 服务 + 打开操作台。
关掉浏览器后服务仍在，回启动器窗口 Ctrl-C / 关窗即结束。

## 给打包/安装用

旧版浏览器壳调试时，可把对应平台的启动器拷到桌面，例如 mac：

```bash
install -m 755 install/launchers/RedBeacon.command "$HOME/Desktop/RedBeacon.command"
```

## 桌面客户端入口（已落地，安装时自动生成）

`install/install.sh`（Mac/Linux）和 `install/install.ps1`（Windows）装完自包含客户端包后，**自动生成一个双击即开的桌面客户端**：
- macOS → `~/Applications/RedBeacon.app`（启动台/聚焦搜索可见）
- Windows → 桌面 + 开始菜单 `RedBeacon.lnk`（指向无控制台的 `redbeacon-app.exe`）
- Linux → `~/.local/share/applications/redbeacon.desktop`

双击打开的是 **pywebview 原生窗口**（无浏览器外壳），后端仍是 `redbeacon ui app` 引擎。
**关键**：这些入口是安装脚本在本机生成/放置的，不走 GitHub Release 分发；未签名时仍可能触发系统提示，
签名/公证是后续优化项。

> 本目录的 `RedBeacon.command` / `RedBeacon.bat` 是更早的「浏览器壳」启动器，已被上面自动生成的
> 原生窗口入口取代，留作兜底参考。`redbeacon ui app` 引擎入口不变。
>
> 想进一步降低系统安全提示，再给 .app/.exe 做签名+公证（Apple $99/年 + Windows 证书）。
