"""RedBeacon — 小红书自动化 CLI。

入口：`redbeacon` 命令（pyproject.toml 声明），实现在 redbeacon.cli:main。
"""
__version__ = "0.1.5"
