"""feishu setup / test（飞书数据只在发布时读取，无独立同步操作）"""
from __future__ import annotations

import time

from redbeacon import config as cfg
from redbeacon.config_keys import CK_FEISHU_APP_ID, CK_FEISHU_APP_SECRET, CK_FEISHU_USER_ID
from redbeacon import database
from redbeacon.utils.logger import get_logger
from ._runtime import out, err, update_account

log = get_logger("router.feishu")

_FEISHU_TEMPLATE_APP_TOKEN = "Wf0WbW4R0a9pcJs4bm6cGEuKn7e"
_FEISHU_TEMPLATE_TABLE_ID  = "tblGEBTJoqK6snYP"


def dispatch(args) -> None:
    if args.sub == "setup": _setup(args)
    elif args.sub == "test": _test(args)
    elif args.sub == "perms": _perms(args)
    else:                    err(f"未知 feishu 子命令：{args.sub}")


def _perms(args) -> None:
    """打印自建应用要开的权限 JSON（紧凑、可直接粘进飞书「批量导入权限」）。
    这是权限清单的唯一出口——UI 向导与对话引导都取这份，不在别处硬编码。
    故意只 print 原始 JSON（不走 out() 的信封），方便 `> 文件` 直接落盘粘贴。"""
    from redbeacon.services.feishu_api import permissions_json
    print(permissions_json())


def _setup(args) -> None:
    from redbeacon.services.feishu_api import FeishuAPI
    arg_app_token = (getattr(args, "app_token", None) or "").strip()
    arg_table_id  = (getattr(args, "table_id", None) or "").strip()

    app_id     = cfg.get(CK_FEISHU_APP_ID)
    app_secret = cfg.get(CK_FEISHU_APP_SECRET)
    if not app_id or not app_secret:
        err("飞书凭证未配置", next="redbeacon config set feishu_app_id <ID>")

    try:
        FeishuAPI.verify_credentials(app_id, app_secret)
    except Exception as e:
        err(str(e))

    feishu = FeishuAPI(app_id, app_secret, "", "")

    # 已绑过则复用、不重复建表（幂等：重跑只为补/刷新授权）；显式传参可覆盖
    with database.cursor() as c:
        existing = c.execute(
            "SELECT feishu_app_token, feishu_table_id, feishu_user_id FROM account WHERE id=?",
            (args.account_id,),
        ).fetchone()
    app_token = arg_app_token or (existing["feishu_app_token"] if existing else "") or ""
    table_id  = arg_table_id  or (existing["feishu_table_id"]  if existing else "") or ""
    reused = bool(app_token and table_id and not arg_app_token)

    if not app_token or not table_id:
        app_token = feishu.copy_bitable_template(_FEISHU_TEMPLATE_APP_TOKEN)
        table_id = ""
        for _ in range(6):
            time.sleep(1)
            tables = feishu.list_tables(app_token)
            if tables:
                table_id = tables[0]["table_id"]
                break
        if not table_id:
            table_id = _FEISHU_TEMPLATE_TABLE_ID
        reused = False

    # 授权 + 转移所有权：复制出来的表默认归"应用"所有，不授权用户根本进不去
    user_id = (cfg.get(CK_FEISHU_USER_ID) or "").strip()
    if not user_id and existing:
        user_id = (existing["feishu_user_id"] or "").strip()

    shared = None
    warning = None
    if app_token and app_token != _FEISHU_TEMPLATE_APP_TOKEN:
        if user_id:
            shared = feishu.share_bitable_to_user(app_token, user_id)
        else:
            warning = ("未配置接收人 User ID：表已建好但未授权给你，你可能打不开它。"
                       "先 `redbeacon config feishu-users` 选自己写入 feishu_user_id，再重跑 "
                       f"`redbeacon feishu setup --account-id {args.account_id}` 即可补授权。")

    update_account(args.account_id,
                   feishu_app_token=app_token or None,
                   feishu_table_id=table_id or None)

    resp = {"ok": True, "app_token": app_token, "table_id": table_id, "reused": reused}
    if shared is not None:
        resp["shared"] = shared
    if warning:
        resp["warning"] = warning
    out(resp)


def _test(args) -> None:
    from redbeacon.services.feishu_api import FeishuAPI

    app_id     = cfg.get(CK_FEISHU_APP_ID)
    app_secret = cfg.get(CK_FEISHU_APP_SECRET)
    with database.cursor() as c:
        acc = c.execute(
            "SELECT feishu_app_token, feishu_table_id, feishu_user_id FROM account WHERE id=?",
            (args.account_id,),
        ).fetchone()
    if not acc or not acc["feishu_app_token"] or not acc["feishu_table_id"]:
        err("账号尚未关联飞书多维表格",
            next=f"redbeacon feishu setup --account-id {args.account_id}")
    if not app_id or not app_secret:
        err("飞书凭证未配置", next="redbeacon config set feishu_app_id <ID>")

    try:
        FeishuAPI.verify_credentials(app_id, app_secret)
    except Exception as e:
        err(str(e))

    app_token = acc["feishu_app_token"]
    table_id  = acc["feishu_table_id"]
    user_id   = cfg.get(CK_FEISHU_USER_ID)
    feishu = FeishuAPI(app_id, app_secret, app_token, table_id)
    results: dict = {}

    try:
        feishu.write_test_record_and_cleanup()
        results["table_write"]  = "✓ 写入成功"
        results["table_delete"] = "✓ 删除成功"
    except Exception as e:
        results["table_write"]  = f"✗ 写入失败：{e}"
        results["table_delete"] = "—"

    if user_id:
        table_url = f"https://www.feishu.cn/base/{app_token}?table={table_id}"
        try:
            feishu.send_text_message(
                user_id,
                f"✅ RedBeacon 飞书连通性测试成功\n\n多维表格：{table_url}",
            )
            results["message"] = "✓ 消息发送成功"
        except Exception as e:
            results["message"] = f"✗ 消息发送失败：{e}"
    else:
        results["message"] = "— 未配置 User ID，跳过消息测试"

    out(results)
