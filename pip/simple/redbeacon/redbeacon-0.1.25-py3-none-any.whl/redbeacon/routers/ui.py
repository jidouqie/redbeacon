"""ui account — 把对话定下来的账号配置渲染成可视化两栏页，让用户审阅+微调+试生成。

设计（契合"无常驻服务"：服务生命周期完全包在本命令内，命令结束即退）：
  左栏：账号配置（人话标签，不暴露字段名），值已按对话结果预填，用户看哪不对改哪。
  右栏：一键「生成一篇预览」看效果——不消耗选题库、落库存起来、配图按左栏设定一起出；
        不推飞书（预览阶段不污染审核表）。可反复 改→生成→再改。
  用户点「完成返回」或超时 → 服务退出，把累计改了哪些字段汇报给 skill（stdout JSON）。

HTML 是内置固定模板（模型不在运行时手写）。浏览器 JS 只能通过 HTTP 跟本地通信，
故起一个 localhost 一次性服务；它不是 daemon，命令一结束就 server_close。
"""
from __future__ import annotations

import json
import socket
import subprocess
import sys
import threading
import time
from http.server import BaseHTTPRequestHandler, HTTPServer, ThreadingHTTPServer

from redbeacon import database
from ._runtime import out, err, now_iso, account_row, require_account

_TIMEOUT_SEC = 1800  # 30 分钟无操作自动退出

# 所有本地 UI 页脚统一带「开源仓库 + 官网」——颜色取各模板通用的中性灰，明/暗底都适配。
# 各模板放一个 __FOOTER__ 占位符（紧贴 </body> 前；topics 放进可滚动内容区），render 时替换。
_UI_FOOTER = (
    '<div style="text-align:center;padding:20px 16px 26px;margin-top:10px;'
    'border-top:1px solid rgba(128,128,128,.16);color:#8b93a1;font-size:12px;line-height:1.9">'
    'RedBeacon · 小红书运营数字员工<br>'
    '<a href="https://github.com/jidouqie/redbeacon" target="_blank" rel="noopener" '
    'style="color:#8b93a1;text-decoration:none">GitHub 开源</a>'
    ' &nbsp;·&nbsp; '
    '<a href="https://redbeacon.jiomig.com" target="_blank" rel="noopener" '
    'style="color:#8b93a1;text-decoration:none">官网 redbeacon.jiomig.com</a>'
    '</div>'
)

# 左栏可编辑项：字段名 → (人话标签, 是否多行, 分组, 兜底默认值)
# 默认值与 tasks/generate.py 内部兜底一致，保证"不改直接生成"无惊喜；绝不留空。
_GROUP_WHO = "这个号是做什么的"
_GROUP_STYLE = "内容怎么写"
# 用下拉选择（而非自由输入）的定位字段：字段名 → 选项列表
_STRATEGY_CHOICES = {
    "emoji_usage": ["较少", "适量", "丰富"],
}
_STRATEGY_FIELDS = [
    ("niche",                "赛道方向",   False, _GROUP_WHO,
     "生活方式分享"),
    ("target_audience",      "目标读者",   False, _GROUP_WHO,
     "对生活品质有要求的年轻人"),
    ("competitive_advantage","差异化亮点", False, _GROUP_WHO,
     "真实体验、不浮夸、给得出可落地的建议"),
    ("monetization",         "变现方向",   False, _GROUP_WHO,
     "涨粉沉淀，后续私域转化"),
    ("pain_points",          "读者痛点（一行一个）", True, _GROUP_WHO,
     "不知道怎么选\n踩过坑走过弯路\n想做但没方法"),
    ("tone",                 "语气",       False, _GROUP_STYLE,
     "亲切自然，专业但不刻板，像朋友分享而非说教"),
    ("opening_style",        "开头风格",   False, _GROUP_STYLE,
     "提问式或数字列举，前两行必须抓住读者注意力"),
    ("format_style",         "排版风格",   False, _GROUP_STYLE,
     "分段清晰，多用短句，每段2-3行，重点内容单独成行"),
    ("emoji_usage",          "表情用量",   False, _GROUP_STYLE,
     "适量"),
    ("content_length",       "篇幅",       False, _GROUP_STYLE,
     "300-500字"),
    ("visual_theme",         "视觉感觉",   False, _GROUP_STYLE,
     "简洁清爽，有高级感"),
]
# 文案风格框为空时填入的人话默认（让用户看得见、可改，而不是空白）。
# 注意：这里只放"这类内容怎么写"的人话指引——JSON 输出契约、占位符等程序逻辑
# 由 generate.py 的 DEFAULT_PROMPT 在生成时自动补，用户不可见、不用管。
_CT_DEFAULT_PROMPT = "紧扣这一类内容的角度来写，标题抓人，正文给得出干货或共鸣。"
# 内置类型的更贴切人话默认（按类型名匹配，匹配不上用 _CT_DEFAULT_PROMPT）
_CT_DEFAULT_BY_NAME = {
    "干货科普": "把一个知识点讲清楚讲透，多用具体步骤、清单、对比，让读者看完能直接照做。",
    "痛点解析": "戳中读者最头疼的那件事，先把痛点说到心坎里，再给出让人共鸣或恍然大悟的视角。",
    "经验分享": "用第一人称讲自己的真实经历或踩坑复盘，真诚、有细节，像朋友面对面聊。",
}

# 配图方式：值 → 人话
_IMAGE_MODE_LABELS = [
    ("cards", "纯文字卡片（封面也是文字大字报，稳定不花钱）"),
    ("both",  "AI 大字报封面 + 文字卡片"),
    ("ai",    "只要 AI 封面（没有正文卡片）"),
]
# 卡片配色风格：内部值 → 人话（来自渲染器 _THEME_MAP 的合法键）
_CARD_THEME_LABELS = [
    ("default",           "默认·小红书紫"),
    ("botanical",         "森系绿"),
    ("professional",      "商务蓝"),
    ("retro",             "复古橙"),
    ("sketch",            "手绘铅笔"),
    ("terminal",          "极客终端"),
    ("neo-brutalism",     "撞色潮酷"),
    ("playful-geometric", "活泼几何"),
    ("macaron",           "马卡龙粉"),
    ("inkwash",           "水墨国风"),
    ("latte",             "奶咖拿铁"),
    ("skyblue",           "晴空蓝"),
    ("lavender",          "薰衣草紫"),
    ("midnight-gold",     "暗夜鎏金"),
    ("cyber",             "赛博霓虹"),
    ("morandi",           "莫兰迪灰"),
    ("random",            "随机"),
]
_VALID_MODES = {m for m, _ in _IMAGE_MODE_LABELS}
# 配图各项兜底默认（绝不留空）
_IMG_DEFAULTS = {
    "mode": "cards",
    "card_theme": "default",
    "ai_model": "",   # 仅 ai/both 模式才需要，cards 模式不强制
    # 封面「视觉风格」——大白话描述即可（不写占位符）；程序会把它包成「大字报 + 标题大字 + 竖版3:4」
    "prompt_template": "深色背景、亮色块点缀，厚重有力的大字，强对比、留白克制、极简高级",
    "reference_images": [],   # 图生图参考图（有则按图里的人物/风格生成）
}


def dispatch(args) -> None:
    if args.sub == "account":
        _account(args)
    elif args.sub == "dashboard":
        _dashboard(args)
    elif args.sub == "setup":
        _setup(args)
    elif args.sub == "manage":
        _manage(args)
    elif args.sub == "topics":
        _topics(args)
    else:
        err(f"未知 ui 子命令：{args.sub}")


# ── 实时拉中转站可用模型（模型名会换代，写死/手敲迟早失效，故每次现拉）──────────

def _list_models() -> dict:
    """从配置的中转站拉可用模型，分成「写文案的」和「画图的」两类。
    返回 {ok, text:[...], image:[...], error}。拿不到时降级（ok=False），
    前端改用手填输入框，绝不卡死面板。"""
    from redbeacon import config as cfg
    import urllib.request

    base = (cfg.get("ai_base_url") or "").rstrip("/")
    key = cfg.get("ai_api_key") or ""
    if not base or not key:
        return {"ok": False, "text": [], "image": [], "error": "未配置 AI（base_url / key）"}
    url = base + "/models"
    try:
        req = urllib.request.Request(url, headers={"Authorization": f"Bearer {key}"})
        with urllib.request.urlopen(req, timeout=8) as r:
            data = json.loads(r.read().decode("utf-8"))
        ids = sorted(m.get("id", "") for m in data.get("data", []) if m.get("id"))
    except Exception as e:
        return {"ok": False, "text": [], "image": [], "error": str(e)[:120]}
    # 名字里带 image 的当画图模型，其余当写文案模型（贴合中转站命名）
    img = [i for i in ids if "image" in i.lower()]
    txt = [i for i in ids if "image" not in i.lower()]
    return {"ok": True, "text": txt, "image": img, "error": ""}


# ── 首装向导（ui setup）：AI / 飞书 / 代理 配置 + 内联测连通 ───────────────────
#
# 密钥只在「浏览器 → localhost」之间传、直接写本地库，全程不进对话/模型上下文——
# 这正是「配置该走网页而非对话」的核心理由（secret hygiene）。页面不回显任何密钥明文。

def _setup_state() -> dict:
    from redbeacon import config as cfg
    api_key  = cfg.get("ai_api_key") or ""
    base_url = cfg.get("ai_base_url") or ""
    app_secret = cfg.get("feishu_app_secret") or ""
    proxy_url  = cfg.get("proxy_api_url") or ""
    return {
        "ai": {
            "has_key": bool(api_key),
            "base_url": base_url,
            "text_model": cfg.get("ai_model") or "",
            "image_model": cfg.get("image_model") or "",
        },
        "feishu": {"app_id": cfg.get("feishu_app_id") or "", "has_secret": bool(app_secret),
                   "user_id": cfg.get("feishu_user_id") or ""},
        "proxy": {"has_url": bool(proxy_url)},
        "models": _list_models() if (api_key and base_url)
                  else {"ok": False, "text": [], "image": [], "error": "先填好 AI Key 和接口地址"},
    }


# 官方深度适配的中转站——只对它保证工具正常运行（三个生图模型实测全通）。
RECOMMENDED_RELAY = "https://aihub.jidouqie.com/v1"
RECOMMENDED_RELAY_HOST = "aihub.jidouqie.com"


def _is_recommended_relay(base: str) -> bool:
    return "jidouqie" in (base or "").lower()


def _do_test_ai() -> dict:
    """AI 连通性测试 = 拉一次模型列表：既验证 key+base，又顺带把可选模型给前端填下拉。"""
    from redbeacon import config as cfg
    m = _list_models()
    if m["ok"]:
        out = {"ok": True, "models": m,
               "msg": f"连通成功，可用模型 {len(m['text']) + len(m['image'])} 个"}
        # 用了非官方站、即便这次通了也提醒一句（不保证后续生图/各模型都正常）
        if not _is_recommended_relay(cfg.get("ai_base_url") or ""):
            out["non_recommended"] = True
        return out
    res = {"ok": False, "models": m, "error": m.get("error") or "未连通"}
    # 非官方站连不通 → 直接推荐换官方站
    if not _is_recommended_relay(cfg.get("ai_base_url") or ""):
        res["recommend_jidouqie"] = True
        res["suggest"] = (f"这个中转站没连通。本工具只对官方站 {RECOMMENDED_RELAY_HOST} 深度适配，"
                          "其他站点不保证正常运行——强烈建议换成它。")
    return res


def _do_test_image() -> dict:
    """真调一次图片模型，双接口自动择路（chat 多模态 / Images API）。"""
    from redbeacon import config as cfg
    import httpx
    from openai import OpenAI
    from redbeacon.services.image_gen import (
        _extract_image_refs, _is_modalities_unsupported, _looks_like_images_api,
    )
    api_key = cfg.get("ai_api_key") or ""
    base    = cfg.get("ai_base_url") or ""
    model   = (cfg.get("image_model") or "").strip()
    if not api_key:
        return {"ok": False, "error": "还没填 AI API Key"}
    if not model:
        return {"ok": False, "error": "还没选图片模型"}
    # 测试图就出一张真·小红书封面，直观可见（而不是一个小图标）；固定用 RedBeacon 介绍大字报封面
    prompt = (
        "小红书风格的笔记封面图，竖版 3:4 比例（宽高比严格 3:4，不要方图、不要横图）。"
        "大字报海报风格：深色墨蓝近黑的背景，搭配一抹小红书红的高饱和色块点缀，简洁有力。"
        "画面正中用厚重的无衬线中文大字，分三行清晰排版，直接作为封面标题烤进图里：\n"
        "第一行（最大、最醒目）：小红书运营\n"
        "第二行（同样大）：交给 AI\n"
        "第三行（小一号、红底白字色块）：RedBeacon 全自动内容工厂\n"
        "底部一行小字副标题：选题 · 文案 · 配图 · 发布 一条龙。"
        "右上角点缀一个极简的红色灯塔/信标光束图标（呼应 beacon 含义）。"
        "整体强对比、留白克制、版式高级利落，文字必须清晰可读、拼写正确无乱码，质感精致。")
    try:
        client = OpenAI(api_key=api_key, base_url=base, max_retries=0,
                        http_client=httpx.Client(trust_env=False, timeout=180))
        if not _looks_like_images_api(model):
            try:
                resp = client.chat.completions.create(
                    model=model, messages=[{"role": "user", "content": prompt}],
                    modalities=["image", "text"])
                refs = _extract_image_refs(resp.choices[0].message.content)
                if not refs:
                    return {"ok": False, "error": "已连通但没返回图片（该模型可能不支持文生图）"}
                fmt = "URL" if refs[0].startswith("http") else "base64"
                # refs[0] 本身就是可直接当 <img src> 用的 data URL 或 http URL
                return {"ok": True, "model": model, "api": "chat 多模态", "fmt": fmt,
                        "image": refs[0]}
            except Exception as e:
                if not _is_modalities_unsupported(e):
                    return {"ok": False, "error": str(e)[:160]}
        resp = client.images.generate(model=model, prompt=prompt, n=1)
        d = (resp.data or [None])[0]
        b64 = getattr(d, "b64_json", None) if d else None
        url = getattr(d, "url", None) if d else None
        if not (b64 or url):
            return {"ok": False, "error": "已连通但没返回图片（b64_json/url 均空）"}
        image = ("data:image/png;base64," + b64) if b64 else url
        return {"ok": True, "model": model, "api": "Images API",
                "fmt": "b64_json" if b64 else "URL", "image": image}
    except Exception as e:
        return {"ok": False, "error": str(e)[:160]}


def _do_test_feishu() -> dict:
    """验证飞书凭证 + 顺手拉通讯录，让用户在页面里直接选「通知接收人」。
    一步同时解决：① 凭证连通验证 ② feishu_user_id 没配全的缺口。"""
    from redbeacon import config as cfg
    from redbeacon.services.feishu_api import FeishuAPI
    app_id     = cfg.get("feishu_app_id") or ""
    app_secret = cfg.get("feishu_app_secret") or ""
    if not app_id or not app_secret:
        return {"ok": False, "error": "App ID / Secret 还没填全"}
    try:
        FeishuAPI.verify_credentials(app_id, app_secret)
    except Exception as e:
        return {"ok": False, "error": str(e)[:160]}
    # 凭证通过 → 拉通讯录给用户选接收人；拉不到（多半没开 contact 权限）不算失败，给提示走手填
    users: list = []
    note = ""
    try:
        feishu = FeishuAPI(app_id, app_secret, "", "")
        users = feishu.list_contact_users() or []
    except Exception as e:
        note = "凭证已通过，但拉不到通讯录（多半是没开 contact:user:readonly 权限）：" + str(e)[:120]
    return {"ok": True, "msg": "凭证验证通过，选一个接收通知的人",
            "users": users, "current": cfg.get("feishu_user_id") or "", "note": note}


def _do_test_proxy() -> dict:
    from redbeacon import config as cfg
    from redbeacon.services import proxy_service
    if not (cfg.get("proxy_api_url") or "").strip():
        return {"ok": False, "error": "代理 API 地址还没填"}
    try:
        proxy = proxy_service.fetch_fresh_proxy()
    except Exception as e:
        return {"ok": False, "error": str(e)[:160]}
    if not proxy:
        return {"ok": False, "error": "代理 API 没返回可用 IP（检查地址 / 套餐余额）"}
    return {"ok": True, "msg": f"取到可用 IP：{proxy}"}


def _save_config_fields(fields: dict) -> list[str]:
    """把页面提交的配置字段写进本地库；空值不覆盖（避免误清已配置的密钥）。
    只接受白名单 key，返回实际写入的 key 列表。"""
    from redbeacon import config as cfg
    allow = {"ai_api_key", "ai_base_url", "ai_model", "image_model",
             "feishu_app_id", "feishu_app_secret", "feishu_user_id", "proxy_api_url"}
    written: list[str] = []
    for k, v in (fields or {}).items():
        if k not in allow:
            continue
        v = (v or "").strip()
        if not v:
            continue  # 留空 = 保持原值不动（密钥已配过时尤其重要）
        cfg.set(k, v)
        written.append(k)
    return written


def _setup(args) -> None:
    from redbeacon.services.feishu_api import permissions_json
    state = _setup_state()
    html = _SETUP_HTML.replace("__DATA__", json.dumps(state, ensure_ascii=False)) \
                      .replace("__FOOTER__", _UI_FOOTER) \
                      .replace("__PERMS_JSON__", permissions_json())

    touched: set[str] = set()
    finished = threading.Event()
    port = _free_port()

    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *a):
            pass

        def _json(self, code, obj):
            body = json.dumps(obj, ensure_ascii=False).encode("utf-8")
            self.send_response(code)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def do_GET(self):
            if self.path in ("/", "/index.html"):
                body = html.encode("utf-8")
                self.send_response(200)
                self.send_header("Content-Type", "text/html; charset=utf-8")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)
            else:
                self.send_response(404); self.end_headers()

        def do_POST(self):
            length = int(self.headers.get("Content-Length", 0))
            raw = self.rfile.read(length) if length else b"{}"
            try:
                payload = json.loads(raw.decode("utf-8"))
            except Exception:
                payload = {}
            fields = payload.get("fields", {})

            # 任何处理异常都回成 JSON 错误，绝不让连接断成前端的 "Failed to fetch"
            try:
                if self.path == "/save":
                    touched.update(_save_config_fields(fields))
                    self._json(200, {"ok": True})
                elif self.path == "/save-test-ai":
                    touched.update(_save_config_fields(fields))
                    self._json(200, _do_test_ai())
                elif self.path == "/save-test-image":
                    touched.update(_save_config_fields(fields))
                    self._json(200, _do_test_image())
                elif self.path == "/save-test-feishu":
                    touched.update(_save_config_fields(fields))
                    self._json(200, _do_test_feishu())
                elif self.path == "/save-test-proxy":
                    touched.update(_save_config_fields(fields))
                    self._json(200, _do_test_proxy())
                elif self.path == "/done":
                    touched.update(_save_config_fields(fields))
                    self._json(200, {"ok": True})
                    finished.set()
                else:
                    self.send_response(404); self.end_headers()
            except Exception as e:
                try:
                    self._json(200, {"ok": False, "error": str(e)[:200]})
                except Exception:
                    pass

    # 多线程：测连通（尤其测图约 20s）在各自线程里跑，不阻塞页面其它请求
    httpd = ThreadingHTTPServer(("127.0.0.1", port), Handler)
    httpd.daemon_threads = True
    server_thread = threading.Thread(target=httpd.serve_forever, daemon=True)
    server_thread.start()

    url = f"http://127.0.0.1:{port}/"
    if sys.platform == "darwin":
        subprocess.Popen(["open", url])
    elif sys.platform.startswith("linux"):
        subprocess.Popen(["xdg-open", url])
    print(json.dumps({"status": "ui_opened", "url": url,
                      "msg": "已打开安装向导页：填 AI 和飞书凭证、每项可点「测连通」，"
                             "弄好点「完成」。密钥只写本地、不进对话。"}, ensure_ascii=False))
    sys.stdout.flush()

    finished.wait(timeout=_TIMEOUT_SEC)
    httpd.shutdown()
    httpd.server_close()

    # 收尾汇报：只回「配好了哪些」的布尔态，绝不回传任何密钥明文给对话
    final = _setup_state()
    out({
        "finished": finished.is_set(),
        "timed_out": not finished.is_set(),
        "configured": {
            "ai_key": final["ai"]["has_key"],
            "ai_base_url": bool(final["ai"]["base_url"]),
            "text_model": bool(final["ai"]["text_model"]),
            "image_model": bool(final["ai"]["image_model"]),
            "feishu_app_id": bool(final["feishu"]["app_id"]),
            "feishu_app_secret": final["feishu"]["has_secret"],
            "feishu_user_id": bool(final["feishu"]["user_id"]),
            "proxy": final["proxy"]["has_url"],
        },
        "touched": sorted(touched),
    })


# ── 读取账号全貌 ──────────────────────────────────────────────────────────────

def _load_state(account_id: int) -> dict:
    acc = account_row(account_id)
    with database.cursor() as c:
        srow = c.execute(
            "SELECT data FROM strategy WHERE account_id=? ORDER BY version DESC LIMIT 1",
            (account_id,),
        ).fetchone()
        types = c.execute(
            "SELECT name, prompt_template FROM content_type WHERE account_id=? ORDER BY sort_order, id",
            (account_id,),
        ).fetchall()
        img = c.execute(
            "SELECT mode, card_theme, prompt_template, ai_model, reference_images FROM image_strategy WHERE account_id=?",
            (account_id,),
        ).fetchone()
        topic_stats = c.execute(
            "SELECT COUNT(*) AS total, SUM(CASE WHEN is_used=0 THEN 1 ELSE 0 END) AS unused "
            "FROM topic WHERE account_id=?",
            (account_id,),
        ).fetchone()
    strategy = {}
    if srow:
        try:
            strategy = json.loads(srow["data"] or "{}")
        except Exception:
            strategy = {}

    def _fmt(v):
        return "\n".join(v) if isinstance(v, list) else (v or "")

    # 定位：库里有值用库里的，空则用兜底默认（绝不留空）
    strat_out = {}
    for k, _label, _ml, _grp, default in _STRATEGY_FIELDS:
        v = _fmt(strategy.get(k, "")).strip()
        v = v if v else default
        # 下拉字段：库里若是旧的自由文本（不在选项里），回落默认档，保证下拉有选中
        if k in _STRATEGY_CHOICES and v not in _STRATEGY_CHOICES[k]:
            v = default
        strat_out[k] = v
    # 全局文案提示词（账号级，所有内容类型通用；改一次即可）
    strat_out["copy_guide"] = (strategy.get("copy_guide") or "").strip()
    # 把"系统母模板/参考图指令"也亮出来给用户改（覆盖式）：没改过就显示内置默认值
    from redbeacon.tasks.generate import DEFAULT_PROMPT, DEFAULT_REF_INSTRUCTION
    strat_out["copy_template"] = strategy.get("copy_template") or DEFAULT_PROMPT
    strat_out["ref_instruction"] = strategy.get("ref_instruction") or DEFAULT_REF_INSTRUCTION

    # 文案风格：每类内容；prompt_template 空则填人话默认（让用户看得见、可改）
    ct_out = []
    for t in types:
        tpl = (t["prompt_template"] or "").strip()
        default = _CT_DEFAULT_BY_NAME.get(t["name"], _CT_DEFAULT_PROMPT)
        ct_out.append({"name": t["name"],
                       "prompt_template": tpl if tpl else default})

    # 配图：库里有值用库里的，空则兜底默认
    img_out = dict(_IMG_DEFAULTS)
    if img:
        for k in ("mode", "card_theme", "prompt_template", "ai_model"):
            v = (img[k] or "").strip() if img[k] else ""
            if v:
                img_out[k] = v
        try:
            refs = json.loads(img["reference_images"] or "[]")
            img_out["reference_images"] = refs if isinstance(refs, list) else []
        except Exception:
            img_out["reference_images"] = []
    # 卡片配色：库里若是无效值（如历史脏数据 cool），兜底回「默认」，保证下拉一定有选中
    _valid_themes = {t for t, _ in _CARD_THEME_LABELS}
    if img_out.get("card_theme") not in _valid_themes:
        img_out["card_theme"] = "default"

    from redbeacon import config as cfg
    text_model = cfg.get("ai_model") or ""        # 全局：写文案用的模型
    image_model_global = cfg.get("image_model") or ""

    return {
        "account_id": account_id,
        "display_name": acc.get("display_name") or f"redbeacon-{account_id}",
        "strategy": strat_out,
        "content_types": ct_out,
        "image": img_out,
        "text_model": text_model,
        # 账号配图模型为空时退回全局，供下拉默认选中
        "image_model": img_out.get("ai_model") or image_model_global,
        "models": _list_models(),
        "topics_unused": (topic_stats["unused"] or 0) if topic_stats else 0,
        "topics_total": (topic_stats["total"] or 0) if topic_stats else 0,
    }


# ── 落库（只写传回来的、且确有变化的字段）──────────────────────────────────────

# 这些定位字段在库里以数组存储，页面用换行分隔，回写时拆回数组
_LIST_FIELDS = {"pain_points"}


def _apply(account_id: int, before: dict, submitted: dict) -> dict:
    changed: dict = {"strategy": [], "content_types": [], "image": [], "config": []}
    now = now_iso()

    # 全局写文案模型（顶层 config.ai_model）——空字符串不覆盖，避免误清
    from redbeacon import config as cfg
    sub_cfg = submitted.get("config", {})
    new_text_model = (sub_cfg.get("ai_model") or "").strip()
    if new_text_model and new_text_model != (before.get("text_model") or ""):
        cfg.set("ai_model", new_text_model)
        changed["config"].append("ai_model")

    new_strat = submitted.get("strategy", {})
    valid_keys = {f[0] for f in _STRATEGY_FIELDS} | {"copy_guide", "copy_template", "ref_instruction"}
    diff_strat = {k: v for k, v in new_strat.items()
                  if k in valid_keys and v != before["strategy"].get(k, "")}
    if diff_strat:
        with database.cursor(commit=True) as c:
            row = c.execute(
                "SELECT id, data FROM strategy WHERE account_id=? ORDER BY version DESC LIMIT 1",
                (account_id,),
            ).fetchone()
            data = {}
            if row:
                try:
                    data = json.loads(row["data"] or "{}")
                except Exception:
                    data = {}
            for k, v in diff_strat.items():
                if k in _LIST_FIELDS:
                    data[k] = [ln.strip() for ln in v.splitlines() if ln.strip()]
                else:
                    data[k] = v
            if row is None:
                c.execute(
                    "INSERT INTO strategy (account_id, version, data, niche, posting_freq, created_at, updated_at) "
                    "VALUES (?, 1, ?, ?, '', ?, ?)",
                    (account_id, json.dumps(data, ensure_ascii=False), data.get("niche", ""), now, now),
                )
            else:
                c.execute(
                    "UPDATE strategy SET data=?, niche=?, updated_at=? WHERE id=?",
                    (json.dumps(data, ensure_ascii=False), data.get("niche", ""), now, row["id"]),
                )
        changed["strategy"] = list(diff_strat.keys())

    before_ct = {c["name"]: c["prompt_template"] for c in before["content_types"]}
    for ct in submitted.get("content_types", []):
        name = ct.get("name")
        tpl = ct.get("prompt_template", "")
        if name in before_ct and tpl != before_ct[name]:
            with database.cursor(commit=True) as c:
                c.execute(
                    "UPDATE content_type SET prompt_template=?, updated_at=? WHERE account_id=? AND name=?",
                    (tpl, now, account_id, name),
                )
            changed["content_types"].append(name)

    new_img = submitted.get("image", {})
    img_diff = {}
    for k in ("mode", "card_theme", "prompt_template", "ai_model"):
        if k in new_img and new_img[k] != before["image"].get(k, ""):
            if k == "mode" and new_img[k] not in _VALID_MODES:
                continue
            img_diff[k] = new_img[k]
    if img_diff:
        with database.cursor(commit=True) as c:
            row = c.execute("SELECT account_id FROM image_strategy WHERE account_id=?",
                            (account_id,)).fetchone()
            if row is None:
                c.execute(
                    "INSERT INTO image_strategy (account_id, mode, prompt_template, card_theme, "
                    "reference_images, ai_model, updated_at) VALUES (?, 'cards', '', 'default', '[]', NULL, ?)",
                    (account_id, now),
                )
            sets = ", ".join(f"{k}=?" for k in img_diff)
            c.execute(f"UPDATE image_strategy SET {sets}, updated_at=? WHERE account_id=?",
                      list(img_diff.values()) + [now, account_id])
        changed["image"] = list(img_diff.keys())

    return changed


# ── 一键生成预览（不消耗选题、落库、配图按设定、不推飞书）──────────────────────

def _pick_preview_topic(account_id: int) -> str:
    """挑一条未用选题的文本作为预览素材；不标记已用（不消耗）。
    选题库为空时返回一个合成选题——确保始终走 topic_override 路径，绝不消耗选题库。"""
    with database.cursor() as c:
        row = c.execute(
            "SELECT content FROM topic WHERE account_id=? AND is_used=0 ORDER BY id LIMIT 1",
            (account_id,),
        ).fetchone()
        if row:
            return row["content"]
        # 没有选题：用赛道名合成一个，避免 run_generate 回落到会消耗选题的取题逻辑
        srow = c.execute(
            "SELECT data FROM strategy WHERE account_id=? ORDER BY version DESC LIMIT 1",
            (account_id,),
        ).fetchone()
    niche = "这个领域"
    if srow:
        try:
            niche = json.loads(srow["data"] or "{}").get("niche") or niche
        except Exception:
            pass
    return f"新手如何入门{niche}"


def _generate_preview(account_id: int) -> dict:
    """生成一篇并落库；返回 {content_id, title, body, tags, images}。"""
    from redbeacon.tasks import generate as gen_mod

    topic = _pick_preview_topic(account_id)  # 始终非空 → 走 topic_override，不消耗选题库
    # 预览不推飞书：临时旁路 _push_to_feishu
    orig_push = gen_mod._push_to_feishu
    gen_mod._push_to_feishu = lambda *a, **k: None
    try:
        content_id = gen_mod.run_generate(
            account_id=account_id,
            topic_override=topic,   # None 时 run_generate 会自己从库里取（极端兜底）
            image_mode=None,        # None = 用账号 image_strategy 的设定
        )
    finally:
        gen_mod._push_to_feishu = orig_push

    with database.cursor() as c:
        row = c.execute("SELECT title, body, tags, images FROM content_queue WHERE id=?",
                        (content_id,)).fetchone()
        imode_row = c.execute("SELECT mode FROM image_strategy WHERE account_id=?",
                              (account_id,)).fetchone()
    def _arr(x):
        try:
            return json.loads(x) if x else []
        except Exception:
            return []
    images = _arr(row["images"]) if row else []
    # 按文件名分类：AI 封面 vs 文字卡片，好让前端说清"配图方式有没有真生效"
    ai_imgs = [p for p in images if "ai_image" in p.rsplit("/", 1)[-1].lower()]
    card_imgs = [p for p in images if p not in ai_imgs]
    mode = (imode_row["mode"] if imode_row else "cards") or "cards"
    want_ai = mode in ("ai", "both")
    if want_ai and not ai_imgs:
        note = "⚠️ 选了 AI 配图，但这次没生成出封面（多半是画图模型无效/额度问题）——换个「用哪个 AI 画图」再试。"
    else:
        bits = []
        if ai_imgs:   bits.append(f"AI 封面 {len(ai_imgs)} 张")
        if card_imgs: bits.append(f"文字卡片 {len(card_imgs)} 张")
        note = "本次配图：" + ("、".join(bits) if bits else "无")
    return {
        "content_id": content_id,
        "topic": topic or "(自动选题)",
        "title": row["title"] if row else "",
        "body": row["body"] if row else "",
        "tags": _arr(row["tags"]) if row else [],
        "images": images,
        "image_note": note,
    }


# ── 最终提示词预览（拼出实际发给 AI 的完整文案/图片提示词，只读展示）─────────────

def _final_prompts(account_id: int, submitted: dict | None) -> dict:
    """按当前面板设定（含未保存的编辑）拼出最终提示词，不落库。与 generate 同源。"""
    from redbeacon.tasks.generate import build_filled_prompt, build_cover_prompt
    submitted = submitted or {}
    base = _load_state(account_id)

    # 完整定位：DB 里的全字段（含面板不暴露的 content_pillars/forbidden_words）+ 覆盖面板的编辑
    with database.cursor() as c:
        srow = c.execute(
            "SELECT data FROM strategy WHERE account_id=? ORDER BY version DESC LIMIT 1",
            (account_id,)).fetchone()
        trow = c.execute(
            "SELECT content FROM topic WHERE account_id=? AND is_used=0 ORDER BY id LIMIT 1",
            (account_id,)).fetchone()
    strat = {}
    if srow:
        try:
            strat = json.loads(srow["data"] or "{}")
        except Exception:
            strat = {}
    for k, v in (submitted.get("strategy") or {}).items():
        strat[k] = [ln.strip() for ln in v.splitlines() if ln.strip()] if k in _LIST_FIELDS else v

    sub_cts = submitted.get("content_types") or []
    if sub_cts:
        ct_name, ct_guide = sub_cts[0]["name"], sub_cts[0].get("prompt_template", "")
    elif base["content_types"]:
        ct_name = base["content_types"][0]["name"]
        ct_guide = base["content_types"][0].get("prompt_template", "")
    else:
        ct_name, ct_guide = "通用", ""

    img_cfg = dict(base["image"])
    if "prompt_template" in (submitted.get("image") or {}):
        img_cfg["prompt_template"] = submitted["image"]["prompt_template"]

    sample = trow["content"] if trow else "新手如何快速入门"
    return {
        "content_type": ct_name,
        "sample_topic": sample,
        # 用户在面板里改过的母模板/参考图指令都会经 strat 透传，保证"看到=实际发送"
        "text_prompt": build_filled_prompt(strat, sample, ct_name, ct_guide,
                                           prompt_template=strat.get("copy_template") or None),
        "image_prompt": build_cover_prompt(strat, img_cfg, sample),
    }


# ── 参考图上传/清除（面板里收浏览器传来的 data URL，落盘到数据目录）──────────────

def _save_ref_from_dataurl(account_id: int, data_url: str) -> list:
    import base64, time as _t, re as _re
    from redbeacon.routers.strategy import _ref_dir, _get_ref_list, _ensure_image_strategy
    if not data_url or "," not in data_url:
        raise ValueError("没收到图片数据")
    header, b64 = data_url.split(",", 1)
    ext = ".png" if "png" in header else (".webp" if "webp" in header else ".jpg")
    data = base64.b64decode(_re.sub(r"\s", "", b64))
    dest = _ref_dir() / f"ref_{account_id}_{int(_t.time()*1000)}{ext}"
    dest.write_bytes(data)
    with database.cursor(commit=True) as c:
        _ensure_image_strategy(c, account_id)
        refs = _get_ref_list(c, account_id)
        refs.append(str(dest))
        c.execute("UPDATE image_strategy SET reference_images=?, updated_at=? WHERE account_id=?",
                  (json.dumps(refs, ensure_ascii=False), now_iso(), account_id))
    return refs


def _clear_refs(account_id: int) -> None:
    import os
    from redbeacon.routers.strategy import _get_ref_list
    with database.cursor(commit=True) as c:
        refs = _get_ref_list(c, account_id)
        for p in refs:
            try:
                if p and os.path.isfile(p):
                    os.remove(p)
            except Exception:
                pass
        c.execute("UPDATE image_strategy SET reference_images='[]', updated_at=? WHERE account_id=?",
                  (now_iso(), account_id))


def _remove_ref(account_id: int, index: int) -> list:
    import os
    from redbeacon.routers.strategy import _get_ref_list
    with database.cursor(commit=True) as c:
        refs = _get_ref_list(c, account_id)
        if 0 <= index < len(refs):
            p = refs.pop(index)
            try:
                if p and os.path.isfile(p):
                    os.remove(p)
            except Exception:
                pass
        c.execute("UPDATE image_strategy SET reference_images=?, updated_at=? WHERE account_id=?",
                  (json.dumps(refs, ensure_ascii=False), now_iso(), account_id))
    return refs


# ── 一次性本地服务 ────────────────────────────────────────────────────────────

def _free_port() -> int:
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.bind(("127.0.0.1", 0))
    port = s.getsockname()[1]
    s.close()
    return port


def _account(args) -> None:
    require_account(args.account_id)
    out(_serve_account_panel(args.account_id))


def _serve_account_panel(account_id: int, announce: bool = True) -> dict:
    """起一个一次性本地服务渲染「账号内容调试面板」，阻塞到用户点完成/超时，返回改动汇总。
    被 `ui account`（单账号命令）和 `ui manage`（Pro 多账号管理台，在线程里起独立面板）共用。
    announce=False 时不往 stdout 打 ui_opened（管理台在子线程里起面板，避免污染主命令输出）。"""
    require_account(account_id)
    state = _load_state(account_id)
    html = _render_html(state)

    all_changed: dict = {"strategy": set(), "content_types": set(), "image": set(), "config": set()}
    finished = threading.Event()
    port = _free_port()

    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *a):
            pass

        def _json(self, code, obj):
            body = json.dumps(obj, ensure_ascii=False).encode("utf-8")
            self.send_response(code)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def do_GET(self):
            if self.path in ("/", "/index.html"):
                body = html.encode("utf-8")
                self.send_response(200)
                self.send_header("Content-Type", "text/html; charset=utf-8")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)
            elif self.path.startswith("/img?"):
                self._serve_image()
            elif self.path.startswith("/theme-preview"):
                self._serve_theme_preview()
            else:
                self.send_response(404); self.end_headers()

        def _serve_theme_preview(self):
            from urllib.parse import urlparse, parse_qs
            from pathlib import Path as _P
            q = parse_qs(urlparse(self.path).query)
            name = (q.get("name", [""])[0] or "")
            valid = {t for t, _ in _CARD_THEME_LABELS}
            if name not in valid or name == "random":
                self.send_response(404); self.end_headers(); return
            f = _P(__file__).resolve().parent.parent / "assets" / "theme_previews" / f"{name}.png"
            if not f.is_file():
                self.send_response(404); self.end_headers(); return
            data = f.read_bytes()
            self.send_response(200)
            self.send_header("Content-Type", "image/png")
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)

        def _serve_image(self):
            from urllib.parse import urlparse, parse_qs, unquote
            import os
            q = parse_qs(urlparse(self.path).query)
            path = unquote(q.get("p", [""])[0])
            # 只允许读数据目录下的图片
            from ._runtime import DATA_DIR
            real = os.path.realpath(path)
            if not real.startswith(os.path.realpath(DATA_DIR)) or not os.path.isfile(real):
                self.send_response(404); self.end_headers(); return
            ext = real.rsplit(".", 1)[-1].lower()
            ctype = {"png": "image/png", "jpg": "image/jpeg", "jpeg": "image/jpeg"}.get(ext, "application/octet-stream")
            with open(real, "rb") as f:
                data = f.read()
            self.send_response(200)
            self.send_header("Content-Type", ctype)
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)

        def do_POST(self):
            length = int(self.headers.get("Content-Length", 0))
            raw = self.rfile.read(length) if length else b"{}"
            try:
                payload = json.loads(raw.decode("utf-8"))
            except Exception:
                payload = {}

            if self.path == "/save":
                # 用最新库状态做 diff 基准，支持反复保存
                base = _load_state(account_id)
                changed = _apply(account_id, base, payload)
                for k in all_changed:
                    all_changed[k].update(changed[k])
                self._json(200, {"ok": True, "changed": changed})

            elif self.path == "/preview":
                # 先把当前页面的改动落库，再用最新设定生成
                base = _load_state(account_id)
                changed = _apply(account_id, base, payload)
                for k in all_changed:
                    all_changed[k].update(changed[k])
                try:
                    result = _generate_preview(account_id)
                    self._json(200, {"ok": True, "preview": result})
                except Exception as e:
                    self._json(200, {"ok": False, "error": str(e)})

            elif self.path == "/final-prompts":
                try:
                    self._json(200, {"ok": True, **_final_prompts(account_id, payload)})
                except Exception as e:
                    self._json(200, {"ok": False, "error": str(e)})

            elif self.path == "/upload-ref":
                # 浏览器把参考图读成 data URL 传来 → 落盘到数据目录、登记给账号
                try:
                    refs = _save_ref_from_dataurl(account_id, payload.get("data_url", ""))
                    all_changed["image"].add("reference_images")
                    self._json(200, {"ok": True, "reference_images": refs})
                except Exception as e:
                    self._json(200, {"ok": False, "error": str(e)})

            elif self.path == "/clear-ref":
                try:
                    _clear_refs(account_id)
                    all_changed["image"].add("reference_images")
                    self._json(200, {"ok": True, "reference_images": []})
                except Exception as e:
                    self._json(200, {"ok": False, "error": str(e)})

            elif self.path == "/remove-ref":
                try:
                    refs = _remove_ref(account_id, int(payload.get("index", -1)))
                    all_changed["image"].add("reference_images")
                    self._json(200, {"ok": True, "reference_images": refs})
                except Exception as e:
                    self._json(200, {"ok": False, "error": str(e)})

            elif self.path == "/done":
                base = _load_state(account_id)
                changed = _apply(account_id, base, payload)
                for k in all_changed:
                    all_changed[k].update(changed[k])
                self._json(200, {"ok": True})
                finished.set()
            else:
                self.send_response(404); self.end_headers()

    # 多线程：试生成/上传参考图等慢请求各跑各的，不阻塞页面（避免单线程下 "Failed to fetch"）
    httpd = ThreadingHTTPServer(("127.0.0.1", port), Handler)
    httpd.daemon_threads = True
    server_thread = threading.Thread(target=httpd.serve_forever, daemon=True)
    server_thread.start()

    url = f"http://127.0.0.1:{port}/"
    if sys.platform == "darwin":
        subprocess.Popen(["open", url])
    elif sys.platform.startswith("linux"):
        subprocess.Popen(["xdg-open", url])
    if announce:
        print(json.dumps({"status": "ui_opened", "url": url,
                          "msg": "已打开账号配置面板：左边看配置改配置，右边可生成一篇预览看效果，"
                                 "弄好点「完成返回对话」"}, ensure_ascii=False))
        sys.stdout.flush()

    finished.wait(timeout=_TIMEOUT_SEC)
    httpd.shutdown()
    httpd.server_close()

    changed_out = {k: sorted(v) for k, v in all_changed.items()}
    any_change = any(changed_out.values())
    return {
        "finished": finished.is_set(),
        "timed_out": not finished.is_set(),
        "account_id": account_id,
        "changed": changed_out,
        "any_change": any_change,
    }


# ── 选题库面板（ui topics）：勾选选题 → 点写成文案 → 逐篇生成并入飞书 ──────────
#
# 「写文案」的可视化入口：把账号未用选题摆成可勾选清单（按内容类型分组），
# 用户勾几条点「写成文案」，后端对每条调 run_generate（内部会自动推飞书审核表）、
# 并把该选题标记已用。和对话版「列编号挑题」是同一件事的两种操作方式，由 skill 在
# 「写文案」时给用户二选一（网页 / 对话）。服务一次性，命令结束即退（无常驻）。

def _load_topics(account_id: int) -> list[dict]:
    """取该账号未用选题，按内容类型分组前的扁平列表（含 note 作为「本篇想法」钩子）。"""
    with database.cursor() as c:
        rows = c.execute(
            "SELECT id, content_type, content, note FROM topic "
            "WHERE account_id=? AND is_used=0 ORDER BY content_type, id",
            (account_id,),
        ).fetchall()
    return [dict(r) for r in rows]


def _render_topics_html(account_id: int, topics: list[dict]) -> str:
    import html as _h
    from collections import OrderedDict

    acc = account_row(account_id)
    name = (acc["display_name"] if acc and acc["display_name"] else None) or f"{account_id}号小红书"

    groups: "OrderedDict[str, list]" = OrderedDict()
    for t in topics:
        groups.setdefault(t["content_type"] or "其它", []).append(t)

    if topics:
        rows_html = ""
        for ctype, items in groups.items():
            rows_html += f'<div class="grp">{_h.escape(ctype)} <span class="gc">{len(items)} 条</span></div>'
            for t in items:
                note = (t.get("note") or "").strip()
                hook = f'<div class="hook">💡 {_h.escape(note)}</div>' if note else ""
                rows_html += (
                    f'<label class="row" data-id="{t["id"]}">'
                    f'<input type="checkbox" class="cb" value="{t["id"]}">'
                    f'<span class="body"><span class="ct">{_h.escape(t["content"])}</span>{hook}'
                    f'<span class="st"></span></span></label>'
                )
    else:
        rows_html = ('<div class="empty">选题库空了 —— 先去补一批选题再来写。'
                     '回到对话里说「补选题」就行。</div>')

    return _TOPICS_HTML_TMPL.replace("__NAME__", _h.escape(name)) \
        .replace("__ROWS__", rows_html) \
        .replace("__TOTAL__", str(len(topics))) \
        .replace("__FOOTER__", _UI_FOOTER)


_TOPICS_HTML_TMPL = """<!doctype html><html lang="zh"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>选题库 · 写文案</title>
<style>
:root{--red:#ff2442;--ink:#1f2329;--mut:#8a9099;--line:#eceef1;--bg:#f6f7f9}
*{box-sizing:border-box}
body{margin:0;font:15px/1.6 -apple-system,BlinkMacSystemFont,"PingFang SC","Microsoft YaHei",sans-serif;color:var(--ink);background:var(--bg)}
.wrap{max-width:760px;margin:0 auto;padding:20px 16px 120px}
.hd{position:sticky;top:0;background:var(--bg);padding:8px 0 12px;z-index:5}
.hd h1{font-size:19px;margin:0 0 4px}
.hd p{margin:0;color:var(--mut);font-size:13px}
.grp{margin:18px 0 8px;font-weight:600;color:#5b616a;font-size:13px}
.grp .gc{color:var(--mut);font-weight:400}
.row{display:flex;gap:11px;align-items:flex-start;padding:12px 14px;background:#fff;border:1px solid var(--line);border-radius:12px;margin-bottom:8px;cursor:pointer;transition:border-color .15s}
.row:hover{border-color:#d6dadf}
.row.sel{border-color:var(--red);background:#fff5f6}
.row.done{opacity:.6}
.cb{margin-top:4px;width:17px;height:17px;accent-color:var(--red);flex:0 0 auto;cursor:pointer}
.body{flex:1;min-width:0}
.ct{display:block}
.hook{color:var(--mut);font-size:13px;margin-top:2px}
.st{font-size:13px;font-weight:600}
.st.ok{color:#13a463}.st.bad{color:var(--red)}.st.run{color:var(--mut)}
.empty{padding:40px 16px;text-align:center;color:var(--mut);background:#fff;border:1px dashed var(--line);border-radius:12px}
.bar{position:fixed;left:0;right:0;bottom:0;background:#fff;border-top:1px solid var(--line);padding:12px 16px;display:flex;gap:10px;align-items:center;justify-content:space-between}
.bar .cnt{color:var(--mut);font-size:14px}
.bar .cnt b{color:var(--ink)}
.btns{display:flex;gap:10px}
button{font:inherit;border:none;border-radius:10px;padding:10px 18px;cursor:pointer;font-weight:600}
.primary{background:var(--red);color:#fff}
.primary:disabled{background:#f3b9c1;cursor:not-allowed}
.ghost{background:#f0f1f3;color:var(--ink)}
.tip{max-width:760px;margin:0 auto;padding:0 16px;color:var(--mut);font-size:12px}
</style></head><body>
<div class="wrap">
  <div class="hd"><h1>选题库 · 写文案</h1><p>账号「__NAME__」 · 勾选要写的选题，点「写成文案」逐篇生成并送进飞书审核表</p></div>
  <div id="list">__ROWS__</div>
  __FOOTER__
</div>
<div class="tip" id="tip"></div>
<div class="bar">
  <div class="cnt">已选 <b id="cnt">0</b> 条</div>
  <div class="btns">
    <button class="ghost" id="done">完成返回对话</button>
    <button class="primary" id="go" disabled>写成文案 →</button>
  </div>
</div>
<script>
let running=false, made=[];
function rows(){return [...document.querySelectorAll('.row')]}
function selected(){return rows().filter(r=>r.querySelector('.cb')&&r.querySelector('.cb').checked)}
function refresh(){
  rows().forEach(r=>{const cb=r.querySelector('.cb'); if(cb) r.classList.toggle('sel',cb.checked)});
  const n=selected().length;
  document.getElementById('cnt').textContent=n;
  document.getElementById('go').disabled=(n===0||running);
}
document.getElementById('list').addEventListener('change',refresh);
async function genOne(row){
  const id=+row.dataset.id;
  const st=row.querySelector('.st'); st.className='st run'; st.textContent=' · 正在写…';
  try{
    const r=await fetch('/generate-one',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({topic_id:id})});
    const j=await r.json();
    if(j.ok){st.className='st ok';st.textContent=' · ✓ 已写好，进飞书了';row.classList.add('done');made.push(j.content_id);}
    else{st.className='st bad';st.textContent=' · ✗ '+(j.error||'失败');}
    return j.ok;
  }catch(e){st.className='st bad';st.textContent=' · ✗ '+e;return false;}
}
document.getElementById('go').addEventListener('click',async()=>{
  if(running)return; const sel=selected(); if(!sel.length)return;
  running=true; refresh();
  document.getElementById('go').textContent='写作中…';
  document.getElementById('done').disabled=true;                 // 写作途中别让点「完成」把服务掐断、丢掉在写的那篇
  document.querySelectorAll('.cb').forEach(c=>c.disabled=true);
  let ok=0;
  for(const row of sel){const cb=row.querySelector('.cb'); cb.checked=false; if(await genOne(row))ok++;}
  running=false;
  document.getElementById('go').textContent='写成文案 →';
  document.getElementById('done').disabled=false;
  document.querySelectorAll('.row:not(.done) .cb').forEach(c=>c.disabled=false);  // 没写过的重新可勾，支持接着写下一批
  document.getElementById('tip').textContent='这批写好 '+ok+' 篇，已送进飞书审核表。可以继续勾选写下一批，或点「完成返回对话」。';
  refresh();
});
document.getElementById('done').addEventListener('click',async()=>{
  document.getElementById('done').disabled=true;
  try{await fetch('/done',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({})});}catch(e){}
  document.getElementById('tip').textContent='已写 '+made.length+' 篇，可以关掉这个页面回到对话了。';
});
refresh();
</script></body></html>"""


def _topics(args) -> None:
    require_account(args.account_id)
    # 写文案要调 AI，没配齐就别弹个点了全 ✗ 的空面板——直接挡在门口、指去配置
    from redbeacon import config as cfg
    missing = [k for k in ("ai_api_key", "ai_base_url", "ai_model") if not (cfg.get(k) or "").strip()]
    if missing:
        err("AI 还没配齐，没法写文案——先把 AI（接口地址 / Key / 文案模型）配好再来。",
            next="redbeacon config", kind="AI_NOT_READY")
    out(_serve_topics_panel(args.account_id))


def _serve_topics_panel(account_id: int, announce: bool = True) -> dict:
    """起一个一次性本地服务渲染「选题库写文案面板」，阻塞到用户点完成/超时。
    /generate-one：对单条选题生成（内部自动推飞书）+ 标记已用；返回累计写了哪几篇。"""
    require_account(account_id)
    topics = _load_topics(account_id)
    html = _render_topics_html(account_id, topics)

    made: list[int] = []
    finished = threading.Event()
    last_activity = [time.time()]   # 空闲超时基准；每次 POST 刷新（见下）
    port = _free_port()

    def _gen_one(topic_id: int) -> dict:
        from redbeacon.tasks.generate import run_generate
        with database.cursor() as c:
            row = c.execute(
                "SELECT content, content_type, note FROM topic WHERE id=? AND account_id=? AND is_used=0",
                (topic_id, account_id),
            ).fetchone()
        if not row:
            return {"ok": False, "error": "选题不存在或已写过"}
        try:
            cid = run_generate(
                account_id=account_id,
                topic_override=row["content"],
                content_type_override=row["content_type"],
                image_mode=None,
                pillar_override=None,
                user_idea=(row["note"] or None),
            )
        except Exception as e:
            return {"ok": False, "error": str(e)[:140]}
        # --topic 路径不消耗库存，手动标记已用，避免重复写
        with database.cursor(commit=True) as c:
            c.execute("UPDATE topic SET is_used=1, used_at=? WHERE id=?", (now_iso(), topic_id))
        made.append(cid)
        return {"ok": True, "content_id": cid}

    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *a):
            pass

        def _json(self, code, obj):
            body = json.dumps(obj, ensure_ascii=False).encode("utf-8")
            self.send_response(code)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def do_GET(self):
            if self.path in ("/", "/index.html"):
                body = html.encode("utf-8")
                self.send_response(200)
                self.send_header("Content-Type", "text/html; charset=utf-8")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)
            else:
                self.send_response(404); self.end_headers()

        def do_POST(self):
            last_activity[0] = time.time()   # 有交互就刷新空闲计时
            length = int(self.headers.get("Content-Length", 0))
            raw = self.rfile.read(length) if length else b"{}"
            try:
                payload = json.loads(raw.decode("utf-8"))
            except Exception:
                payload = {}
            if self.path == "/generate-one":
                try:
                    self._json(200, _gen_one(int(payload.get("topic_id", 0))))
                except Exception as e:
                    self._json(200, {"ok": False, "error": str(e)[:140]})
            elif self.path == "/done":
                self._json(200, {"ok": True})
                finished.set()
            else:
                self.send_response(404); self.end_headers()

    httpd = ThreadingHTTPServer(("127.0.0.1", port), Handler)
    httpd.daemon_threads = True
    threading.Thread(target=httpd.serve_forever, daemon=True).start()

    url = f"http://127.0.0.1:{port}/"
    if sys.platform == "darwin":
        subprocess.Popen(["open", url])
    elif sys.platform.startswith("linux"):
        subprocess.Popen(["xdg-open", url])
    if announce:
        print(json.dumps({"status": "ui_opened", "url": url,
                          "msg": "已打开选题库面板：勾选要写的选题、点「写成文案」逐篇生成并送进飞书，"
                                 "弄完点「完成返回对话」"}, ensure_ascii=False))
        sys.stdout.flush()

    # 空闲超时（非总时长封顶）：选题面板要逐篇慢生成、可能批量写很久，
    # 用总时长封顶会把人写到一半掐断；改成"真静默 _TIMEOUT_SEC 才退"，写着就一直开。
    while not finished.wait(timeout=60):
        if time.time() - last_activity[0] > _TIMEOUT_SEC:
            break
    httpd.shutdown()
    httpd.server_close()

    return {
        "finished": finished.is_set(),
        "timed_out": not finished.is_set(),
        "account_id": account_id,
        "generated": len(made),
        "content_ids": made,
    }


# ── 运营看板（只读，一眼看全部账号）──────────────────────────────────────────

def _load_dashboard() -> dict:
    """聚合所有账号的运营态：在线状态、定位、审核表、内容数(按状态)、可用选题。
    全部字段已转人话，前端直接展示，不出现库字段/英文状态。"""
    from redbeacon.services import license as _lic

    accounts = []
    with database.cursor() as c:
        rows = c.execute(
            "SELECT id, display_name, nickname, login_status, last_login_check, proxy, "
            "feishu_app_token, feishu_table_id FROM account ORDER BY id"
        ).fetchall()
        for r in rows:
            aid = r["id"]
            niche_row = c.execute(
                "SELECT niche FROM strategy WHERE account_id=? AND niche IS NOT NULL "
                "ORDER BY version DESC, updated_at DESC LIMIT 1", (aid,)
            ).fetchone()
            counts = {"pending_review": 0, "published": 0, "failed": 0}
            for cr in c.execute(
                "SELECT status, COUNT(*) n FROM content_queue WHERE account_id=? GROUP BY status",
                (aid,),
            ):
                counts[cr["status"]] = cr["n"]
            # 孤儿（生成了没推进飞书）从待审里剔出来单独报，保证「待审 = 飞书可见」
            unpushed = c.execute(
                "SELECT COUNT(*) FROM content_queue WHERE account_id=? AND status='pending_review' "
                "AND (feishu_record_id IS NULL OR feishu_record_id='')", (aid,)
            ).fetchone()[0]
            unused = c.execute(
                "SELECT COUNT(*) FROM topic WHERE account_id=? AND is_used=0", (aid,)
            ).fetchone()[0]
            total_content = counts["pending_review"] + counts["published"] + counts["failed"]

            ls = r["login_status"]
            online = "在线" if ls == "logged_in" else ("已掉线" if ls == "logged_out" else "未登录")
            accounts.append({
                "id": aid,
                "name": r["display_name"] or r["nickname"] or f"账号{aid}",
                "online": online,
                "online_ok": ls == "logged_in",
                "last_check": (r["last_login_check"] or "")[:16].replace("T", " "),
                "niche": niche_row["niche"] if niche_row and niche_row["niche"] else "",
                "feishu_ok": bool(r["feishu_app_token"] and r["feishu_table_id"]),
                "proxy_on": bool(r["proxy"]),
                "pending": counts["pending_review"] - unpushed,
                "unpushed": unpushed,
                "published": counts["published"],
                "failed": counts["failed"],
                "total": total_content,
                "unused_topics": unused,
                "topics_low": unused < 5,
            })

    return {
        "accounts": accounts,
        "summary": {
            "account_count": len(accounts),
            "max_accounts": _lic.max_accounts(),
            "tier": "已解锁多账号" if _lic.is_unlocked() else "免费版（单账号）",
            "online_count": sum(1 for a in accounts if a["online_ok"]),
            "pending_total": sum(a["pending"] for a in accounts),
            "unpushed_total": sum(a.get("unpushed", 0) for a in accounts),
            "published_total": sum(a["published"] for a in accounts),
            "low_topic_count": sum(1 for a in accounts if a["topics_low"]),
        },
    }


def _render_dashboard_html(data: dict) -> str:
    return _DASH_HTML.replace("__DATA__", json.dumps(data, ensure_ascii=False)) \
                     .replace("__FOOTER__", _UI_FOOTER)


def _dashboard(args) -> None:
    if not _account_count():
        err("还没有账号，先建一个账号再看看板", next="redbeacon accounts create")

    finished = threading.Event()
    port = _free_port()

    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *a):
            pass

        def _json(self, code, obj):
            body = json.dumps(obj, ensure_ascii=False).encode("utf-8")
            self.send_response(code)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def do_GET(self):
            if self.path in ("/", "/index.html"):
                body = _render_dashboard_html(_load_dashboard()).encode("utf-8")
                self.send_response(200)
                self.send_header("Content-Type", "text/html; charset=utf-8")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)
            elif self.path == "/data":
                # 前端刷新按钮：拿最新聚合，不重开页面
                self._json(200, _load_dashboard())
            else:
                self.send_response(404); self.end_headers()

        def do_POST(self):
            if self.path == "/done":
                self._json(200, {"ok": True})
                finished.set()
            else:
                self.send_response(404); self.end_headers()

    httpd = HTTPServer(("127.0.0.1", port), Handler)
    httpd.timeout = 1

    url = f"http://127.0.0.1:{port}/"
    if sys.platform == "darwin":
        subprocess.Popen(["open", url])
    elif sys.platform.startswith("linux"):
        subprocess.Popen(["xdg-open", url])
    print(json.dumps({"status": "ui_opened", "url": url,
                      "msg": "已打开运营看板：一眼看全部账号的在线/内容/选题情况，看完点「关闭看板」"},
                     ensure_ascii=False))
    sys.stdout.flush()

    deadline = time.time() + _TIMEOUT_SEC
    while not finished.is_set() and time.time() < deadline:
        httpd.handle_request()
    httpd.server_close()

    out({"finished": finished.is_set(), "timed_out": not finished.is_set()})


def _account_count() -> int:
    with database.cursor() as c:
        return c.execute("SELECT COUNT(*) FROM account").fetchone()[0]


# ── 多账号管理台（Pro 专属）：一页列出所有账号卡片，点「进入配置」在独立窗口开该账号的内容调试面板 ──

def _render_manage_html(data: dict) -> str:
    return _MANAGE_HTML.replace("__DATA__", json.dumps(data, ensure_ascii=False)) \
                       .replace("__FOOTER__", _UI_FOOTER)


def _manage(args) -> None:
    """Pro 多账号管理台。一个本地服务渲染账号卡片列表；点某张卡的「进入配置」就在子线程里
    起一个独立的账号内容调试面板（复用 `_serve_account_panel`，自己的端口/浏览器窗口），列表页不动。"""
    from redbeacon.services import license as _lic
    if not _lic.is_unlocked():
        err("多账号管理台是 Pro 专属能力；免费版单账号直接用 `redbeacon ui account` 即可",
            next="redbeacon ui account --account-id 1")
    if not _account_count():
        err("还没有账号，先建一个账号再来", next="redbeacon accounts create")

    finished = threading.Event()
    launched: list[int] = []
    port = _free_port()

    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *a):
            pass

        def _json(self, code, obj):
            body = json.dumps(obj, ensure_ascii=False).encode("utf-8")
            self.send_response(code)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def do_GET(self):
            if self.path in ("/", "/index.html"):
                body = _render_manage_html(_load_dashboard()).encode("utf-8")
                self.send_response(200)
                self.send_header("Content-Type", "text/html; charset=utf-8")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)
            elif self.path == "/data":
                self._json(200, _load_dashboard())
            else:
                self.send_response(404); self.end_headers()

        def do_POST(self):
            length = int(self.headers.get("Content-Length", 0))
            raw = self.rfile.read(length) if length else b"{}"
            try:
                payload = json.loads(raw.decode("utf-8"))
            except Exception:
                payload = {}
            if self.path == "/launch":
                try:
                    aid = int(payload.get("id"))
                except Exception:
                    self._json(200, {"ok": False, "error": "账号 id 不对"}); return
                # 子线程里起独立面板（自己的端口 + 浏览器窗口），不阻塞列表页
                threading.Thread(
                    target=lambda: _serve_account_panel(aid, announce=False),
                    daemon=True,
                ).start()
                launched.append(aid)
                self._json(200, {"ok": True, "id": aid})
            elif self.path == "/done":
                self._json(200, {"ok": True}); finished.set()
            else:
                self.send_response(404); self.end_headers()

    httpd = ThreadingHTTPServer(("127.0.0.1", port), Handler)
    httpd.daemon_threads = True
    threading.Thread(target=httpd.serve_forever, daemon=True).start()

    url = f"http://127.0.0.1:{port}/"
    if sys.platform == "darwin":
        subprocess.Popen(["open", url])
    elif sys.platform.startswith("linux"):
        subprocess.Popen(["xdg-open", url])
    print(json.dumps({"status": "ui_opened", "url": url,
                      "msg": "已打开多账号管理台：每个账号一张卡片，点「进入配置」会在新窗口打开"
                             "该账号的内容调试面板；都弄完点「关闭管理台」"}, ensure_ascii=False))
    sys.stdout.flush()

    finished.wait(timeout=_TIMEOUT_SEC)
    httpd.shutdown()
    httpd.server_close()
    out({"finished": finished.is_set(), "timed_out": not finished.is_set(),
         "launched_accounts": sorted(set(launched))})


_MANAGE_HTML = """<!DOCTYPE html>
<html lang="zh-CN"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>RedBeacon · 多账号管理台</title>
<style>
  :root{--bg:#f6f7f9;--card:#ffffff;--bd:#eceef1;--fg:#1f2329;--mut:#8a9099;--accent:#ff2442;--ok:#13a463;--warn:#c8860a;}
  *{box-sizing:border-box;} body{margin:0;background:var(--bg);color:var(--fg);
    font-family:-apple-system,BlinkMacSystemFont,"PingFang SC","Microsoft YaHei",sans-serif;}
  .wrap{max-width:1080px;margin:0 auto;padding:28px 22px 60px;}
  .top{display:flex;align-items:center;justify-content:space-between;margin-bottom:6px;}
  h1{font-size:20px;margin:0;} h1 .lt{color:var(--accent);}
  .sub{color:var(--mut);font-size:13px;margin:4px 0 20px;}
  .acts{display:flex;gap:8px;}
  button{font:inherit;cursor:pointer;border-radius:8px;border:1px solid var(--bd);
    background:#f0f1f3;color:var(--fg);padding:7px 14px;}
  button:hover{border-color:var(--mut);}
  button.refresh{background:transparent;color:var(--mut);}
  .grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(320px,1fr));gap:14px;}
  .card{background:var(--card);border:1px solid var(--bd);border-radius:14px;padding:16px 16px 14px;
    display:flex;flex-direction:column;gap:10px;}
  .chead{display:flex;align-items:baseline;gap:10px;}
  .num{font-size:20px;font-weight:700;} .num small{font-size:13px;color:var(--mut);font-weight:500;}
  .nick{font-size:15px;color:var(--fg);}
  .nick.empty{color:var(--mut);font-style:italic;}
  .badges{display:flex;flex-wrap:wrap;gap:6px;margin-top:2px;}
  .tag{font-size:11.5px;padding:2px 9px;border-radius:999px;border:1px solid var(--bd);color:var(--mut);}
  .tag.on{color:var(--ok);border-color:rgba(60,186,120,.4);}
  .tag.off{color:var(--accent);border-color:rgba(255,46,77,.4);}
  .tag.warn{color:var(--warn);border-color:rgba(202,164,90,.4);}
  .niche{color:var(--mut);font-size:12.5px;min-height:16px;}
  .stats{display:flex;gap:16px;font-size:12.5px;color:var(--mut);border-top:1px solid var(--bd);padding-top:10px;}
  .stats b{color:var(--fg);font-weight:600;}
  .go{margin-top:4px;background:var(--accent);border-color:var(--accent);color:#fff;font-weight:600;text-align:center;}
  .go:hover{filter:brightness(1.08);} .go:disabled{opacity:.6;cursor:default;}
  .foot{margin-top:26px;text-align:center;}
  .closing{color:var(--ok);font-size:13px;margin-top:10px;min-height:18px;}
</style></head><body>
<div class="wrap">
  <div class="top">
    <h1><span class="lt">RedBeacon</span> · 多账号管理台</h1>
    <div class="acts">
      <button class="refresh" onclick="load()">↻ 刷新</button>
      <button onclick="done()">关闭管理台</button>
    </div>
  </div>
  <p class="sub" id="sub">每个账号一张卡片。点「进入配置」会在新窗口打开该账号的内容调试面板，调完关掉那个窗口即可，列表留在这。</p>
  <div class="grid" id="grid"></div>
  <div class="foot"><div class="closing" id="closing"></div></div>
</div>
<script>
let S = __DATA__;
const $ = id => document.getElementById(id);
const esc = s => (s==null?'':String(s)).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
function isUnnamed(n){ return !n || /^\\d+号小红书$/.test(n) || /^redbeacon-\\d+$/.test(n) || n==='账号'+''; }
function card(a){
  const nick = isUnnamed(a.name) ? '<span class="nick empty">（未命名）</span>' : '<span class="nick">'+esc(a.name)+'</span>';
  const online = a.online_ok ? '<span class="tag on">● 在线</span>'
                : '<span class="tag off">● '+esc(a.online)+'</span>';
  const fs = a.feishu_ok ? '<span class="tag on">飞书已绑</span>' : '<span class="tag off">飞书未绑</span>';
  const px = a.proxy_on ? '<span class="tag">代理</span>' : '';
  const low = a.topics_low ? '<span class="tag warn">选题余 '+a.unused_topics+'</span>'
                           : '<span class="tag">选题 '+a.unused_topics+'</span>';
  const niche = a.niche ? '定位：'+esc(a.niche) : '<span style="opacity:.7">未做定位</span>';
  return '<div class="card">'
    + '<div class="chead"><span class="num">'+a.id+'<small>号小红书</small></span>'+nick+'</div>'
    + '<div class="badges">'+online+fs+low+px+'</div>'
    + '<div class="niche">'+niche+'</div>'
    + '<div class="stats"><span>待审 <b>'+a.pending+'</b></span><span>已发 <b>'+a.published+'</b></span>'
    + (a.failed?'<span>失败 <b>'+a.failed+'</b></span>':'')
    + (a.unpushed?'<span style="color:var(--warn)" title="生成了但没推进飞书">未推 <b>'+a.unpushed+'</b></span>':'')+'</div>'
    + '<button class="go" onclick="launch('+a.id+',this)">⚙ 进入配置</button>'
    + '</div>';
}
function render(){
  $('grid').innerHTML = (S.accounts||[]).map(card).join('');
  $('sub').textContent = '共 '+(S.accounts||[]).length+' 个账号（'+(S.summary?S.summary.tier:'')+'）。点「进入配置」在新窗口打开该账号的内容调试面板，调完关掉即可。';
}
async function load(){
  try{ const r=await fetch('/data'); S=await r.json(); render(); }catch(e){}
}
async function launch(id, btn){
  btn.disabled=true; const old=btn.textContent; btn.textContent='已在新窗口打开…';
  try{ await fetch('/launch',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({id})}); }catch(e){}
  $('closing').textContent = '已为 '+id+'号 打开内容调试面板（新窗口）。调完关掉那个窗口，回来可「↻ 刷新」看最新数据。';
  setTimeout(()=>{ btn.disabled=false; btn.textContent=old; }, 2500);
}
async function done(){
  try{ await fetch('/done',{method:'POST'}); }catch(e){}
  document.body.innerHTML='<div style="padding:80px 30px;text-align:center;color:#8b93a1;font-size:16px">管理台已关闭 ✓<br><br>请关闭本页，回到对话。</div>';
  setTimeout(()=>{try{window.close()}catch(e){}},500);
}
render();
</script>__FOOTER__</body></html>"""


# ── HTML 模板（内置固定，不在运行时由模型生成）────────────────────────────────

def _render_html(state: dict) -> str:
    # 按分组拼字段；每个分组一张卡片，组内字段紧凑两列（多行项独占整行）
    groups: dict[str, list[str]] = {}
    for key, label, multiline, group, _default in _STRATEGY_FIELDS:
        if key in _STRATEGY_CHOICES:
            opts = "".join(f'<option value="{o}">{o}</option>' for o in _STRATEGY_CHOICES[key])
            ctrl = f'<select data-strat="{key}">{opts}</select>'
            cls = "fld"
        else:
            # 全部用自适应高度文本框（内容长就自动变高，读着不憋屈），并独占整行更好读
            ctrl = f'<textarea data-strat="{key}" rows="1" class="ag"></textarea>'
            cls = "fld wide"
        groups.setdefault(group, []).append(
            f'<label class="{cls}"><span class="lab">{label}</span>{ctrl}</label>')
    group_cards = "".join(
        f'<div class="card"><h2>{name}</h2><div class="grid">{"".join(rows)}</div></div>'
        for name, rows in groups.items())
    mode_opts = "".join(f'<option value="{v}">{t}</option>' for v, t in _IMAGE_MODE_LABELS)
    theme_list = json.dumps(_CARD_THEME_LABELS, ensure_ascii=False)
    return (_HTML
            .replace("__DATA__", json.dumps(state, ensure_ascii=False))
            .replace("__GROUP_CARDS__", group_cards)
            .replace("__MODE_OPTS__", mode_opts)
            .replace("__THEME_LIST__", theme_list)
            .replace("__FOOTER__", _UI_FOOTER))


_HTML = r"""<!doctype html>
<html lang="zh"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>RedBeacon 账号配置</title>
<style>
  :root { --bg:#f6f7f9; --card:#ffffff; --bd:#eceef1; --fg:#1f2329; --mut:#8a9099; --accent:#ff2442; --ok:#13a463; }
  * { box-sizing:border-box; }
  body { margin:0; background:var(--bg); color:var(--fg);
         font:14px/1.65 -apple-system,BlinkMacSystemFont,"PingFang SC",sans-serif; }
  .top { padding:18px 28px; border-bottom:1px solid var(--bd); display:flex; align-items:baseline; gap:12px; }
  .top h1 { font-size:18px; margin:0; }
  .top .who { color:var(--accent); font-weight:600; }
  .top .tip { color:var(--mut); font-size:12.5px; margin-left:auto; }
  .layout { display:grid; grid-template-columns:1fr 1fr; gap:0; height:calc(100vh - 59px); }
  .col { overflow-y:auto; padding:22px 28px; }
  .col.left { border-right:1px solid var(--bd); }
  .card { background:var(--card); border:1px solid var(--bd); border-radius:12px; padding:18px 20px; margin-bottom:16px; }
  .card h2 { font-size:14px; margin:0 0 14px; color:var(--accent); letter-spacing:.3px; }
  .grid { display:grid; grid-template-columns:1fr 1fr; gap:11px 16px; }
  .fld { display:flex; flex-direction:column; gap:4px; }
  .fld.wide { grid-column:1 / -1; }
  .fld .lab { font-size:12.5px; font-weight:600; color:var(--mut); }
  input, select, textarea { background:var(--bg); border:1px solid var(--bd); color:var(--fg);
          border-radius:8px; padding:9px 11px; font:inherit; width:100%; }
  textarea { resize:vertical; }
  textarea.ag { resize:none; overflow:hidden; min-height:40px; line-height:1.6; }
  .ct { margin-bottom:11px; }
  .ct b { font-size:12.5px; color:var(--mut); display:block; margin-bottom:4px; }
  .ct textarea { min-height:64px; font-size:13px; }
  .actions { position:sticky; bottom:0; background:linear-gradient(transparent,var(--bg) 28%); padding:16px 0 6px; display:flex; gap:10px; }
  button { background:var(--accent); color:#fff; border:0; border-radius:8px; padding:11px 20px; font:inherit; font-weight:600; cursor:pointer; }
  button.ghost { background:transparent; border:1px solid var(--bd); color:var(--mut); }
  button:disabled { opacity:.5; cursor:default; }
  #msg { color:var(--mut); align-self:center; font-size:12.5px; }
  .pv-empty { color:var(--mut); text-align:center; margin-top:60px; line-height:2; }
  .pv-title { font-size:17px; font-weight:700; margin:0 0 12px; }
  .pv-body { white-space:pre-wrap; background:var(--card); border:1px solid var(--bd); border-radius:10px; padding:16px; }
  .pv-tags { margin-top:12px; color:#2f6fd0; font-size:13px; }
  .pv-imgs { display:flex; flex-wrap:wrap; gap:8px; margin-top:14px; }
  .pv-imgs img { width:130px; border-radius:8px; border:1px solid var(--bd); cursor:zoom-in; transition:transform .12s; }
  .pv-imgs img:hover { transform:scale(1.03); border-color:var(--accent); }
  .lightbox { position:fixed; inset:0; background:rgba(0,0,0,.86); display:none; align-items:center; justify-content:center; z-index:999; cursor:zoom-out; }
  .lightbox.show { display:flex; }
  .lightbox img { max-width:92vw; max-height:92vh; border-radius:10px; box-shadow:0 8px 40px rgba(0,0,0,.6); }
  .lightbox .x { position:absolute; top:18px; right:24px; color:#fff; font-size:30px; line-height:1; opacity:.8; cursor:pointer; }
  .lightbox .x:hover { opacity:1; }
  /* 卡片配色：缩略图选择网格 + 悬停放大浮层 */
  .theme-grid { display:grid; grid-template-columns:repeat(5,1fr); gap:7px; margin-top:5px; }
  .theme-cell { border:2px solid var(--bd); border-radius:8px; padding:4px; cursor:pointer; background:var(--bg); transition:border-color .12s, box-shadow .12s; }
  .theme-cell:hover { border-color:var(--accent); }
  .theme-cell.sel { border-color:var(--accent); box-shadow:0 0 0 2px rgba(255,77,109,.3); }
  .theme-cell img { width:100%; height:78px; object-fit:cover; object-position:top center; border-radius:5px; display:block; background:#eef0f2; }
  .theme-cell .tlab { font-size:10px; color:var(--mut); margin-top:4px; line-height:1.25; text-align:center; }
  .theme-cell.sel .tlab { color:var(--fg); }
  .theme-cell .dice-ico { height:78px; display:flex; align-items:center; justify-content:center; font-size:34px; }
  #theme-zoom { position:fixed; z-index:900; display:none; pointer-events:none; border-radius:12px; overflow:hidden; box-shadow:0 14px 48px rgba(0,0,0,.25); border:1px solid var(--bd); background:#fff; }
  #theme-zoom img { width:330px; display:block; }
  .pv-meta { color:var(--mut); font-size:12px; margin-bottom:14px; }
  .spin { color:var(--accent); }
  @keyframes spin360 { to { transform:rotate(360deg); } }
  .loading-wrap { text-align:center; margin-top:64px; color:var(--mut); }
  .loading-wrap .ring { width:48px; height:48px; border:4px solid var(--bd); border-top-color:var(--accent);
                        border-radius:50%; margin:0 auto 20px; animation:spin360 .8s linear infinite; }
  .loading-wrap .big { color:var(--fg); font-size:15px; font-weight:600; }
  .loading-wrap .step { font-size:12.5px; margin-top:8px; }
  button.loading { position:relative; color:transparent !important; }
  button.loading::after { content:''; position:absolute; left:50%; top:50%; width:16px; height:16px;
        margin:-8px 0 0 -8px; border:2px solid rgba(255,255,255,.5); border-top-color:#fff;
        border-radius:50%; animation:spin360 .7s linear infinite; }
  .ref-list { display:flex; flex-wrap:wrap; gap:8px; margin-bottom:8px; }
  .ref-list .refcell { position:relative; }
  .ref-list img { width:64px; height:80px; object-fit:cover; border-radius:7px; border:1px solid var(--bd); }
  .ref-list .rx { position:absolute; top:-6px; right:-6px; width:18px; height:18px; border-radius:50%;
        background:var(--accent); color:#fff; font-size:12px; line-height:18px; text-align:center; cursor:pointer; }
  .ref-actions { display:flex; align-items:center; gap:10px; }
  .ref-up { display:inline-block; font-size:12.5px; padding:7px 12px; border:1px dashed var(--bd);
        border-radius:8px; color:var(--mut); cursor:pointer; }
  .ref-up:hover { border-color:var(--accent); color:var(--fg); }
  button.ref-clear { padding:7px 12px; font-size:12.5px; }
</style></head>
<body>
  <div class="top"><h1>账号配置 · <span class="who" id="who"></span></h1>
    <span class="tip">下面是按我们聊的内容帮你定好的方案，看哪不对就改哪，不用全填。右边能直接生成一篇看效果。</span></div>
  <div class="layout">
    <div class="col left">
      __GROUP_CARDS__
      <div class="card"><h2>文案提示词</h2>
        <label class="fld" style="margin-bottom:14px"><span class="lab">全局文案提示词（所有内容类型通用——改这一个就够，不用逐类改）</span><textarea data-strat="copy_guide" rows="3" class="ag"></textarea></label>
        <div class="lab" style="margin-bottom:6px;color:var(--mut)">各类内容的微调（可选，留空即可；填了会叠加在全局之上）</div>
        <div id="cts"></div></div>
      <div class="card"><h2>用哪个 AI 写文案</h2>
        <div class="grid">
          <label class="fld wide"><span class="lab">写文案的模型（拿不准就保持当前）</span>
            <select id="text-model-sel"></select>
            <input id="text-model" style="display:none" placeholder="模型代号"></label>
        </div>
      </div>
      <div class="card"><h2>配图</h2>
        <div class="grid">
          <label class="fld"><span class="lab">配图方式</span><select id="img-mode">__MODE_OPTS__</select></label>
          <div class="fld wide" id="theme-wrap"><span class="lab">卡片配色（鼠标悬停看效果，点一下选中）</span>
            <div class="theme-grid" id="theme-grid"></div>
            <input type="hidden" id="img-theme"></div>
          <label class="fld" id="model-wrap"><span class="lab">用哪个 AI 画图</span>
            <select id="img-model-sel"></select>
            <input id="img-model" style="display:none" placeholder="模型代号"></label>
          <label class="fld wide" id="prompt-wrap"><span class="lab">图片提示词（封面，可直接改）—— 可只写风格（如「深色背景、亮色块、厚重大字、极简高级」，自动包成大字报）；也可写完整提示词，用 {标题} 控制封面大字</span><textarea id="img-prompt" rows="3" class="ag"></textarea></label>
          <div class="fld wide" id="ref-wrap"><span class="lab">参考图（可选）——想用自己的照片做人物封面，或复刻某张图的风格，上传它，AI 就按这张图来生成</span>
            <div id="ref-list" class="ref-list"></div>
            <div class="ref-actions">
              <label class="ref-up">＋ 上传参考图<input type="file" id="ref-file" accept="image/*" style="display:none"></label>
              <button type="button" class="ghost ref-clear" id="ref-clear" style="display:none" onclick="clearRefs()">清空参考图</button>
              <span id="ref-msg" style="color:var(--mut);font-size:12px"></span>
            </div>
          </div>
          <label class="fld wide" id="ref-instr-wrap"><span class="lab">参考图指令（有参考图时自动加在封面提示词前；想保脸/复刻风格的话术都在这，可改）</span><textarea data-strat="ref_instruction" rows="2" class="ag"></textarea></label>
        </div>
      </div>
      <details class="card" style="padding:0 18px">
        <summary style="cursor:pointer;padding:16px 0;color:var(--accent);font-weight:600;font-size:14px;list-style:none">⚙️ 文案母模板（高级，谨慎改）</summary>
        <div style="padding-bottom:16px">
          <p style="color:var(--mut);font-size:12px;margin:0 0 10px">这是最底层那条文案模板——上面所有提示词最终都拼进它里面的 <code>{占位符}</code>。<b>含 JSON 输出格式约定，改坏会导致生成失败</b>。一般不用动；要完全掌控才改。<code>{niche}</code> <code>{tone}</code> <code>{content_type_guide}</code> 等占位符生成时自动替换；留着别删。</p>
          <textarea data-strat="copy_template" rows="14" style="font-size:12px;line-height:1.6"></textarea>
        </div>
      </details>
      <div class="card"><h2>查看最终提示词（实际发给 AI 的完整内容）</h2>
        <p style="color:var(--mut);font-size:12px;margin:0 0 10px">把上面的设定 + 一条示例选题拼好、真正发给 AI 的完整提示词（只读）。改了上面的设定，点「刷新查看」重看。</p>
        <button class="ghost" type="button" onclick="loadFinalPrompts()">刷新查看</button>
        <div id="fp-meta" style="color:var(--mut);font-size:12px;margin:8px 0 4px"></div>
        <label class="fld"><span class="lab">📝 文案最终提示词</span><textarea id="fp-text" rows="8" readonly style="font-size:12px;color:var(--mut)"></textarea></label>
        <label class="fld" id="fp-img-wrap" style="margin-top:8px"><span class="lab">🖼 图片最终提示词（封面）</span><textarea id="fp-img" rows="3" readonly style="font-size:12px;color:var(--mut)"></textarea></label>
      </div>
      <div class="actions">
        <button onclick="save()">保存修改</button>
        <button class="ghost" onclick="done()">完成返回对话</button>
        <span id="msg"></span>
      </div>
    </div>
    <div class="col right">
      <div class="card"><h2>试生成一篇看看效果</h2>
        <p style="color:var(--mut);font-size:12.5px;margin:0 0 12px">
          用左边的设定生成一篇笔记（会先存一下你的改动）。不占用选题库，生成的笔记会进内容队列。觉得不对就回左边改，或回到对话里告诉我怎么调。</p>
        <button id="gen" onclick="preview()">⚡ 生成一篇预览</button>
        <span id="gmsg" style="margin-left:10px;color:var(--mut);font-size:12.5px"></span>
      </div>
      <div id="pv"><div class="pv-empty">点上面的按钮，<br>这里会显示生成出来的笔记</div></div>
    </div>
  </div>
  <div id="lightbox" class="lightbox" onclick="closeZoom()"><span class="x">×</span><img id="lightbox-img" alt=""></div>
<script>
const S = __DATA__;
const PORT_BASE = location.origin;
document.getElementById('who').textContent = S.display_name;
document.querySelectorAll('[data-strat]').forEach(el => { el.value = S.strategy[el.dataset.strat] || ''; });
const ctBox = document.getElementById('cts');
S.content_types.forEach((ct,i) => {
  const d = document.createElement('div'); d.className='ct';
  d.innerHTML = '<b>'+ct.name+'</b><textarea data-ct="'+i+'" class="ag"></textarea>';
  ctBox.appendChild(d); d.querySelector('textarea').value = ct.prompt_template || '';
});
document.getElementById('img-mode').value = S.image.mode || 'cards';
document.getElementById('img-prompt').value = S.image.prompt_template || '';

// 自适应高度：内容多就长高，读着不憋屈（只读的最终提示词框不参与）
function autoGrow(el){ el.style.height='auto'; el.style.height=(el.scrollHeight+2)+'px'; }
function wireAutoGrow(){
  document.querySelectorAll('textarea.ag').forEach(t=>{
    if(!t._ag){ t._ag=1; t.addEventListener('input',()=>autoGrow(t)); }
    autoGrow(t);
  });
}
wireAutoGrow();

// 卡片配色：缩略图选择 + 悬停放大预览
const THEMES = __THEME_LIST__;
const themeGrid = document.getElementById('theme-grid');
const themeInput = document.getElementById('img-theme');
let curTheme = S.image.card_theme || 'default';
themeInput.value = curTheme;
const tzoom = document.createElement('div'); tzoom.id='theme-zoom'; tzoom.innerHTML='<img alt="">';
document.body.appendChild(tzoom);
function themeUrl(v){ return '/theme-preview?name='+encodeURIComponent(v); }
function showTZoom(e, v){
  const img = tzoom.querySelector('img'); const u = location.origin + themeUrl(v);
  if(img.getAttribute('src') !== u) img.src = u;
  tzoom.style.display='block';
  const w=332, h=445; let x=e.clientX+22, y=e.clientY-h/2;
  if(x+w>window.innerWidth) x=e.clientX-w-22;
  if(y<10) y=10; if(y+h>window.innerHeight) y=window.innerHeight-h-10;
  tzoom.style.left=x+'px'; tzoom.style.top=y+'px';
}
function hideTZoom(){ tzoom.style.display='none'; }
function renderThemeGrid(){
  themeGrid.innerHTML = THEMES.map(([v,label]) => {
    const sel = (v===curTheme) ? ' sel' : '';
    if(v==='random')
      return '<div class="theme-cell'+sel+'" data-theme="random"><div class="dice-ico">🎲</div><div class="tlab">'+label+'</div></div>';
    return '<div class="theme-cell'+sel+'" data-theme="'+v+'"><img src="'+themeUrl(v)+'" loading="lazy" alt=""><div class="tlab">'+label+'</div></div>';
  }).join('');
  themeGrid.querySelectorAll('.theme-cell').forEach(c => {
    const v = c.dataset.theme;
    c.onclick = () => { curTheme=v; themeInput.value=v; renderThemeGrid(); };
    if(v!=='random'){
      c.onmousemove = (e)=>showTZoom(e, v);
      c.onmouseleave = hideTZoom;
    } else { c.onmouseenter = hideTZoom; }
  });
}
renderThemeGrid();

// 模型选择：能从中转站拉到就用下拉，拉不到降级成手填输入框（绝不卡住）
const MODELS = S.models || {ok:false, text:[], image:[], error:''};
function setupModel(selId, inpId, options, current){
  const sel = document.getElementById(selId), inp = document.getElementById(inpId);
  current = current || '';
  if (MODELS.ok && options && options.length){
    sel.style.display=''; inp.style.display='none';
    let opts = options.slice();
    if (current && opts.indexOf(current)===-1) opts.unshift(current); // 当前值即便已下架也保留可见
    sel.innerHTML = opts.map(m => '<option value="'+m+'"'+(m===current?' selected':'')+'>'+m+'</option>').join('');
    if (current) sel.value = current;
  } else {
    // 没连上模型列表：手填，并把原因写进 placeholder
    sel.style.display='none'; inp.style.display='';
    inp.value = current;
    inp.placeholder = MODELS.error ? ('手填模型代号（没拉到列表：'+MODELS.error+'）') : '手填模型代号';
  }
}
setupModel('text-model-sel','text-model', MODELS.text,  S.text_model);
setupModel('img-model-sel','img-model',   MODELS.image, S.image_model);
function modelVal(selId, inpId){
  const sel=document.getElementById(selId);
  return (sel.style.display!=='none') ? sel.value : document.getElementById(inpId).value;
}
function syncImgFields(){
  // 按配图方式显隐：卡片配色只在用到卡片时显示；AI 画图相关只在用到 AI 时显示。
  const m = document.getElementById('img-mode').value;
  const showCards = (m==='cards'||m==='both');   // 纯卡片 / 两者
  const showAI    = (m==='ai'||m==='both');      // 纯AI / 两者
  const set=(id,on)=>{ const e=document.getElementById(id); if(e) e.style.display = on?'':'none'; };
  set('theme-wrap', showCards);
  set('model-wrap', showAI);
  set('prompt-wrap', showAI);
  set('ref-wrap', showAI);
  set('ref-instr-wrap', showAI);
  set('fp-img-wrap', showAI);   // 纯卡片时连"图片最终提示词"也藏掉
}
document.getElementById('img-mode').addEventListener('change', syncImgFields); syncImgFields();

// 参考图：上传(浏览器读成 data URL 传后端落盘) / 渲染 / 清空；有图=图生图、无图=文生图
let REFS = (S.image && S.image.reference_images) || [];
function renderRefs(){
  const box=document.getElementById('ref-list');
  box.innerHTML = REFS.map((p,i)=>'<div class="refcell"><img src="/img?p='+encodeURIComponent(p)+'">'
    +'<div class="rx" title="移除" onclick="removeRef('+i+')">×</div></div>').join('');
  document.getElementById('ref-clear').style.display = REFS.length ? '' : 'none';
  const msg=document.getElementById('ref-msg');
  msg.textContent = REFS.length ? '已设参考图 → AI 封面按这张图的人物/风格生成（图生图）' : '无参考图 → 文生图';
}
document.getElementById('ref-file').addEventListener('change', function(e){
  const f=e.target.files[0]; if(!f) return;
  const msg=document.getElementById('ref-msg'); msg.textContent='上传中…';
  const r=new FileReader();
  r.onload=async()=>{
    try{
      const j=await post('/upload-ref', {data_url:r.result});
      if(j.ok){ REFS=j.reference_images||[]; renderRefs(); }
      else { msg.textContent='上传失败：'+(j.error||''); }
    }catch(err){ msg.textContent='上传失败：'+((err&&err.message)||err); }
  };
  r.readAsDataURL(f); e.target.value='';
});
async function clearRefs(){
  try{ const j=await post('/clear-ref',{}); if(j.ok){ REFS=[]; renderRefs(); } }catch(e){}
}
async function removeRef(i){
  try{ const j=await post('/remove-ref',{index:i}); if(j.ok){ REFS=j.reference_images||[]; renderRefs(); } }catch(e){}
}
renderRefs();
// 打开即自动拼一次最终提示词，不用用户手点
loadFinalPrompts();

function collect(){
  const strategy = {};
  document.querySelectorAll('[data-strat]').forEach(el => { strategy[el.dataset.strat] = el.value; });
  const content_types = S.content_types.map((ct,i) => ({ name: ct.name,
    prompt_template: document.querySelector('[data-ct="'+i+'"]').value }));
  const image = { mode: document.getElementById('img-mode').value,
    card_theme: document.getElementById('img-theme').value,
    ai_model: modelVal('img-model-sel','img-model'),
    prompt_template: document.getElementById('img-prompt').value };
  const config = { ai_model: modelVal('text-model-sel','text-model') };
  return {strategy, content_types, image, config};
}
async function post(path, body){
  const r = await fetch(PORT_BASE+path, {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(body)});
  return r.json();
}
async function save(){
  const msg = document.getElementById('msg');
  msg.textContent = '保存中…';
  try {
    await post('/save', collect());
    msg.textContent = '已保存 ✓';
    setTimeout(()=>{ msg.textContent=''; }, 2000);
  } catch(e) {
    msg.textContent = '保存失败：' + (e && e.message || e);
  }
}
async function preview(){
  const btn = document.getElementById('gen'); btn.disabled = true; btn.classList.add('loading');
  const gmsg = document.getElementById('gmsg');
  const pv = document.getElementById('pv');
  gmsg.textContent = '';
  // 右栏直观 loading：旋转圈 + 阶段文字（单次请求，阶段按时间推进，给"在动"的感觉）
  const withCards = (document.getElementById('img-mode').value)!=='ai';
  const steps = ['调用 AI 写文案…'].concat(withCards?['根据配色渲染卡片…']:[]).concat(['快好了…']);
  pv.innerHTML = '<div class="loading-wrap"><div class="ring"></div><div class="big">正在生成预览</div>'
               + '<div class="step" id="lstep">'+steps[0]+'</div>'
               + '<div class="step" style="opacity:.7">大约十几秒，请稍候</div></div>';
  let si = 0;
  const stepTimer = setInterval(()=>{ si=Math.min(si+1,steps.length-1);
    const el=document.getElementById('lstep'); if(el) el.textContent=steps[si]; }, 4500);
  let j;
  try {
    j = await post('/preview', collect());
  } catch(e) {
    clearInterval(stepTimer); btn.disabled=false; btn.classList.remove('loading'); gmsg.textContent='';
    pv.innerHTML = '<div class="pv-empty">生成请求没发出去或中断了：<br>'+((e&&e.message)||e)+'<br><br>可重试，或回到对话里告诉我。</div>';
    return;
  }
  clearInterval(stepTimer);
  btn.disabled = false; btn.classList.remove('loading'); gmsg.textContent='';
  if(!j.ok){
    pv.innerHTML = '<div class="pv-empty" style="color:var(--accent)">生成失败 ✗<br><br>'+
      (j.error||'未知错误')+
      '<br><br><span style="color:var(--mut);font-size:12px">多半是 AI 配置问题（比如 API Key 失效）。回到对话里说一声，我帮你查配置。</span></div>';
    return;
  }
  const p = j.preview;
  let imgs = (p.images||[]).map(src => '<img src="/img?p='+encodeURIComponent(src)+'" onclick="zoom(this.src)">').join('');
  const noteWarn = (p.image_note||'').indexOf('⚠️')===0;
  pv.innerHTML =
    '<div class="pv-meta">选题：'+(p.topic||'')+' ｜ 已存入内容队列 #'+p.content_id+'（不消耗选题库）</div>'+
    '<div class="pv-title">'+ (p.title||'(无标题)') +'</div>'+
    '<div class="pv-body">'+ (p.body||'').replace(/</g,'&lt;') +'</div>'+
    (p.tags&&p.tags.length ? '<div class="pv-tags">'+p.tags.join(' ')+'</div>' : '')+
    (p.image_note ? '<div style="margin-top:14px;font-size:12.5px;color:'+(noteWarn?'var(--accent)':'var(--mut)')+'">'+p.image_note+'</div>' : '')+
    (imgs ? '<div class="pv-imgs">'+imgs+'</div>' : '');
}
function zoom(src){
  document.getElementById('lightbox-img').src = src;
  document.getElementById('lightbox').classList.add('show');
}
function closeZoom(){ document.getElementById('lightbox').classList.remove('show'); }
document.addEventListener('keydown', e => { if(e.key==='Escape') closeZoom(); });
async function loadFinalPrompts(){
  const meta=document.getElementById('fp-meta'); meta.textContent='拼装中…';
  try{
    const j=await post('/final-prompts', collect());
    if(!j.ok){ meta.textContent='出错：'+(j.error||''); return; }
    meta.textContent='（按 内容类型「'+j.content_type+'」+ 示例选题「'+j.sample_topic+'」渲染；真实生成时标题/选题会换成当篇的）';
    document.getElementById('fp-text').value=j.text_prompt||'';
    document.getElementById('fp-img').value=j.image_prompt||'';
  }catch(e){ meta.textContent='出错：'+((e&&e.message)||e); }
}
async function done(){
  try { await post('/done', collect()); } catch(e) { /* 即便回报失败也照常收尾，服务端会超时退出 */ }
  document.body.innerHTML = '<div style="padding:80px;text-align:center;color:#8b93a1;font-size:16px">已保存并返回 ✓<br><br>请关闭本页，回到对话继续。</div>';
  setTimeout(()=>{ try{window.close()}catch(e){} }, 600);
}
</script>__FOOTER__</body></html>"""


# ── 运营看板 HTML（只读，自包含）──────────────────────────────────────────────

_DASH_HTML = r"""<!DOCTYPE html>
<html lang="zh-CN"><head><meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>运营看板 · RedBeacon</title>
<style>
:root{--bg:#f6f7f9;--card:#ffffff;--line:#eceef1;--ink:#1f2329;--soft:#5b616a;--dim:#8a9099;
--beacon:#ff2442;--ok:#13a463;--warn:#c8860a;--off:#9ca3af;}
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:-apple-system,"PingFang SC","Microsoft YaHei",sans-serif;background:var(--bg);color:var(--ink);padding:32px}
.wrap{max-width:1180px;margin:0 auto}
.head{display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:16px;margin-bottom:28px}
.title{display:flex;align-items:center;gap:12px;font-size:24px;font-weight:800}
.dot{width:12px;height:12px;border-radius:50%;background:var(--beacon);box-shadow:0 0 0 0 rgba(255,61,84,.6);animation:p 2.4s infinite}
@keyframes p{0%{box-shadow:0 0 0 0 rgba(255,61,84,.55)}70%{box-shadow:0 0 0 12px rgba(255,61,84,0)}100%{box-shadow:0 0 0 0 rgba(255,61,84,0)}}
.btns{display:flex;gap:10px}
.btn{padding:9px 16px;border-radius:999px;font-size:14px;font-weight:600;cursor:pointer;border:1px solid var(--line);background:transparent;color:var(--ink)}
.btn:hover{border-color:var(--beacon)}
.btn.primary{background:linear-gradient(120deg,var(--beacon),#ff7a3d);border-color:transparent;color:#fff}
.stats{display:grid;grid-template-columns:repeat(5,1fr);gap:14px;margin-bottom:26px}
.stat{background:var(--card);border:1px solid var(--line);border-radius:14px;padding:18px}
.stat .n{font-size:30px;font-weight:800;letter-spacing:-1px}
.stat .l{font-size:13px;color:var(--dim);margin-top:4px}
table{width:100%;border-collapse:collapse;background:var(--card);border:1px solid var(--line);border-radius:14px;overflow:hidden}
th,td{text-align:left;padding:14px 16px;font-size:14px;border-bottom:1px solid var(--line)}
th{color:var(--dim);font-weight:600;font-size:12px;letter-spacing:.5px;text-transform:uppercase}
tr:last-child td{border-bottom:none}
tr:hover td{background:rgba(0,0,0,.025)}
.name{font-weight:700}
.id{color:var(--dim);font-size:12px;font-family:monospace;margin-right:8px}
.niche{color:var(--soft)}
.pill{display:inline-flex;align-items:center;gap:5px;padding:3px 10px;border-radius:999px;font-size:12px;font-weight:600}
.pill::before{content:"";width:6px;height:6px;border-radius:50%;background:currentColor}
.on{color:var(--ok);background:rgba(52,211,153,.12)}
.off{color:var(--off);background:rgba(156,163,175,.12)}
.down{color:var(--beacon);background:rgba(255,61,84,.12)}
.tag{display:inline-block;padding:2px 8px;border-radius:6px;font-size:12px}
.tag.ok{color:var(--ok);background:rgba(52,211,153,.1)}
.tag.no{color:var(--dim);background:rgba(118,114,108,.12)}
.num{font-variant-numeric:tabular-nums;font-weight:700}
.low{color:var(--warn)}
.muted{color:var(--dim)}
.foot{margin-top:18px;color:var(--dim);font-size:13px;text-align:center}
@media(max-width:820px){.stats{grid-template-columns:repeat(2,1fr)}td:nth-child(6),th:nth-child(6){display:none}}
</style></head>
<body><div class="wrap">
  <div class="head">
    <div class="title"><span class="dot"></span> 运营看板</div>
    <div class="btns">
      <button class="btn" onclick="refresh()">刷新</button>
      <button class="btn primary" onclick="done()">关闭看板</button>
    </div>
  </div>
  <div class="stats" id="stats"></div>
  <table><thead><tr>
    <th>账号</th><th>定位</th><th>登录</th><th>审核表</th><th>待审 / 已发 / 失败</th><th>可用选题</th>
  </tr></thead><tbody id="rows"></tbody></table>
  <div class="foot" id="foot"></div>
</div>
<script>
let DATA = __DATA__;
function esc(s){return (s==null?'':String(s)).replace(/[&<>]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;'}[c]));}
function render(){
  const s = DATA.summary;
  document.getElementById('stats').innerHTML = [
    ['账号数', s.account_count + ' / ' + s.max_accounts],
    ['在线', s.online_count],
    ['待审核', s.pending_total],
    ['已发布', s.published_total],
    ['选题告急', s.low_topic_count],
  ].map(([l,n],i)=>`<div class="stat"><div class="n${i===4&&s.low_topic_count>0?' low':''}">${esc(n)}</div><div class="l">${esc(l)}</div></div>`).join('');

  document.getElementById('rows').innerHTML = DATA.accounts.map(a=>{
    const onCls = a.online==='在线'?'on':(a.online==='已掉线'?'down':'off');
    const fei = a.feishu_ok?'<span class="tag ok">已连</span>':'<span class="tag no">未连</span>';
    const topics = a.unused_topics<5
      ? `<span class="num low">${a.unused_topics}</span> <span class="muted">条 · 该补题</span>`
      : `<span class="num">${a.unused_topics}</span> <span class="muted">条</span>`;
    const niche = a.niche? esc(a.niche) : '<span class="muted">未设定位</span>';
    return `<tr>
      <td class="name"><span class="id">#${a.id}</span>${esc(a.name)}</td>
      <td class="niche">${niche}</td>
      <td><span class="pill ${onCls}">${esc(a.online)}</span></td>
      <td>${fei}${a.proxy_on?' <span class="tag ok">代理</span>':''}</td>
      <td><span class="num">${a.pending}</span> / <span class="num">${a.published}</span> / <span class="num${a.failed>0?' low':''}">${a.failed}</span>${a.unpushed>0?` <span class="tag" style="color:var(--warn)" title="生成了但没推进飞书">⚠${a.unpushed} 未推</span>`:''}</td>
      <td>${topics}</td>
    </tr>`;
  }).join('');

  const low = DATA.accounts.filter(a=>a.topics_low).map(a=>a.name);
  document.getElementById('foot').textContent = low.length
    ? '⚠ 选题快用完的账号：' + low.join('、') + ' —— 回对话让我按定位补题'
    : '全部账号选题充足 · 数据只读，改动去对应 skill';
}
async function refresh(){
  try{ const r=await fetch('/data'); DATA=await r.json(); render(); }catch(e){}
}
async function done(){
  try{ await fetch('/done',{method:'POST'}); }catch(e){}
  document.body.innerHTML='<div style="padding:90px;text-align:center;color:#8b93a1;font-size:16px">看板已关闭 ✓<br><br>请关闭本页，回到对话继续。</div>';
  setTimeout(()=>{try{window.close()}catch(e){}},600);
}
render();
</script>__FOOTER__</body></html>"""


# ── 安装向导 HTML（ui setup，自包含；密钥只在浏览器↔localhost 间传）──────────────

_SETUP_HTML = r"""<!doctype html>
<html lang="zh"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>RedBeacon 安装向导</title>
<style>
  :root{--bg:#f6f7f9;--card:#ffffff;--bd:#eceef1;--fg:#1f2329;--mut:#8a9099;--accent:#ff2442;--ok:#13a463;--warn:#c8860a;}
  *{box-sizing:border-box;}
  body{margin:0;background:var(--bg);color:var(--fg);font:14px/1.65 -apple-system,BlinkMacSystemFont,"PingFang SC",sans-serif;}
  .wrap{max-width:640px;margin:0 auto;padding:30px 24px 60px;}
  .head h1{font-size:20px;margin:0 0 6px;}
  .head p{color:var(--mut);font-size:13px;margin:0 0 22px;}
  .head .sec{color:var(--ok);}
  .card{background:var(--card);border:1px solid var(--bd);border-radius:12px;padding:18px 20px;margin-bottom:16px;}
  .card h2{font-size:14px;margin:0 0 4px;color:var(--accent);}
  .card .sub{color:var(--mut);font-size:12px;margin:0 0 14px;}
  .fld{display:flex;flex-direction:column;gap:5px;margin-bottom:12px;}
  .fld .lab{font-size:12.5px;font-weight:600;color:var(--mut);}
  input,select{background:var(--bg);border:1px solid var(--bd);color:var(--fg);border-radius:8px;padding:10px 12px;font:inherit;width:100%;}
  .row{display:flex;gap:10px;align-items:center;}
  button{background:var(--accent);color:#fff;border:0;border-radius:8px;padding:10px 18px;font:inherit;font-weight:600;cursor:pointer;white-space:nowrap;}
  button.ghost{background:transparent;border:1px solid var(--bd);color:var(--mut);}
  button.big{width:100%;padding:13px;font-size:15px;margin-top:6px;}
  button:disabled{opacity:.5;cursor:default;}
  button.loading{position:relative;color:transparent !important;}
  @keyframes spin360{to{transform:rotate(360deg);}}
  button.loading::after{content:'';position:absolute;left:50%;top:50%;width:15px;height:15px;margin:-7.5px 0 0 -7.5px;border:2px solid rgba(255,255,255,.5);border-top-color:#fff;border-radius:50%;animation:spin360 .7s linear infinite;}
  .res{font-size:12.5px;margin-top:4px;min-height:18px;}
  .res.ok{color:var(--ok);} .res.no{color:var(--accent);}
  .res .meta{color:var(--mut);}
  .imgmeta{display:flex;flex-wrap:wrap;gap:6px;margin:8px 0 6px;}
  .imgmeta .kv{font-size:12px;background:var(--bg);border:1px solid var(--bd);border-radius:6px;padding:3px 9px;}
  .imgmeta .kv b{color:var(--fg);font-weight:600;}
  .imgmeta .kv span{color:var(--mut);}
  .fs-userlist{display:flex;flex-direction:column;gap:6px;margin-bottom:6px;}
  .fs-user{display:flex;align-items:center;gap:8px;padding:8px 10px;border:1px solid var(--bd);border-radius:8px;cursor:pointer;background:var(--bg);}
  .fs-user:hover{border-color:var(--mut);}
  .fs-user.on{border-color:var(--ok);background:rgba(60,180,120,.08);}
  .fs-user b{color:var(--fg);font-weight:600;font-size:13.5px;white-space:nowrap;}
  .fs-user .uid{color:var(--mut);font-size:11.5px;margin-left:auto;font-family:ui-monospace,monospace;
        white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:62%;}
  /* 关键修复：页面全局 input{width:100%} 会把单选框也撑满、挤竖名字，这里把 radio 复位成原生小尺寸 */
  .fs-user input[type=radio]{width:auto;flex:0 0 auto;padding:0;margin:0;}
  .badge{display:inline-block;font-size:11px;padding:1px 8px;border-radius:999px;border:1px solid var(--bd);color:var(--mut);margin-left:8px;}
  .badge.done{color:var(--ok);border-color:rgba(55,211,155,.4);}
  details{border:1px solid var(--bd);border-radius:12px;padding:0 20px;margin-bottom:16px;background:var(--card);}
  details summary{cursor:pointer;padding:16px 0;font-size:14px;color:var(--accent);font-weight:600;list-style:none;}
  details summary::-webkit-details-marker{display:none;}
  details summary::before{content:"▸ ";color:var(--mut);}
  details[open] summary::before{content:"▾ ";}
  details .inner{padding-bottom:18px;}
  .hint{color:var(--mut);font-size:12px;margin-top:10px;line-height:1.7;}
  .cardhead{display:flex;align-items:center;gap:8px;margin:0 0 4px;}
  .cardhead h2{margin:0;flex:0 0 auto;}
  .cardhead .acts{margin-left:auto;display:flex;gap:7px;}
  button.mini{font-size:12px;padding:5px 10px;background:transparent;border:1px solid var(--bd);color:var(--mut);border-radius:7px;font-weight:500;}
  button.mini:hover{border-color:var(--accent);color:var(--fg);}
  button.mini.copied{color:var(--ok);border-color:rgba(55,211,155,.45);}
  #img-preview{margin-top:10px;}
  #img-preview img.shot{width:200px;border-radius:10px;border:1px solid var(--bd);display:block;box-shadow:0 4px 18px rgba(0,0,0,.4);}
  .rec{font-size:12px;color:var(--mut);margin:-4px 0 12px;line-height:1.7;}
  .relaywarn{font-size:12.5px;color:var(--warn);background:rgba(202,164,90,.1);border:1px solid rgba(202,164,90,.4);
        border-radius:8px;padding:8px 11px;margin:-2px 0 12px;line-height:1.6;}
  .relaywarn a,.rec a{color:var(--accent);cursor:pointer;text-decoration:underline;}
  .rec b{color:var(--fg);}
  .rec a{color:var(--accent);cursor:pointer;text-decoration:none;}
  .rec a:hover{text-decoration:underline;}
  summary .px-reg{float:right;font-size:12px;color:var(--accent);cursor:pointer;font-weight:500;}
  summary .px-reg:hover{text-decoration:underline;}
</style></head>
<body><div class="wrap">
  <div class="head">
    <h1>RedBeacon 安装向导</h1>
    <p>填一次就好。<span class="sec">🔒 你的 Key 只写在这台电脑本地，不会进入对话、也不发给任何模型。</span></p>
  </div>

  <div class="card">
    <div class="cardhead">
      <h2>① AI（必需）<span class="badge" id="b-ai">未配置</span></h2>
      <div class="acts">
        <button class="mini" onclick="openUrl('https://aihub.jidouqie.com/')">🔗 推荐中转站 ↗</button>
      </div>
    </div>
    <p class="sub">用来写文案、生成配图。填好点「保存并测连通」，连上后下面会自动列出可选模型。</p>
    <div class="fld"><span class="lab">接口地址（base_url）</span><input id="ai_base_url" placeholder="https://…/v1" oninput="checkRelay()"></div>
    <div class="rec">兼容性最佳：<b>aihub.jidouqie.com</b>（本项目深度适配，三个生图模型实测全通）· <a onclick="useRecommended()">一键填入地址</a> · <a onclick="openUrl('https://aihub.jidouqie.com/')">没有 Key？去开通 ↗</a></div>
    <div class="relaywarn" id="ai-relay-warn" style="display:none">⚠️ 你填的不是官方中转站。本工具<b>只对 aihub.jidouqie.com 深度适配</b>，其他站点不保证写文案/生图正常——强烈建议 <a onclick="useRecommended()">一键换成官方站</a>。</div>
    <div class="fld"><span class="lab">API Key</span><input id="ai_api_key" type="password" placeholder="粘贴 API Key（sk-…）"></div>
    <div class="row"><button id="t-ai" onclick="testAI()">保存并测连通</button></div>
    <div class="res" id="r-ai"></div>
    <div class="fld" style="margin-top:14px"><span class="lab">写文案用哪个模型</span>
      <select id="ai_model_sel"></select><input id="ai_model_inp" style="display:none" placeholder="模型代号"></div>
    <div class="fld"><span class="lab">画图用哪个模型</span>
      <select id="image_model_sel"></select><input id="image_model_inp" style="display:none" placeholder="模型代号"></div>
    <div class="row"><button class="ghost" id="t-img" onclick="testImage()">测一张图</button>
      <span class="hint" style="margin:0">约 15–25 秒，会真出一张封面给你看</span></div>
    <div class="res" id="r-img"></div>
    <div id="img-preview"></div>
  </div>

  <div class="card">
    <div class="cardhead">
      <h2>② 飞书（必需）<span class="badge" id="b-fs">未配置</span></h2>
      <div class="acts">
        <button class="mini" onclick="openUrl('https://open.feishu.cn/app')">创建企业自建应用 ↗</button>
        <button class="mini" id="copy-perms" onclick="copyPerms()">复制要开的权限</button>
      </div>
    </div>
    <p class="sub">用来推送文案到多维表格审核、给你发通知。点「创建企业自建应用」建好应用拿 App ID / Secret；「复制要开的权限」把权限 JSON 复制好，到应用的「权限管理 → 批量导入权限」直接粘贴。</p>
    <div class="fld"><span class="lab">App ID</span><input id="feishu_app_id" placeholder="cli_…"></div>
    <div class="fld"><span class="lab">App Secret</span><input id="feishu_app_secret" type="password" placeholder="粘贴 App Secret"></div>
    <div class="row"><button id="t-fs" onclick="testFeishu()">保存并获取可选接收人</button></div>
    <div class="res" id="r-fs"></div>
    <div id="fs-users"></div>
    <div class="hint">点上面按钮：先验证凭证能不能用，验证通过后会列出你飞书通讯录里的人，<b>选一个接收生成/审核通知的人</b>（通常就是你自己）。App ID 不是密钥可以放心填；Secret 同样只存本地。</div>
  </div>

  <details>
    <summary>③ 代理（可选，多账号防关联才需要）<span class="badge" id="b-px" style="margin-left:8px">未配置</span><span class="px-reg" onclick="event.preventDefault();event.stopPropagation();openUrl('https://www.juliangip.com/user/reg?inviteCode=1001359')">🔗 注册巨量 IP ↗</span></summary>
    <div class="inner">
      <p class="sub" style="margin-top:0">单账号用不上，留空即可。多账号同机发布想换 IP 才填。推荐巨量 IP（点右上角注册），把它的 getips 地址填进来。</p>
      <div class="fld"><span class="lab">代理 API 地址</span><input id="proxy_api_url" placeholder="https://…getips…"></div>
      <div class="row"><button class="ghost" id="t-px" onclick="testProxy()">保存并测取 IP</button></div>
      <div class="res" id="r-px"></div>
    </div>
  </details>

  <button class="big" onclick="done()">完成，回到对话</button>
  <div class="hint" id="foot"></div>
</div>
<script>
const S = __DATA__;
const $ = id => document.getElementById(id);
let fsUserId = S.feishu.user_id || '';   // 选定的通知接收人 open_id

// 飞书自建应用要开的权限（与 /redbeacon-config 引导里的一致）
const PERMS_JSON = '__PERMS_JSON__';  // 渲染时注入（真源：services/feishu_api.permissions_json）

function openUrl(u){ try{ window.open(u, '_blank', 'noopener'); }catch(e){ location.href=u; } }
function useRecommended(){ $('ai_base_url').value = 'https://aihub.jidouqie.com/v1'; $('ai_base_url').focus(); checkRelay(); }
function checkRelay(){
  const v = ($('ai_base_url').value||'').toLowerCase();
  const warn = $('ai-relay-warn');
  if(warn) warn.style.display = (v && v.indexOf('jidouqie')<0) ? '' : 'none';
}
// 跨平台复制（浏览器 clipboard，localhost 即安全上下文，mac/win 通用）；旧环境回落 execCommand
async function copyText(text){
  try{ await navigator.clipboard.writeText(text); return true; }
  catch(e){
    try{
      const ta=document.createElement('textarea'); ta.value=text;
      ta.style.position='fixed'; ta.style.top='-9999px'; document.body.appendChild(ta);
      ta.focus(); ta.select(); const ok=document.execCommand('copy'); document.body.removeChild(ta); return ok;
    }catch(e2){ return false; }
  }
}
async function copyPerms(){
  const b=$('copy-perms'); const ok=await copyText(PERMS_JSON);
  b.textContent = ok ? '已复制 ✓ 去飞书粘贴' : '复制失败，手动选';
  b.classList.toggle('copied', ok);
  setTimeout(()=>{ b.textContent='复制要开的权限'; b.classList.remove('copied'); }, 2800);
}

$('ai_base_url').value = S.ai.base_url || '';
$('ai_api_key').placeholder = S.ai.has_key ? '已配置 ✓（留空＝不改）' : '粘贴 API Key（sk-…）';
$('feishu_app_id').value = S.feishu.app_id || '';
$('feishu_app_secret').placeholder = S.feishu.has_secret ? '已配置 ✓（留空＝不改）' : '粘贴 App Secret';
if(S.proxy.has_url) $('proxy_api_url').placeholder = '已配置 ✓（留空＝不改）';

function setBadge(id, ok){ const b=$(id); b.textContent = ok?'已配置':'未配置'; b.classList.toggle('done', !!ok); }
setBadge('b-ai', S.ai.has_key); setBadge('b-fs', S.feishu.app_id && S.feishu.has_secret && fsUserId); setBadge('b-px', S.proxy.has_url);

// 模型下拉：连上中转站就用下拉，否则手填
function fillModel(selId, inpId, opts, cur){
  const sel=$(selId), inp=$(inpId); cur=cur||'';
  if(opts && opts.length){
    sel.style.display=''; inp.style.display='none';
    let list=opts.slice(); if(cur && list.indexOf(cur)===-1) list.unshift(cur);
    sel.innerHTML = list.map(m=>'<option'+(m===cur?' selected':'')+'>'+m+'</option>').join('');
    if(cur) sel.value=cur;
  } else { sel.style.display='none'; inp.style.display=''; inp.value=cur; }
}
function applyModels(m){
  fillModel('ai_model_sel','ai_model_inp', (m&&m.ok)?m.text:[], S.ai.text_model);
  fillModel('image_model_sel','image_model_inp', (m&&m.ok)?m.image:[], S.ai.image_model);
}
applyModels(S.models);
function modelVal(selId, inpId){ const sel=$(selId); return sel.style.display!=='none'?sel.value:$(inpId).value; }

function fields(){
  return {
    ai_api_key: $('ai_api_key').value,
    ai_base_url: $('ai_base_url').value,
    ai_model: modelVal('ai_model_sel','ai_model_inp'),
    image_model: modelVal('image_model_sel','image_model_inp'),
    feishu_app_id: $('feishu_app_id').value,
    feishu_app_secret: $('feishu_app_secret').value,
    feishu_user_id: fsUserId,
    proxy_api_url: $('proxy_api_url').value,
  };
}
async function post(path){
  const r = await fetch(path,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({fields:fields()})});
  return r.json();
}
function showRes(id, j){ const el=$(id); el.className='res '+(j.ok?'ok':'no'); el.textContent=(j.ok?'✓ ':'✗ ')+(j.ok?(j.msg||'通过'):(j.error||'失败')); }
async function run(btnId, resId, path, after){
  const b=$(btnId); b.disabled=true; b.classList.add('loading');
  let j; try{ j=await post(path); }catch(e){ j={ok:false,error:(e&&e.message)||e}; }
  b.disabled=false; b.classList.remove('loading'); showRes(resId, j); if(after) after(j); return j;
}
function testAI(){ run('t-ai','r-ai','/save-test-ai', j=>{
  if(j.ok){ setBadge('b-ai',true); applyModels(j.models); }
  // 非官方站连不通 → 在结果行下面强提示换官方站
  if(j.recommend_jidouqie){
    $('r-ai').insertAdjacentHTML('afterend',
      '<div class="relaywarn" id="ai-fail-rec">连不上这个站。本工具只对 <b>aihub.jidouqie.com</b> 深度适配，'
      +'其他站点不保证正常运行——<a onclick="useRecommended()">一键换成官方站</a>再试。</div>');
  } else { const e=$('ai-fail-rec'); if(e) e.remove(); }
  checkRelay();
}); }
function esc(s){ return (s==null?'':String(s)).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c])); }
function testImage(){
  $('img-preview').innerHTML='';
  run('t-img','r-img','/save-test-image', j=>{
    if(!j.ok){ $('img-preview').innerHTML=''; return; }
    // 成功：结果行写清「✓ 出图成功」，下面用标签明确列出 模型 / 接口 / 格式 + 图
    $('r-img').className='res ok';
    $('r-img').textContent='✓ 出图成功';
    let meta='<div class="imgmeta">'
      + '<span class="kv"><span>模型</span> <b>'+esc(j.model)+'</b></span>'
      + '<span class="kv"><span>接口</span> <b>'+esc(j.api)+'</b></span>'
      + '<span class="kv"><span>返回格式</span> <b>'+esc(j.fmt)+'</b></span></div>';
    let img = j.image ? '<img class="shot" src="'+j.image+'" alt="测试封面">' : '';
    $('img-preview').innerHTML = meta + img;
  });
}
function renderFeishuUsers(j){
  const box=$('fs-users'); const users=j.users||[];
  if(j.current && !fsUserId) fsUserId=j.current;
  if(!users.length){
    // 拉不到通讯录（多半没开 contact 权限）→ 退化成手填 open_id
    box.innerHTML='<div class="fld" style="margin-top:10px"><span class="lab">接收人 user_id</span>'
      +'<input id="fs-uid-manual" placeholder="ou_… 飞书后台通讯录里复制" value="'+esc(fsUserId)+'"></div>'
      +'<div class="row"><button class="ghost" id="t-fs-save" onclick="saveFeishuUser($(\'fs-uid-manual\').value)">保存接收人</button></div>'
      +(j.note?'<div class="hint" style="color:#caa45a">'+esc(j.note)+'</div>':'');
    return;
  }
  let html='<div class="sub" style="margin:10px 0 6px">选一个接收通知的人：</div><div class="fs-userlist">';
  users.forEach(u=>{
    const sel = (u.user_id===fsUserId);
    html+='<label class="fs-user'+(sel?' on':'')+'"><input type="radio" name="fsu" value="'+esc(u.user_id)+'"'
      +(sel?' checked':'')+' onchange="saveFeishuUser(this.value)"> <b>'+esc(u.name||'(未命名)')+'</b>'
      +'<span class="uid">'+esc(u.user_id)+'</span></label>';
  });
  html+='</div>';
  box.innerHTML=html;
  // 只有一个人 → 直接定他
  if(users.length===1 && !fsUserId){ saveFeishuUser(users[0].user_id); }
}
async function saveFeishuUser(uid){
  uid=(uid||'').trim(); if(!uid) return;
  fsUserId=uid;
  // 高亮选中项
  document.querySelectorAll('#fs-users .fs-user').forEach(el=>{
    el.classList.toggle('on', el.querySelector('input') && el.querySelector('input').value===uid);
  });
  try{ await post('/save'); }catch(e){}
  setBadge('b-fs', true);
  const r=$('r-fs'); r.className='res ok'; r.textContent='✓ 已设接收人，飞书配置完成';
}
function testFeishu(){
  $('fs-users').innerHTML='';
  run('t-fs','r-fs','/save-test-feishu', j=>{ if(j.ok){ renderFeishuUsers(j); } }); }
function testProxy(){ run('t-px','r-px','/save-test-proxy', j=>{ if(j.ok) setBadge('b-px',true); }); }
async function done(){
  try{ await post('/done'); }catch(e){}
  document.body.innerHTML='<div style="padding:80px 30px;text-align:center;color:#8b93a1;font-size:16px">配置已保存 ✓<br><br>请关闭本页，回到对话继续。</div>';
  setTimeout(()=>{try{window.close()}catch(e){}},600);
}
</script>__FOOTER__</body></html>"""
