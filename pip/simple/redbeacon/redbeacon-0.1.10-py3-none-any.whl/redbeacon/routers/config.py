"""config get / set / list / models / test-ai / test-feishu / test-proxy / feishu-users"""
from __future__ import annotations

from redbeacon import config as cfg
from redbeacon.config_keys import (
    CK_AI_API_KEY, CK_AI_BASE_URL, CK_AI_MODEL,
    CK_FEISHU_APP_ID, CK_FEISHU_APP_SECRET,
    CK_PROXY_API_URL,
)
from ._runtime import out, err


def dispatch(args) -> None:
    if args.sub == "get":          _get(args)
    elif args.sub == "set":        _set(args)
    elif args.sub == "list":       _list()
    elif args.sub == "models":     _models()
    elif args.sub == "test-ai":    _test_ai()
    elif args.sub == "test-image": _test_image()
    elif args.sub == "test-feishu": _test_feishu()
    elif args.sub == "test-proxy": _test_proxy()
    elif args.sub == "feishu-users": _feishu_users()
    else:                          err(f"未知 config 子命令：{args.sub}")


def _get(args) -> None:
    out({"key": args.key, "value": cfg.get(args.key)})


def _set(args) -> None:
    cfg.set(args.key, args.value)
    out({"ok": True, "key": args.key})


def _list() -> None:
    out(cfg.get_all_public())


def _models() -> None:
    import httpx
    api_key  = cfg.get(CK_AI_API_KEY)
    base_url = cfg.get(CK_AI_BASE_URL).rstrip("/")
    if not api_key:
        err("AI API Key 未配置", next="redbeacon config set ai_api_key <KEY>")
    try:
        with httpx.Client(trust_env=False, timeout=15) as client:
            resp = client.get(f"{base_url}/models",
                              headers={"Authorization": f"Bearer {api_key}"})
        resp.raise_for_status()
        data = resp.json()
        ids: list[str] = []
        if isinstance(data, dict) and "data" in data:
            ids = [m["id"] for m in data["data"] if isinstance(m, dict) and m.get("id")]
        elif isinstance(data, list):
            ids = [m.get("id") if isinstance(m, dict) else str(m) for m in data]
        elif isinstance(data, dict):
            for key in ("models", "result", "items"):
                if key in data and isinstance(data[key], list):
                    ids = [m.get("id") if isinstance(m, dict) else str(m) for m in data[key]]
                    break
        out({"models": sorted(set(filter(None, ids)))})
    except Exception as e:
        err(f"获取模型列表失败：{e}")


def _test_ai() -> None:
    import httpx
    from openai import OpenAI
    api_key  = cfg.get(CK_AI_API_KEY)
    base_url = cfg.get(CK_AI_BASE_URL)
    model    = cfg.get(CK_AI_MODEL)
    if not api_key:
        err("AI API Key 未配置", next="redbeacon config set ai_api_key <KEY>")
    try:
        client = OpenAI(api_key=api_key, base_url=base_url,
                        http_client=httpx.Client(trust_env=False, timeout=20))
        resp = client.chat.completions.create(
            model=model,
            messages=[{"role": "user", "content": '回复"ok"两个字'}],
            max_tokens=10,
        )
        out({"ok": True, "reply": resp.choices[0].message.content.strip(), "model": model})
    except Exception as e:
        err(f"AI 连接失败：{e}")


def _test_image() -> None:
    """真实调一次图片模型，确认能连通且能返回图片数据（约一张图的成本）。

    直连 API（不走 image_gen 的吞错包装），好把真实失败原因暴露给用户。
    """
    import httpx
    from openai import OpenAI
    from redbeacon.config_keys import CK_IMAGE_MODEL
    api_key  = cfg.get(CK_AI_API_KEY)
    base_url = cfg.get(CK_AI_BASE_URL)
    model    = cfg.get(CK_IMAGE_MODEL).strip()
    if not api_key:
        err("AI API Key 未配置", next="redbeacon config set ai_api_key <KEY>")
    if not model:
        err("图片模型未配置", next="redbeacon config set image_model <模型名>")
    try:
        client = OpenAI(api_key=api_key, base_url=base_url, max_retries=0,
                        http_client=httpx.Client(trust_env=False, timeout=120))
        resp = client.chat.completions.create(
            model=model,
            messages=[{"role": "user",
                       "content": "生成一个简单的红色圆形图标，纯色背景，极简风格"}],
            modalities=["image", "text"],
        )
    except Exception as e:
        err(f"图片模型连接失败：{e}")
    from redbeacon.services.image_gen import _extract_image_refs
    refs = _extract_image_refs(resp.choices[0].message.content)
    if not refs:
        err("已连通但未返回图片数据（该模型可能不支持文生图，或模型名有误）",
            next="redbeacon config models  # 换一个支持文生图的模型")
    kind = "URL" if refs[0].startswith("http") else "base64"
    out({"ok": True, "model": model, "msg": f"✓ 图片模型连通，成功返回图片数据（{kind} 格式）"})


def _test_feishu() -> None:
    from redbeacon.services.feishu_api import FeishuAPI
    app_id     = cfg.get(CK_FEISHU_APP_ID)
    app_secret = cfg.get(CK_FEISHU_APP_SECRET)
    if not app_id or not app_secret:
        err("飞书凭证未配置（feishu_app_id / feishu_app_secret）",
            next="redbeacon config set feishu_app_id cli_xxx && redbeacon config set feishu_app_secret <SECRET>")
    try:
        FeishuAPI.verify_credentials(app_id, app_secret)
    except Exception as e:
        err(str(e))
    out({"ok": True, "msg": "✓ App ID / Secret 验证通过"})


def _test_proxy() -> None:
    """验证 proxy_api_url 能否取到一个可用 IP（一次真实取 IP，约 0.05 元）。"""
    from redbeacon.services import proxy_service
    url = cfg.get(CK_PROXY_API_URL).strip()
    if not url:
        err("代理 API URL 未配置（不配则不走代理）",
            next="redbeacon config set proxy_api_url <巨量 getips URL>")
    proxy = proxy_service.fetch_fresh_proxy()
    if not proxy:
        err("代理 API 未返回可用 IP，请检查 URL / trade_no / sign / 套餐余额")
    out({"ok": True, "proxy": proxy})


def _feishu_users() -> None:
    from redbeacon.services.feishu_api import FeishuAPI
    app_id     = cfg.get(CK_FEISHU_APP_ID)
    app_secret = cfg.get(CK_FEISHU_APP_SECRET)
    if not app_id or not app_secret:
        err("飞书凭证未配置", next="redbeacon config set feishu_app_id <ID>")
    try:
        FeishuAPI.verify_credentials(app_id, app_secret)
        feishu = FeishuAPI(app_id, app_secret, "", "")
        users = feishu.list_contact_users()
    except Exception as e:
        err(str(e))
    out({"users": users})
