"""CLI 输出 JSON shape 的契约定义。

每个子命令的 stdout 输出由一个 TypedDict 描述；skill 端可以按 schema 安全解析。
错误输出统一为 {"error": str}，由 _err() 在 cli.py 输出，无需在此声明。

约定：
  - 字段类型只用 JSON 友好类型（str/int/bool/list/dict/None）
  - 加密字段在响应里返回哨兵字符串 "__SET__" 而非明文
  - 时间统一 ISO8601 字符串（UTC）
  - 跨命令复用的子结构（Account, ContentRow 等）单独定义 TypedDict
"""
from __future__ import annotations

from typing import TypedDict


# ── 通用错误 ──────────────────────────────────────────────────────────────────

class ErrorResponse(TypedDict, total=False):
    """所有非零 exit code 命令的 stderr 输出。

    next: 可选，建议的修复命令。skill 端可据此自愈或提示用户。
    """
    error: str
    next: str


# ── readiness ─────────────────────────────────────────────────────────────────

class ReadinessChecks(TypedDict):
    ai_ok: bool
    feishu_ok: bool
    has_account: bool
    has_login: bool
    niche_ok: bool


class ReadinessResp(TypedDict):
    stage: str                  # stage1 / stage2 / stage3 / stage4 / ready
    checks: ReadinessChecks
    reasons: list[str]
    next: str                   # 下一步建议命令；ready 时为 ""
    feishu_required: bool       # 当前为 False（飞书可选）


# ── accounts ──────────────────────────────────────────────────────────────────

class Account(TypedDict, total=False):
    id: int
    display_name: str | None
    nickname: str | None
    xhs_user_id: str | None
    cookie_file: str | None
    proxy: str | None
    session_running: bool   # 运行时计算字段：进程内 CloakBrowser 会话是否在跑
    login_status: str       # logged_in / logged_out / unknown
    last_login_check: str | None
    feishu_app_token: str | None
    feishu_table_id: str | None
    feishu_user_id: str | None
    auto_generate_enabled: int
    generate_schedule_json: str | None
    created_at: str
    updated_at: str


# accounts list → list[Account]
# accounts get  → Account
# accounts create → Account
# accounts patch → Account
# accounts delete → OkResponse


class OkResponse(TypedDict):
    ok: bool


# ── login ─────────────────────────────────────────────────────────────────────

class LoginStart(TypedDict, total=False):
    logged_in: bool
    nickname: str
    msg: str                 # 流式过程消息


class LoginVerify(TypedDict, total=False):
    logged_in: bool
    nickname: str
    error: str               # 仅在 logged_in=False 且需要说明时


class LoginStatus(TypedDict):
    login_status: str
    nickname: str | None


# ── strategy ──────────────────────────────────────────────────────────────────

class StrategyRow(TypedDict, total=False):
    id: int
    account_id: int
    version: int
    data: str                # JSON 序列化串
    niche: str | None
    posting_freq: str | None
    created_at: str
    updated_at: str


class StrategyPatchResp(TypedDict):
    ok: bool
    fields: list[str]


# ── topics ────────────────────────────────────────────────────────────────────

class Topic(TypedDict):
    id: int
    account_id: int
    content_type: str
    content: str
    is_used: int
    used_at: str | None
    created_at: str


class TopicBatchResp(TypedDict):
    inserted: int
    total: int


class TopicStatsByType(TypedDict):
    content_type: str
    total: int
    unused: int


class TopicStats(TypedDict):
    total: int
    unused: int
    used: int
    by_type: list[TopicStatsByType]


class TopicInspireResp(TypedDict):
    options: list[str]


class ContentType(TypedDict):
    id: int
    account_id: int
    name: str
    prompt_template: str
    is_active: int
    sort_order: int
    created_at: str
    updated_at: str


# ── content ───────────────────────────────────────────────────────────────────

class ContentRow(TypedDict, total=False):
    id: int
    account_id: int
    topic: str
    content_type: str | None
    pillar_name: str | None
    title: str | None
    body: str | None
    tags: list[str]                  # 反序列化为 list
    images: list[str]                # 反序列化为 list
    image_prompt: str | None
    visual_theme: str | None
    status: str                      # pending_review / published / failed（审核在飞书，本地无审核态）
    scheduled_at: str | None
    published_at: str | None
    xhs_note_id: str | None
    feishu_record_id: str | None
    error_msg: str | None
    created_at: str
    updated_at: str


class ContentFeishuPushResp(TypedDict):
    ok: bool
    pushed: int


# ── generate ──────────────────────────────────────────────────────────────────

class GenerateResp(TypedDict):
    ok: bool
    content_id: int


# stderr 流式进度（一行一个 JSON）：
class GenerateProgressEvent(TypedDict, total=False):
    progress: int          # step
    # 其他字段视 step 而定（topic / title / image_count ...）


# ── publish ───────────────────────────────────────────────────────────────────

class PublishResp(TypedDict):
    ok: bool
    synced: int            # 本次飞书同步条数
    published: int         # 本次实际发布成功数


# ── feishu ────────────────────────────────────────────────────────────────────

class FeishuSyncResp(TypedDict):
    ok: bool
    synced: int


class FeishuSetupResp(TypedDict, total=False):
    ok: bool
    skipped: bool          # 已配置则返回 skipped=true 而不重复 setup
    app_token: str
    table_id: str


class FeishuTestResp(TypedDict, total=False):
    table_write: str       # "✓ 写入成功" 或 "✗ 写入失败：xxx"
    table_delete: str
    message: str


# ── config ────────────────────────────────────────────────────────────────────

class ConfigGetResp(TypedDict):
    key: str
    value: str             # 加密字段返回明文或 __SET__（list 命令）


class ConfigSetResp(TypedDict):
    ok: bool
    key: str


# config list → dict[str, str]（key → value 或 __SET__）

class ConfigModelsResp(TypedDict):
    models: list[str]


class ConfigTestAIResp(TypedDict):
    ok: bool
    reply: str
    model: str


class ConfigTestFeishuResp(TypedDict):
    ok: bool
    msg: str


class FeishuUser(TypedDict):
    user_id: str           # open_id 形式
    name: str


class ConfigFeishuUsersResp(TypedDict):
    users: list[FeishuUser]


# ── status ────────────────────────────────────────────────────────────────────

class StatusAccountSummary(TypedDict):
    id: int
    display_name: str | None
    login_status: str
    nickname: str | None


class StatusPaths(TypedDict):
    data_dir: str
    log_dir: str
    db: str
    profiles: str
    images: str


class StatusResp(TypedDict):
    accounts: list[StatusAccountSummary]
    content_counts: dict[str, int]
    paths: StatusPaths
    ai_base_url: str
    ai_api_key: str        # "__SET__" 或 ""
    ai_model: str
    image_model: str
    feishu_app_id: str
    feishu_app_secret: str # "__SET__" 或 ""


# ── logs ──────────────────────────────────────────────────────────────────────

class LogsResp(TypedDict):
    lines: list[str]
