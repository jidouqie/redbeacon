"""全局配置读写（settings 表）。

支持两种 key 形态：
  - 字符串："ai_api_key"
  - Key 常量：config_keys.CK_AI_API_KEY（推荐，附带默认值、加密标志）

敏感字段（is encrypted=True）写入时自动加密，读取时自动解密。
"""
from __future__ import annotations

import logging
from typing import Union

from redbeacon.database import conn
from redbeacon.utils.crypto import encrypt, decrypt
from redbeacon.config_keys import Key, ENCRYPTED_KEY_NAMES, ALL_KEYS

_log = logging.getLogger("config")

KeyArg = Union[str, Key]


def _name_and_default(key: KeyArg, default: str) -> tuple[str, str]:
    if isinstance(key, Key):
        return key.name, (default if default else key.default)
    return key, default


def get(key: KeyArg, default: str = "") -> str:
    name, default = _name_and_default(key, default)
    c = conn()
    row = c.execute(
        "SELECT value, is_encrypted FROM settings WHERE key=?", (name,)
    ).fetchone()
    c.close()
    if row is None:
        return default
    value = row["value"]
    if row["is_encrypted"] and value:
        try:
            value = decrypt(value)
        except Exception:
            _log.warning(
                "配置项 '%s' 解密失败（可能是机器迁移导致密钥不匹配），"
                "请重新保存该字段", name,
            )
            c2 = conn()
            c2.execute(
                "UPDATE settings SET value='', updated_at=datetime('now') WHERE key=?",
                (name,),
            )
            c2.commit()
            c2.close()
            return default
    return value


def set(key: KeyArg, value: str) -> None:
    name = key.name if isinstance(key, Key) else key
    is_enc = 1 if name in ENCRYPTED_KEY_NAMES else 0
    stored = encrypt(value) if is_enc and value else value
    c = conn()
    c.execute(
        """INSERT INTO settings (key, value, is_encrypted, updated_at)
           VALUES (?, ?, ?, datetime('now'))
           ON CONFLICT(key) DO UPDATE SET
               value=excluded.value,
               is_encrypted=excluded.is_encrypted,
               updated_at=excluded.updated_at""",
        (name, stored, is_enc),
    )
    c.commit()
    c.close()


_SENTINEL = "__SET__"   # 表示"已设置但不回传明文"


def get_all_public() -> dict:
    """返回所有配置；加密字段已设置则返回哨兵值 __SET__，未设置或解密失败返回 ""。"""
    c = conn()
    rows = c.execute("SELECT key, value, is_encrypted FROM settings").fetchall()
    c.close()
    result: dict[str, str] = {}
    for r in rows:
        if r["is_encrypted"]:
            if not r["value"]:
                result[r["key"]] = ""
            else:
                try:
                    decrypt(r["value"])
                    result[r["key"]] = _SENTINEL
                except Exception:
                    result[r["key"]] = ""
        else:
            result[r["key"]] = r["value"]
    return result


def registered_keys() -> tuple[Key, ...]:
    """供 CLI / 文档使用：枚举所有注册的 key。"""
    return ALL_KEYS
