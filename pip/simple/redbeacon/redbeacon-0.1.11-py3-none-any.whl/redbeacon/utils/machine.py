"""机器码：本机唯一标识，稳定（同机不变）且区分机器。

用途：作为 Ed25519 解锁码的签名对象，把解锁码绑定到具体机器（见 services/license.py）。
发码端对该字符串签名即可，无需复现本函数。
"""
from __future__ import annotations

import hashlib
import platform
import uuid


def machine_code() -> str:
    raw = f"{platform.system()}|{platform.node()}|{uuid.getnode():012x}"
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()[:16].upper()
