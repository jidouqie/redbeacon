"""默认数据/日志目录解析。

约定：安装后数据落 ~/.redbeacon/{data,logs}/，可被环境变量覆盖。
- REDBEACON_DATA_DIR：覆盖数据目录（含 SQLite、cookies、profiles、images）
- REDBEACON_LOG_DIR ：覆盖日志目录
"""
from __future__ import annotations

import os
from pathlib import Path


def _home_redbeacon() -> Path:
    return Path(os.path.expanduser("~")) / ".redbeacon"


def default_data_dir() -> Path:
    return _home_redbeacon() / "data"


def default_log_dir() -> Path:
    return _home_redbeacon() / "logs"
