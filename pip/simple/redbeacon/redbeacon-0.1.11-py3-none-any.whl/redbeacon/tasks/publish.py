"""
发布任务：取「通过」状态的记录，下载图片，经 CloakBrowser 发布到小红书。

数据源唯一：飞书「通过」记录（飞书未配齐则跳过，router 已前置拦截，本地无审核态）。
流程：读飞书通过记录 → 下载图片 → CloakBrowser 发布 → 回写「已发布」→ 更新本地 DB → 飞书通知。

由 `redbeacon publish` 命令触发，单次跑完即退出；无常驻调度器，
周期性发布请交给外部 cron / launchd / CI。定时发布走小红书平台原生定时
功能（publish_image(schedule_time=...)），不依赖本地进程常驻。
"""
import os
import re
import json
import time
import random
import threading
from datetime import datetime, timezone, timedelta
from pathlib import Path

_publish_lock = threading.Lock()
_cancel_flag = threading.Event()


def _markdown_to_plain(md: str) -> str:
    """把轻量 Markdown 清成小红书正文用的干净文字（保留换行与可读结构）。
    卡片渲染吃 Markdown，但小红书正文不渲染——发布前去掉 #、**、>、` 等符号。"""
    if not md:
        return md
    out_lines = []
    for line in md.split("\n"):
        s = line.rstrip()
        # 标题：去掉行首 #，保留文字
        s = re.sub(r'^\s{0,3}#{1,6}\s*', '', s)
        # 引用：去掉行首 >
        s = re.sub(r'^\s{0,3}>\s?', '', s)
        # 无序列表项：- / * / + → 用「· 」更适合小红书
        s = re.sub(r'^(\s*)[-*+]\s+', r'\1· ', s)
        out_lines.append(s)
    text = "\n".join(out_lines)
    # 行内：粗体/斜体/删除线/行内代码，仅去符号留文字
    text = re.sub(r'\*\*(.+?)\*\*', r'\1', text)
    text = re.sub(r'__(.+?)__', r'\1', text)
    text = re.sub(r'(?<!\*)\*(?!\*)(.+?)(?<!\*)\*(?!\*)', r'\1', text)
    text = re.sub(r'~~(.+?)~~', r'\1', text)
    text = re.sub(r'`([^`]+)`', r'\1', text)
    # 残留的行首裸 # 或多余空行收一收
    text = re.sub(r'\n{3,}', '\n\n', text)
    return text.strip()


def cancel_publish() -> None:
    """请求取消当前发布任务（非阻塞，设置标志位）。"""
    _cancel_flag.set()


def is_publish_running() -> bool:
    return _publish_lock.locked()

from redbeacon import database
from redbeacon import config as cfg
from redbeacon.config_keys import (
    CK_FEISHU_APP_ID, CK_FEISHU_APP_SECRET, CK_FEISHU_USER_ID,
    CK_BROWSER_VISIBLE, CK_DATA_DIR,
    CK_PUBLISH_IS_ORIGINAL, CK_PUBLISH_IS_AI_GENERATED, CK_PUBLISH_VISIBILITY,
    CK_PUBLISH_MIN_INTERVAL, CK_PUBLISH_MAX_INTERVAL, CK_PUBLISH_RERENDER_CARDS,
    CK_PROXY_AUTO_ROTATE, CK_PROXY_API_URL, CK_PROXY_SPEED_TEST,
)
from redbeacon.services import xhs
from redbeacon.services.feishu_api import (
    FIELD_TITLE, FIELD_BODY, FIELD_TAGS, FIELD_IMAGES, FIELD_STATUS,
    FIELD_SCHEDULE_AT, STATUS_PUBLISHED, STATUS_FAILED, STATUS_APPROVED,
)
from redbeacon.utils.logger import get_logger

logger = get_logger("tasks.publish")

REQUEST_TIMEOUT = 120

_RETRYABLE_KEYWORDS = [
    "timeout", "connection", "network",
    "timed out", "connection reset", "connection refused",
    "publish_failed", "没有找到", "自动化失败",
]


def _is_retryable_error(msg: str) -> bool:
    m = str(msg).lower()
    return any(kw in m for kw in _RETRYABLE_KEYWORDS)


def _resolve_schedule_at(raw_value):
    """飞书「发布时间」毫秒时间戳 → CST datetime，或 None（立即发布）。"""
    if not raw_value:
        return None
    try:
        ts_ms = int(raw_value)
        schedule_dt = datetime.fromtimestamp(ts_ms / 1000, tz=timezone.utc)
    except Exception:
        return None
    delta = schedule_dt - datetime.now(timezone.utc)
    if delta < timedelta(hours=1) or delta > timedelta(days=14):
        return None
    CST = timezone(timedelta(hours=8))
    return schedule_dt.astimezone(CST)


def _int_cfg(key, default: int) -> int:
    try:
        return int(float(cfg.get(key)))
    except Exception:
        return default


# 小红书图文：正文 + 话题（标签也打进正文编辑器）合计字数上限。
_XHS_INPUT_MAX = 1000


def _estimate_input_len(body: str, tags: list) -> int:
    """估算小红书正文编辑器的合计字数 = 正文 + 各话题（含 #）。
    略偏保守：每个标签按 #+词 计。用于发布前 fail-fast，真值仍以页面 length-error 为准。"""
    tag_len = sum(len(str(t).lstrip("#")) + 1 for t in (tags or []))
    return len(body or "") + tag_len


def _maybe_rerender_cards(account_id, record_id, content_raw, title, tags):
    """飞书正文若相对生成时已改动、且该内容是纯图文卡片，则按新正文重渲卡片。

    返回新卡片本地路径列表；任何条件不满足或渲染失败都返回 None（回落到飞书原附件）。
    只处理"纯卡片"内容（无 AI 封面），避免动到图文混排里语义不明的图。
    """
    if cfg.get(CK_PUBLISH_RERENDER_CARDS).lower() != "true":
        return None
    try:
        with database.cursor() as c:
            row = c.execute(
                "SELECT body, images, visual_theme FROM content_queue WHERE feishu_record_id=?",
                (record_id,),
            ).fetchone()
        if not row:
            return None
        stored_imgs = json.loads(row["images"] or "[]")
        # 纯卡片判定：有图且每张都来自 cards_ 目录（AI 封面是 ai_image_*.jpg，不含 cards_）
        if not stored_imgs or not all("cards_" in str(p) for p in stored_imgs):
            return None
        # 正文是否被改过：比对纯文本形态，没改就别折腾，保留原卡片
        new_plain = _markdown_to_plain(re.sub(r'\s*(#[^\s#]+\s*)+$', '', content_raw)).strip()
        old_plain = (row["body"] or "").strip()
        if not new_plain or new_plain == old_plain:
            return None
        card_theme = "default"
        with database.cursor() as c2:
            s = c2.execute("SELECT card_theme FROM image_strategy WHERE account_id=?",
                           (account_id,)).fetchone()
            if s and s["card_theme"]:
                card_theme = s["card_theme"]
        card_md = re.sub(r'\s*(#[^\s#]+\s*)+$', '', content_raw).rstrip()
        if tags:
            card_md += "\n\n" + " ".join(t if t.startswith("#") else f"#{t}" for t in tags)
        from redbeacon.tasks.generate import _render_cards
        data_dir = Path(os.environ.get("REDBEACON_DATA_DIR") or cfg.get(CK_DATA_DIR)).resolve()
        paths = _render_cards(
            title, card_md, row["visual_theme"] or "default", card_theme,
            save_dir=str(data_dir / "images"),
            cover_emoji="📌", cover_subtitle=title[:18],
        )
        if paths:
            logger.info(f"[publish] 《{title}》正文已改动，按飞书新正文重渲 {len(paths)} 张卡片")
            return paths
    except Exception as e:
        logger.warning(f"[publish] 卡片重渲失败，回落飞书原图：{e}")
    return None


def preview_publish(account_id: int = 1) -> dict:
    """发布前预览：列出飞书「通过」记录的发布属性 + 全局发布配置。
    纯读取，不启动浏览器、不下载图片、不发布——给 skill 做发布前确认用。"""
    app_id     = cfg.get(CK_FEISHU_APP_ID)
    app_secret = cfg.get(CK_FEISHU_APP_SECRET)
    with database.cursor() as c:
        acc = c.execute(
            "SELECT feishu_app_token, feishu_table_id FROM account WHERE id=?",
            (account_id,),
        ).fetchone()
    app_token = acc["feishu_app_token"] if acc else None
    table_id  = acc["feishu_table_id"]  if acc else None

    from redbeacon.services.feishu_api import FeishuAPI
    feishu = FeishuAPI(app_id, app_secret, app_token, table_id)
    records = feishu.get_approved_records()

    items = []
    for record in records:
        fields = record.get("fields", {})
        title = fields.get(FIELD_TITLE, "") or ""
        body  = fields.get(FIELD_BODY, "") or ""
        attachments = fields.get(FIELD_IMAGES, []) or []
        sched = _resolve_schedule_at(fields.get(FIELD_SCHEDULE_AT))
        items.append({
            "title": title,
            "body_preview": body[:80] + ("…" if len(body) > 80 else ""),
            "body_length": len(body),
            "image_count": len(attachments),
            "schedule": sched.strftime("%Y-%m-%d %H:%M") if sched else "立即发布",
        })

    proxy_url = cfg.get(CK_PROXY_API_URL).strip()
    rotate = cfg.get(CK_PROXY_AUTO_ROTATE).lower() == "true"
    return {
        "count": len(items),
        "items": items,
        "config": {
            "browser_visible": cfg.get(CK_BROWSER_VISIBLE).lower() == "true",
            "mark_ai_generated": cfg.get(CK_PUBLISH_IS_AI_GENERATED).lower() != "false",
            "mark_original": cfg.get(CK_PUBLISH_IS_ORIGINAL).lower() == "true",
            "visibility": cfg.get(CK_PUBLISH_VISIBILITY) or "公开可见",
            "proxy_configured": bool(proxy_url),
            "proxy_rotate": bool(proxy_url) and rotate,
        },
    }


def run_publish(account_id: int = 1) -> int:
    """从飞书读取「通过」记录，逐条下载图片并发布。返回本次成功发布数。"""
    if not _publish_lock.acquire(blocking=False):
        logger.warning("[publish] 上一次发布任务仍在运行中，跳过本次触发（防重复发布）")
        return 0
    try:
        if _cancel_flag.is_set():
            logger.info("[publish] 启动前检测到取消信号，跳过")
            return 0
        _cancel_flag.clear()
        return _run_publish_inner(account_id)
    finally:
        _publish_lock.release()


def _run_publish_inner(account_id: int = 1) -> int:
    """从飞书读「通过」记录发布（唯一数据源）；飞书未配齐则跳过（router 已前置拦截）。"""
    app_id     = cfg.get(CK_FEISHU_APP_ID)
    app_secret = cfg.get(CK_FEISHU_APP_SECRET)
    with database.cursor() as c0:
        acc = c0.execute(
            "SELECT feishu_app_token, feishu_table_id, display_name, nickname FROM account WHERE id=?",
            (account_id,),
        ).fetchone()
    app_token    = acc["feishu_app_token"] if acc else None
    table_id     = acc["feishu_table_id"]  if acc else None
    user_id      = cfg.get(CK_FEISHU_USER_ID) or ""
    account_name = (acc["display_name"] or acc["nickname"] or f"账号{account_id}") if acc else f"账号{account_id}"

    feishu_ready = all([app_id, app_secret, app_token, table_id])
    if not feishu_ready:
        # 发布唯一数据源是飞书；router 已前置拦截，这里是防御性兜底
        logger.warning("[publish] 飞书未配置，发布数据源缺失，跳过")
        return 0

    from redbeacon.services.feishu_api import FeishuAPI
    feishu = FeishuAPI(app_id, app_secret, app_token, table_id)

    # 直接从飞书读取「通过」记录
    try:
        records = feishu.get_approved_records()
    except Exception as e:
        logger.error(f"[publish] 读取飞书审核记录失败: {e}")
        return 0

    if not records:
        return 0

    logger.info(f"[publish] 账号 {account_id} 发现 {len(records)} 条待发布（飞书源）")

    # 有待发布内容才检查登录状态
    with database.cursor() as c:
        row = c.execute("SELECT cookie_file FROM account WHERE id=?", (account_id,)).fetchone()
    if not row:
        logger.warning(f"[publish] 账号 {account_id} 不存在")
        return 0
    cookie_file = row["cookie_file"] or ""

    # 1. 先确保 CloakBrowser 会话在跑（不带代理），再检查登录状态
    headless = cfg.get(CK_BROWSER_VISIBLE).lower() != "true"
    if not xhs.session.is_running(account_id):
        if not cookie_file:
            logger.warning(f"[publish] 账号 {account_id} 尚未登录，跳过")
            return 0
        try:
            xhs.session.start(account_id, headless=headless)
        except Exception as e:
            logger.warning(f"[publish] 账号 {account_id} 浏览器启动失败：{e}")
            return 0

    try:
        status = xhs.login.check_login_status(account_id)
        is_logged_in = bool(status.get("is_logged_in"))
    except Exception as e:
        logger.warning(f"[publish] 账号 {account_id} 登录态查询失败：{e}")
        return 0

    if not is_logged_in:
        logger.warning(f"[publish] 账号 {account_id} 小红书未登录，跳过")
        if user_id:
            try:
                feishu.send_text_message(user_id, f"[{account_name}] 小红书已掉线，请在账号页重新登录")
            except Exception:
                pass
        return 0

    # 2. check_login_status 内部强制用 headless=True，需要在这里对齐回目标 headless
    current_sess = xhs.session.get(account_id)
    if current_sess and current_sess.headless != headless:
        logger.info(f"[publish] 重启会话以应用 headless={headless}")
        xhs.session.stop(account_id)
        try:
            xhs.session.start(account_id, headless=headless)
        except Exception as e:
            logger.warning(f"[publish] 重启会话失败：{e}")
            return 0

    # 3. 登录确认后再换 IP 重启会话，代理只用于实际发布
    _setup_fresh_proxy(account_id)

    # 准备图片存放根目录
    data_dir = Path(os.environ.get("REDBEACON_DATA_DIR") or cfg.get(CK_DATA_DIR)).resolve()
    img_root = data_dir / "images"
    img_root.mkdir(parents=True, exist_ok=True)

    success = 0
    for record in records:
        if _cancel_flag.is_set():
            logger.info("[publish] 收到取消信号，中止发布")
            break

        record_id = record.get("record_id", "")
        fields    = record.get("fields", {})

        title       = fields.get(FIELD_TITLE, "") or ""
        content_raw = fields.get(FIELD_BODY, "") or ""
        tags_raw    = fields.get(FIELD_TAGS, "") or ""
        schedule_at = _resolve_schedule_at(fields.get(FIELD_SCHEDULE_AT))
        attachments = fields.get(FIELD_IMAGES, []) or []

        tags = [t.strip() for t in tags_raw.split("、") if t.strip()] if tags_raw else []
        body_clean = re.sub(r'\n+(#[\w\u4e00-\u9fa5 ]+)+$', '', content_raw).strip()
        # \u6b63\u6587\u91cc\u82e5\u5e26\u8f7b\u91cf Markdown\uff08## \u5c0f\u6807\u9898 / **\u52a0\u7c97** / > \u91d1\u53e5 / - \u5217\u8868\uff0c\u7528\u4e8e\u6392\u7248\u5361\u7247\uff09\uff0c
        # \u53d1\u5e03\u5230\u5c0f\u7ea2\u4e66\u524d\u6e05\u6210\u5e72\u51c0\u6587\u5b57\u2014\u2014\u5c0f\u7ea2\u4e66\u6b63\u6587\u4e0d\u6e32\u67d3 Markdown\uff0c\u7559\u7740\u7b26\u53f7\u4f1a\u5f88\u4e11
        body_clean = _markdown_to_plain(body_clean)

        # 飞书正文改过且是纯卡片 → 按新正文重渲卡片，否则用飞书原附件
        prerendered = _maybe_rerender_cards(account_id, record_id, content_raw, title, tags)

        ok = _publish_one(
            account_id=account_id,
            record_id=record_id,
            title=title,
            body=body_clean,
            tags=tags,
            schedule_at=schedule_at,
            attachments=attachments,
            prerendered_images=prerendered,
            img_root=img_root,
            feishu=feishu,
            user_id=user_id,
        )
        if ok:
            success += 1

        if record != records[-1] and not _cancel_flag.is_set():
            lo = _int_cfg(CK_PUBLISH_MIN_INTERVAL, 30)
            hi = _int_cfg(CK_PUBLISH_MAX_INTERVAL, 90)
            if hi < lo:
                lo, hi = hi, lo
            wait = random.randint(lo, hi)
            logger.info(f"[publish] 等待 {wait}s 后继续下一条")
            for _ in range(wait):
                if _cancel_flag.is_set():
                    break
                time.sleep(1)

    xhs.session.stop(account_id)
    logger.info(f"[publish] 账号 {account_id} 发布完成，会话已停止")
    return success


def _publish_one(
    *,
    account_id: int,
    record_id: str,
    title: str,
    body: str,
    tags: list,
    schedule_at,
    attachments: list,
    img_root: Path,
    feishu,
    user_id: str | None,
    prerendered_images: list | None = None,
) -> bool:

    # fail-fast：正文+话题超小红书上限，直接标失败，别白下载/上传一遍图（旧内容或飞书改长会触发）
    est_len = _estimate_input_len(body, tags)
    if est_len >= _XHS_INPUT_MAX:
        msg = (f"正文+话题约 {est_len} 字，超过小红书上限 {_XHS_INPUT_MAX}；"
               "请在飞书把正文删短后把状态改回「通过」再发")
        logger.warning(f"[publish] 《{title}》{msg}")
        _mark_failed(account_id, record_id, title, msg, feishu, user_id)
        return False

    # 本地已重渲卡片则直接用，跳过飞书附件下载；否则下载飞书附件
    if prerendered_images:
        local_images = list(prerendered_images)
    else:
        ts = str(int(time.time()))
        img_dir = img_root / f"publish_{ts}"
        img_dir.mkdir(parents=True, exist_ok=True)
        local_images = []
        try:
            for i, att in enumerate(attachments):
                file_token = att.get("file_token") or att.get("token", "")
                if not file_token:
                    continue
                local_path = str(img_dir / f"{ts}_{i}.jpg")
                feishu.download_image(file_token, local_path)
                local_images.append(local_path)
        except Exception as e:
            err = str(e)
            logger.error(f"[publish] 《{title}》图片下载失败：{err}")
            if not _is_retryable_error(err):
                _mark_failed(account_id, record_id, title, err, feishu, user_id)
            return False

    if not local_images:
        logger.warning(f"[publish] 《{title}》无图片，跳过")
        _mark_failed(account_id, record_id, title, "无图片，无法发布图文笔记", feishu, user_id)
        return False

    is_original     = cfg.get(CK_PUBLISH_IS_ORIGINAL).lower() == "true"
    is_ai_generated = cfg.get(CK_PUBLISH_IS_AI_GENERATED).lower() != "false"
    visibility      = cfg.get(CK_PUBLISH_VISIBILITY) or "公开可见"

    schedule_label = schedule_at.strftime("%Y-%m-%d %H:%M") if schedule_at else "立即"
    logger.info(f"[publish] 发布《{title}》，定时={schedule_label}")

    MAX_ATTEMPTS = 3
    RETRY_DELAYS = [10, 30]  # seconds between attempt 1→2 and 2→3

    last_err = ""
    data: dict = {}
    for attempt in range(1, MAX_ATTEMPTS + 1):
        try:
            data = xhs.publish.publish_image(
                account_id,
                title=title[:20],
                content=body,
                images=local_images,
                tags=tags,
                schedule_time=schedule_at,
                is_original=is_original,
                is_ai_generated=is_ai_generated,
                visibility=visibility,
            )
            break  # success
        except Exception as e:
            last_err = str(e)
            if attempt < MAX_ATTEMPTS and _is_retryable_error(last_err):
                delay = RETRY_DELAYS[attempt - 1]
                logger.warning(f"[publish] 《{title}》发布失败（第{attempt}次），{delay}s 后重试：{last_err}")
                time.sleep(delay)
                continue
            logger.error(f"[publish] 《{title}》发布失败（已重试{attempt-1}次）：{last_err}")
            if not _is_retryable_error(last_err):
                _mark_failed(account_id, record_id, title, last_err, feishu, user_id)
            return False

    # 发布成功
    note_id = data.get("post_id", "") if isinstance(data, dict) else ""
    now = datetime.now(timezone.utc).isoformat()

    try:
        feishu.update_record(record_id, {FIELD_STATUS: STATUS_PUBLISHED})
    except Exception as e:
        logger.warning(f"[publish] 飞书状态回写失败：{e}")

    with database.cursor(commit=True) as c:
        c.execute(
            "UPDATE content_queue SET status='published', xhs_note_id=?, published_at=?, updated_at=?"
            " WHERE feishu_record_id=?",
            (note_id, now, now, record_id),
        )
        local = c.execute("SELECT id FROM content_queue WHERE feishu_record_id=?", (record_id,)).fetchone()
        if local:
            c.execute(
                "INSERT INTO publish_log (content_id, account_id, xhs_note_id, status, published_at)"
                " VALUES (?, ?, ?, 'success', ?)",
                (local["id"], account_id, note_id, now),
            )

    if schedule_at:
        msg = f"《{title}》已提交定时发布（{schedule_at.strftime('%Y-%m-%d %H:%M')}）"
    else:
        msg = f"《{title}》已立即发布 ✓"
    logger.info(f"[publish] {msg}")

    if user_id:
        try:
            feishu.send_text_message(user_id, msg)
        except Exception:
            pass

    return True


def _setup_fresh_proxy(account_id: int) -> None:
    """发布前取一个新 IP 重启浏览器会话，不存 DB，用完即废。未配置或未开启代理轮换则跳过。"""
    if cfg.get(CK_PROXY_AUTO_ROTATE).lower() != "true":
        return
    if not cfg.get(CK_PROXY_API_URL).strip():
        return

    from redbeacon.services.proxy_service import fetch_fresh_proxy, test_proxy_speed
    speed_test = cfg.get(CK_PROXY_SPEED_TEST).lower() == "true"

    new_proxy = None
    for attempt in range(1, 4):
        candidate = fetch_fresh_proxy()
        if not candidate:
            logger.warning(f"[publish] 获取代理 IP 失败（第 {attempt}/3 次）")
            continue
        if not speed_test:
            new_proxy = candidate
            break
        logger.info(f"[publish] 测速代理 IP（第 {attempt}/3 次）：{candidate}")
        if test_proxy_speed(candidate):
            new_proxy = candidate
            break
        logger.warning(f"[publish] 代理 IP 测速不达标，丢弃，尝试换一个")

    if not new_proxy:
        logger.warning(f"[publish] 未找到合格代理 IP，本次发布不使用代理")
        return

    logger.info(f"[publish] 发布代理：重启 account={account_id} 会话以应用新 IP")
    xhs.session.stop(account_id)
    time.sleep(1)

    headless = cfg.get(CK_BROWSER_VISIBLE).lower() != "true"
    try:
        xhs.session.start(account_id, headless=headless, proxy=new_proxy)
        logger.info(f"[publish] 代理轮换完成，新 IP 已应用")
    except Exception as e:
        logger.warning(f"[publish] 代理轮换：会话启动失败：{e}")


def _mark_failed(
    account_id: int,
    record_id: str,
    title: str,
    reason: str,
    feishu,
    user_id: str | None,
) -> None:
    now = datetime.now(timezone.utc).isoformat()

    try:
        feishu.update_record(record_id, {FIELD_STATUS: STATUS_FAILED})
    except Exception as e:
        logger.warning(f"[publish] 飞书失败状态回写失败：{e}")

    with database.cursor(commit=True) as c:
        c.execute(
            "UPDATE content_queue SET status='failed', error_msg=?, updated_at=? WHERE feishu_record_id=?",
            (reason, now, record_id),
        )
        local = c.execute("SELECT id FROM content_queue WHERE feishu_record_id=?", (record_id,)).fetchone()
        if local:
            c.execute(
                "INSERT INTO publish_log (content_id, account_id, status, error_msg, published_at)"
                " VALUES (?, ?, 'failed', ?, ?)",
                (local["id"], account_id, reason, now),
            )

    if user_id:
        try:
            feishu.send_text_message(
                user_id,
                f"《{title}》发布失败 ❌\n\n"
                f"想重试，把这条记录的「{FIELD_STATUS}」从「{STATUS_FAILED}」改回「{STATUS_APPROVED}」即可，下次发布会自动重发。\n\n"
                f"失败原因：{reason}",
            )
        except Exception:
            pass
