#!/usr/bin/env python3
"""RedBeacon CLI — skill 入口。

约定：
  - 成功：exit 0 + stdout JSON
  - 失败：exit ≠0 + stderr {"error": str}
  - 输出 shape 见 redbeacon.schemas
  - 子命令实现在 redbeacon.routers.<feature>

新增子命令：在 routers/ 下加文件 + 在 _build_parser/_DISPATCH 注册即可。
"""
from __future__ import annotations

import argparse
import os
import sys
from pathlib import Path

from redbeacon import __version__
from redbeacon.utils.paths import default_data_dir, default_log_dir

DATA_DIR = str(os.environ.get("REDBEACON_DATA_DIR", default_data_dir()))
LOG_DIR  = str(os.environ.get("REDBEACON_LOG_DIR",  default_log_dir()))

from redbeacon.utils.logger import init_logger
from redbeacon import database

init_logger(LOG_DIR)
database.init_db(DATA_DIR)

from redbeacon.routers import (
    accounts as r_accounts,
    login as r_login,
    strategy as r_strategy,
    topics as r_topics,
    content as r_content,
    generate as r_generate,
    publish as r_publish,
    feishu as r_feishu,
    config as r_config,
    status as r_status,
    logs as r_logs,
    readiness as r_readiness,
    license as r_license,
    ui as r_ui,
    update as r_update,
    setup as r_setup,
    backup as r_backup,
)


# ── CLI Parser ────────────────────────────────────────────────────────────────

def _build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="redbeacon", description="RedBeacon CLI — 小红书自动化")
    p.add_argument("--version", action="version", version=f"redbeacon {__version__}")
    sp = p.add_subparsers(dest="cmd", required=True)

    # accounts
    acc = sp.add_parser("accounts")
    acc_sp = acc.add_subparsers(dest="sub", required=True)
    acc_sp.add_parser("list")
    _add_account_arg(acc_sp.add_parser("get"))
    acc_sp.add_parser("create")
    _add_account_arg(acc_sp.add_parser("delete"))
    acc_pat = acc_sp.add_parser("patch")
    _add_account_arg(acc_pat)
    acc_pat.add_argument("--data", required=True, help='JSON: {"field": "value"}')

    # login
    login = sp.add_parser("login")
    login_sp = login.add_subparsers(dest="sub", required=True)
    for sub in ("start", "verify", "status", "delete"):
        _add_account_arg(login_sp.add_parser(sub))

    # strategy
    strat = sp.add_parser("strategy")
    strat_sp = strat.add_subparsers(dest="sub", required=True)
    _add_account_arg(strat_sp.add_parser("get"))
    sp2 = strat_sp.add_parser("patch")
    _add_account_arg(sp2)
    sp2.add_argument("--data", required=True, help='JSON: {"field": "value"}')
    # 文案预设（content_type.prompt_template）
    _add_account_arg(strat_sp.add_parser("prompt-list"))
    spg = strat_sp.add_parser("prompt-get"); _add_account_arg(spg)
    spg.add_argument("--type", required=True, help="内容类型名")
    sps = strat_sp.add_parser("prompt-set"); _add_account_arg(sps)
    sps.add_argument("--type", required=True, help="内容类型名")
    sps.add_argument("--text", default=None, help="提示词模板，不传则从 stdin 读取")
    spr = strat_sp.add_parser("prompt-reset"); _add_account_arg(spr)
    spr.add_argument("--type", required=True, help="内容类型名")
    # 图片预设（image_strategy）
    _add_account_arg(strat_sp.add_parser("image-get"))
    sis = strat_sp.add_parser("image-set"); _add_account_arg(sis)
    sis.add_argument("--data", required=True,
                     help='JSON: {"mode":"cards|ai|both","card_theme":"...","prompt_template":"...","ai_model":"..."}')

    # topics
    top = sp.add_parser("topics")
    top_sp = top.add_subparsers(dest="sub", required=True)
    tl = top_sp.add_parser("list")
    _add_account_arg(tl)
    tl.add_argument("--type", default=None)
    tl.add_argument("--used", type=int, default=None)
    tl.add_argument("--domain", default=None, help="按应用域过滤")
    tl.add_argument("--limit", type=int, default=100)
    tl.add_argument("--offset", type=int, default=0)
    ta = top_sp.add_parser("add"); _add_account_arg(ta)
    ta.add_argument("--content", required=True)
    ta.add_argument("--type", required=True)
    ta.add_argument("--domain", default=None, help="应用域（选题规划元数据，可选）")
    ta.add_argument("--problem-type", default=None, dest="problem_type", help="问题类型（识别/盲区/决策/替代/反例/后果，可选）")
    tb = top_sp.add_parser("batch"); _add_account_arg(tb)
    tb.add_argument("--type", default=None, help="纯文本模式的内容类型；--json 模式可省（每项自带 content_type）")
    tb.add_argument("--json", action="store_true", help="从 stdin 读 JSON 数组，每项含 content/content_type/application_domain/problem_type")
    tb.add_argument("--text", default=None, help="选题内容，不传则从 stdin 读取")
    ti = top_sp.add_parser("inspire"); _add_account_arg(ti)
    ti.add_argument("--text", required=True)
    _add_account_arg(top_sp.add_parser("stats"))
    te = top_sp.add_parser("edit"); _add_account_arg(te)
    te.add_argument("--id", type=int, required=True, help="要修改的选题 id")
    te.add_argument("--content", default=None, help="新的选题文本")
    te.add_argument("--type", default=None, help="改归到的内容类型")
    te.add_argument("--used", type=int, default=None, help="改状态：0 未用 / 1 已用")
    te.add_argument("--domain", default=None, help="改应用域")
    te.add_argument("--problem-type", default=None, dest="problem_type", help="改问题类型")
    tr = top_sp.add_parser("reset"); _add_account_arg(tr)
    tr.add_argument("--type", default=None)
    tdel = top_sp.add_parser("delete"); _add_account_arg(tdel)
    tdel.add_argument("--ids", default=None, help="逗号分隔的选题 id，如 3,4,5")
    tdel.add_argument("--type", default=None, help="按内容类型删除")
    tdel.add_argument("--used", type=int, default=None, help="按状态删除：0 未用 / 1 已用")
    tdel.add_argument("--all", action="store_true", help="删除该账号全部选题（防误删，需显式指定）")
    _add_account_arg(top_sp.add_parser("types"))
    _add_account_arg(top_sp.add_parser("types-init"))
    tta = top_sp.add_parser("types-add"); _add_account_arg(tta)
    tta.add_argument("--name", required=True, help="新内容类型名")
    tta.add_argument("--prompt", default=None, help="该类型的文案风格指引（一句人话，可选）")
    ttr = top_sp.add_parser("types-rename"); _add_account_arg(ttr)
    ttr.add_argument("--name", required=True, help="原类型名")
    ttr.add_argument("--to", required=True, help="新类型名")
    ttd = top_sp.add_parser("types-delete"); _add_account_arg(ttd)
    ttd.add_argument("--name", required=True, help="要删除的内容类型名")
    ttd.add_argument("--force", action="store_true", help="该类型下还有未用选题时强制删除")

    # content
    cont = sp.add_parser("content")
    cont_sp = cont.add_subparsers(dest="sub", required=True)
    cl = cont_sp.add_parser("list"); _add_account_arg(cl)
    cl.add_argument("--status", default=None)
    cl.add_argument("--limit", type=int, default=20)
    cl.add_argument("--offset", type=int, default=0)
    cg = cont_sp.add_parser("get"); _add_account_arg(cg)
    cg.add_argument("--id", type=int, required=True)
    cont_sp.add_parser("feishu-push")

    # generate
    gen = sp.add_parser("generate")
    gen.add_argument("--account-id", type=int, default=None, dest="account_id")
    gen.add_argument("--all-accounts", action="store_true", dest="all_accounts",
                     help="对所有账号各生成（可叠加 --count）")
    gen.add_argument("--count", type=int, default=1, help="连续生成多少篇（每篇取下一个未用选题）")
    gen.add_argument("--topic", default=None)
    gen.add_argument("--image-mode", default=None, dest="image_mode",
                     choices=["cards", "ai", "both"])
    gen.add_argument("--content-type", default=None, dest="content_type")
    gen.add_argument("--pillar", default=None)

    # publish
    pub = sp.add_parser("publish")
    pub.add_argument("--account-id", type=int, default=None, dest="account_id")
    pub.add_argument("--all-accounts", action="store_true", dest="all_accounts",
                     help="依次发布所有账号（账号之间自动错峰）")
    pub.add_argument("--dry-run", action="store_true",
                     help="只预览即将发布的内容与发布配置，不实际发布")

    # feishu
    fei = sp.add_parser("feishu")
    fei_sp = fei.add_subparsers(dest="sub", required=True)
    fsu = fei_sp.add_parser("setup"); _add_account_arg(fsu)
    fsu.add_argument("--app-token", default=None, dest="app_token")
    fsu.add_argument("--table-id", default=None, dest="table_id")
    _add_account_arg(fei_sp.add_parser("test"))

    # config
    conf = sp.add_parser("config")
    conf_sp = conf.add_subparsers(dest="sub", required=True)
    cg = conf_sp.add_parser("get"); cg.add_argument("key")
    cs = conf_sp.add_parser("set"); cs.add_argument("key"); cs.add_argument("value")
    for sub in ("list", "models", "test-ai", "test-image", "test-feishu", "test-proxy", "feishu-users"):
        conf_sp.add_parser(sub)

    # ui（按需可编辑网页）
    ui = sp.add_parser("ui")
    ui_sp = ui.add_subparsers(dest="sub", required=True)
    _add_account_arg(ui_sp.add_parser("account"))
    ui_sp.add_parser("dashboard")  # 运营看板：一眼看全部账号（只读）

    # update（升级 CLI + skill）
    upd = sp.add_parser("update")
    upd.add_argument("--check", action="store_true", help="只检查有无新版，不执行升级")

    # setup（下载浏览器内核，首装用）
    sp.add_parser("setup")

    # backup（导出 / 导入工作数据，换机迁移用）
    bak = sp.add_parser("backup")
    bak_sp = bak.add_subparsers(dest="sub", required=True)
    bex = bak_sp.add_parser("export")
    bex.add_argument("--out", default=None, help="导出文件路径（默认当前目录带时间戳）")
    bim = bak_sp.add_parser("import")
    bim.add_argument("--file", required=True, help="要导入的备份 JSON 路径")
    bim.add_argument("--force", action="store_true", help="当前库已有数据时强制覆盖")

    # license（多账号解锁）
    lic = sp.add_parser("license")
    lic_sp = lic.add_subparsers(dest="sub", required=True)
    lic_sp.add_parser("info")
    la = lic_sp.add_parser("activate"); la.add_argument("code")

    # readiness / status / logs
    sp.add_parser("readiness")
    sp.add_parser("status")
    log_p = sp.add_parser("logs")
    log_p.add_argument("--tail", type=int, default=150)

    return p


def _add_account_arg(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--account-id", type=int, required=True, dest="account_id")


# ── Dispatch ──────────────────────────────────────────────────────────────────

_DISPATCH = {
    "accounts": r_accounts.dispatch,
    "login":    r_login.dispatch,
    "strategy": r_strategy.dispatch,
    "topics":   r_topics.dispatch,
    "content":  r_content.dispatch,
    "generate": r_generate.dispatch,
    "publish":  r_publish.dispatch,
    "feishu":   r_feishu.dispatch,
    "config":   r_config.dispatch,
    "status":   r_status.dispatch,
    "logs":     r_logs.dispatch,
    "readiness": r_readiness.dispatch,
    "license":  r_license.dispatch,
    "ui":       r_ui.dispatch,
    "update":   r_update.dispatch,
    "setup":    r_setup.dispatch,
    "backup":   r_backup.dispatch,
}


def main():
    args = _build_parser().parse_args()
    fn = _DISPATCH.get(args.cmd)
    if fn is None:
        import json
        print(json.dumps({"error": f"未知命令：{args.cmd}"}, ensure_ascii=False), file=sys.stderr)
        sys.exit(1)
    fn(args)


if __name__ == "__main__":
    main()
