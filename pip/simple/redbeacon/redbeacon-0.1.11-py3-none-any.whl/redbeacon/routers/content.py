"""content list / get / feishu-push（审核与改稿全部在飞书，CLI 无本地审核）"""
from __future__ import annotations

import json

from redbeacon import database
from redbeacon.utils.logger import get_logger
from ._runtime import out, err

log = get_logger("router.content")


def _content_row(row) -> dict:
    d = dict(row)
    for f in ("tags", "images"):
        try:
            d[f] = json.loads(d[f]) if d.get(f) else []
        except Exception:
            d[f] = []
    return d


def dispatch(args) -> None:
    if args.sub == "list":     _list(args)
    elif args.sub == "get":    _get(args)
    elif args.sub == "feishu-push": _feishu_push()
    else:                      err(f"未知 content 子命令：{args.sub}")


def _list(args) -> None:
    with database.cursor() as c:
        if args.status:
            rows = c.execute(
                "SELECT * FROM content_queue WHERE account_id=? AND status=? "
                "ORDER BY created_at DESC LIMIT ? OFFSET ?",
                (args.account_id, args.status, args.limit, args.offset),
            ).fetchall()
        else:
            rows = c.execute(
                "SELECT * FROM content_queue WHERE account_id=? "
                "ORDER BY created_at DESC LIMIT ? OFFSET ?",
                (args.account_id, args.limit, args.offset),
            ).fetchall()
    out([_content_row(r) for r in rows])


def _get(args) -> None:
    with database.cursor() as c:
        row = c.execute(
            "SELECT * FROM content_queue WHERE id=? AND account_id=?",
            (args.id, args.account_id),
        ).fetchone()
    if not row:
        err(f"内容 {args.id} 不存在")
    out(_content_row(row))


def _feishu_push() -> None:
    from redbeacon.tasks.generate import _push_to_feishu
    with database.cursor() as c:
        rows = c.execute(
            "SELECT id FROM content_queue WHERE status='pending_review' "
            "AND (feishu_record_id IS NULL OR feishu_record_id='')"
        ).fetchall()
    pushed = 0
    for row in rows:
        try:
            _push_to_feishu(row["id"])
            pushed += 1
        except Exception as e:
            log.warning(f"content_id={row['id']} 推送失败: {e}")
    out({"ok": True, "pushed": pushed})
