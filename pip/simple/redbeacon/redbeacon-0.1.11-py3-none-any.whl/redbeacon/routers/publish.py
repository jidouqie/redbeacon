"""publish: 从飞书读「通过」记录 → 浏览器自动化发布。

唯一发布数据源是飞书多维表格（审核全部在飞书完成），无本地审核路径。

支持：
  - 单账号（默认，兼容旧 shape {"ok":true,"published":N}）
  - --all-accounts  依次发布所有已配齐飞书的账号，账号之间自动错峰（防关联）
  - --dry-run       只预览不发布
"""
from __future__ import annotations

import random
import time

from redbeacon import config as cfg
from redbeacon.config_keys import (
    CK_FEISHU_APP_ID, CK_FEISHU_APP_SECRET, CK_PUBLISH_ACCOUNT_STAGGER,
)
from redbeacon import database
from redbeacon.utils.logger import get_logger
from ._runtime import out, err

log = get_logger("router.publish")


def _feishu_ready(account_id: int) -> bool:
    app_id     = cfg.get(CK_FEISHU_APP_ID)
    app_secret = cfg.get(CK_FEISHU_APP_SECRET)
    with database.cursor() as c:
        acc = c.execute(
            "SELECT feishu_app_token, feishu_table_id FROM account WHERE id=?",
            (account_id,),
        ).fetchone()
    return bool(app_id and app_secret and acc and acc["feishu_app_token"] and acc["feishu_table_id"])


def dispatch(args) -> None:
    from redbeacon.tasks.publish import run_publish, preview_publish

    all_accounts = getattr(args, "all_accounts", False)
    dry_run      = getattr(args, "dry_run", False)

    # ── 解析目标账号
    if all_accounts:
        with database.cursor() as c:
            ids = [r["id"] for r in c.execute("SELECT id FROM account ORDER BY id").fetchall()]
        account_ids = [i for i in ids if _feishu_ready(i)]
        if not account_ids:
            err("没有任何账号配齐飞书审核表，无法发布",
                next="redbeacon feishu setup --account-id <ID>")
    else:
        if not getattr(args, "account_id", None):
            err("请用 --account-id 指定账号，或加 --all-accounts 发布全部")
        if not _feishu_ready(args.account_id):
            err("发布需要先配置飞书审核表格（审核与发布数据源均在飞书）",
                next=f"redbeacon feishu setup --account-id {args.account_id}")
        account_ids = [args.account_id]

    # ── dry-run：逐账号预览
    if dry_run:
        try:
            if len(account_ids) == 1:
                out(preview_publish(account_id=account_ids[0]))
            else:
                out({"ok": True, "previews": [
                    {"account_id": aid, **preview_publish(account_id=aid)} for aid in account_ids
                ]})
        except Exception as e:
            log.error(f"publish 预览失败：{e}", exc_info=True)
            err(f"发布预览失败：{e}")
        return

    # ── 单账号：保留旧返回 shape
    if len(account_ids) == 1:
        try:
            published = run_publish(account_id=account_ids[0])
            out({"ok": True, "published": published})
        except Exception as e:
            log.error(f"publish 失败：{e}", exc_info=True)
            err(f"发布失败：{e}")
        return

    # ── 多账号：逐个发布，账号之间错峰（防关联）
    stagger_base = _int_cfg(CK_PUBLISH_ACCOUNT_STAGGER, 120)
    results: list[dict] = []
    for idx, aid in enumerate(account_ids):
        try:
            n = run_publish(account_id=aid)
            results.append({"account_id": aid, "published": n})
        except Exception as e:
            log.error(f"publish 账号 {aid} 失败：{e}", exc_info=True)
            results.append({"account_id": aid, "error": str(e)})
        # 不是最后一个账号就错峰等待（0.5x~1.5x 基准秒），避免多号同一时刻批量动作
        if idx < len(account_ids) - 1 and stagger_base > 0:
            wait = int(stagger_base * random.uniform(0.5, 1.5))
            log.info(f"[publish] 账号间错峰等待 {wait}s")
            time.sleep(wait)
    total = sum(r.get("published", 0) for r in results)
    out({"ok": True, "published": total, "results": results})


def _int_cfg(key, default: int) -> int:
    try:
        return int(float(cfg.get(key)))
    except Exception:
        return default
