"""update: 升级 CLI（闭源包，走 uv）+ skill（开源 markdown，走 GitHub）。

  redbeacon update --check   只检查有无新版，不动任何文件
  redbeacon update           执行升级：uv 升 CLI + 从 GitHub 刷新 skill

联网失败一律静默降级（见 services/updater），不影响正常使用。
"""
from __future__ import annotations

from redbeacon.utils.logger import get_logger
from ._runtime import out, err

log = get_logger("router.update")


def dispatch(args) -> None:
    from redbeacon.services import updater

    try:
        if getattr(args, "check", False):
            out(updater.check())
            return
        out(updater.run_update())
    except Exception as e:
        log.error(f"update 失败：{e}", exc_info=True)
        err(f"升级失败：{e}")
