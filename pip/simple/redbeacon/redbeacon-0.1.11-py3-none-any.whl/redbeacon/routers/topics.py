"""topics list / add / batch / inspire / stats / reset / delete / types / types-init"""
from __future__ import annotations

import json
import sys

from redbeacon import config as cfg
from redbeacon.config_keys import CK_AI_API_KEY, CK_AI_BASE_URL, CK_AI_MODEL
from redbeacon import database
from ._runtime import out, err, now_iso, require_account


def dispatch(args) -> None:
    if args.sub == "list":     _list(args)
    elif args.sub == "add":    _add(args)
    elif args.sub == "batch":  _batch(args)
    elif args.sub == "inspire": _inspire(args)
    elif args.sub == "stats":  _stats(args)
    elif args.sub == "edit":   _edit(args)
    elif args.sub == "reset":  _reset(args)
    elif args.sub == "delete": _delete(args)
    elif args.sub == "types":  _types(args)
    elif args.sub == "types-init":   _types_init(args)
    elif args.sub == "types-add":    _types_add(args)
    elif args.sub == "types-rename": _types_rename(args)
    elif args.sub == "types-delete": _types_delete(args)
    else:                      err(f"未知 topics 子命令：{args.sub}")


def _list(args) -> None:
    wheres = ["account_id=?"]
    params: list = [args.account_id]
    if args.type:
        wheres.append("content_type=?")
        params.append(args.type)
    if args.used is not None:
        wheres.append("is_used=?")
        params.append(args.used)
    if getattr(args, "domain", None):
        wheres.append("application_domain=?")
        params.append(args.domain)
    where_sql = " AND ".join(wheres)
    with database.cursor() as c:
        rows = c.execute(
            f"SELECT * FROM topic WHERE {where_sql} ORDER BY is_used, id DESC LIMIT ? OFFSET ?",
            params + [args.limit, args.offset],
        ).fetchall()
    out([dict(r) for r in rows])


def _add(args) -> None:
    require_account(args.account_id)
    with database.cursor(commit=True) as c:
        c.execute(
            "INSERT INTO topic (account_id, content_type, content, application_domain, problem_type, created_at) "
            "VALUES (?, ?, ?, ?, ?, ?)",
            (args.account_id, args.type, args.content.strip(),
             getattr(args, "domain", None) or None,
             getattr(args, "problem_type", None) or None, now_iso()),
        )
        row = c.execute("SELECT * FROM topic WHERE rowid=last_insert_rowid()").fetchone()
    out(dict(row))


def _batch(args) -> None:
    """批量入库。两种输入：
      - 纯文本（默认）：每行一个选题，全部归到 --type；不带规划元数据。
      - --json：stdin 读 JSON 数组，每项 {content, content_type?, application_domain?, problem_type?}，
        一次性把整张选题规划网格连同应用域/问题类型落库（content_type 缺省回退 --type）。
    """
    require_account(args.account_id)
    if getattr(args, "json", False):
        _batch_json(args)
        return
    if not args.type:
        err("纯文本批量需要 --type 指定内容类型；或用 --json 让每项自带 content_type")
    text = args.text or sys.stdin.read()
    lines = [l.strip() for l in text.splitlines() if l.strip()]
    if not lines:
        out({"inserted": 0, "total": 0})
    now = now_iso()
    inserted = 0
    with database.cursor(commit=True) as c:
        for line in lines:
            exists = c.execute(
                "SELECT id FROM topic WHERE account_id=? AND content_type=? AND content=?",
                (args.account_id, args.type, line),
            ).fetchone()
            if not exists:
                c.execute(
                    "INSERT INTO topic (account_id, content_type, content, created_at) VALUES (?, ?, ?, ?)",
                    (args.account_id, args.type, line, now),
                )
                inserted += 1
    out({"inserted": inserted, "total": len(lines)})


def _batch_json(args) -> None:
    raw = args.text or sys.stdin.read()
    try:
        items = json.loads(raw)
    except Exception as e:
        err(f"--json 解析失败：{e}")
    if not isinstance(items, list):
        err("--json 期望一个 JSON 数组")
    now = now_iso()
    inserted = 0
    with database.cursor(commit=True) as c:
        for it in items:
            if not isinstance(it, dict):
                continue
            content = (it.get("content") or "").strip()
            if not content:
                continue
            ctype = (it.get("content_type") or args.type or "").strip()
            if not ctype:
                err("某条选题缺 content_type，且未提供 --type 作为回退")
            domain = (it.get("application_domain") or "").strip() or None
            ptype  = (it.get("problem_type") or "").strip() or None
            exists = c.execute(
                "SELECT id FROM topic WHERE account_id=? AND content_type=? AND content=?",
                (args.account_id, ctype, content),
            ).fetchone()
            if exists:
                continue
            c.execute(
                "INSERT INTO topic (account_id, content_type, content, application_domain, problem_type, created_at) "
                "VALUES (?, ?, ?, ?, ?, ?)",
                (args.account_id, ctype, content, domain, ptype, now),
            )
            inserted += 1
    out({"inserted": inserted, "total": len(items)})


def _inspire(args) -> None:
    require_account(args.account_id)
    import httpx
    from openai import OpenAI
    api_key  = cfg.get(CK_AI_API_KEY)
    base_url = cfg.get(CK_AI_BASE_URL)
    model    = cfg.get(CK_AI_MODEL)
    if not api_key:
        err("AI API Key 未配置", next="redbeacon config set ai_api_key <KEY>")
    with database.cursor() as c:
        row = c.execute(
            "SELECT data FROM strategy WHERE account_id=? ORDER BY version DESC LIMIT 1",
            (args.account_id,),
        ).fetchone()
    niche = "通用"
    if row:
        try:
            niche = json.loads(row["data"]).get("niche", "通用")
        except Exception:
            pass
    prompt = (
        f"你是一个{niche}领域的小红书内容策划专家。\n\n"
        f"用户有以下灵感：\n\"{args.text}\"\n\n"
        "请基于这个灵感，生成5个具体的小红书笔记选题标题。\n\n"
        "要求：\n"
        "- 每条选题都是完整的笔记标题，不超过25字\n"
        "- 有吸引力，适合小红书风格（口语化、有共鸣、可加数字）\n"
        f'- 与"{niche}"领域相关\n'
        "- 5条选题要有差异性，覆盖不同角度\n\n"
        "只输出5条标题，每行一条，不要编号，不要任何额外说明。"
    )
    try:
        client = OpenAI(
            api_key=api_key, base_url=base_url,
            http_client=httpx.Client(trust_env=False, timeout=30),
        )
        resp = client.chat.completions.create(
            model=model,
            messages=[{"role": "user", "content": prompt}],
            temperature=0.9,
            max_tokens=500,
        )
        raw = resp.choices[0].message.content.strip()
        options = [l.strip() for l in raw.splitlines() if l.strip()][:6]
        out({"options": options})
    except Exception as e:
        err(f"AI 生成失败：{e}")


def _stats(args) -> None:
    with database.cursor() as c:
        total  = c.execute("SELECT COUNT(*) FROM topic WHERE account_id=?", (args.account_id,)).fetchone()[0]
        unused = c.execute("SELECT COUNT(*) FROM topic WHERE account_id=? AND is_used=0",
                           (args.account_id,)).fetchone()[0]
        by_type = c.execute(
            "SELECT content_type, COUNT(*) as total, SUM(CASE WHEN is_used=0 THEN 1 ELSE 0 END) as unused "
            "FROM topic WHERE account_id=? GROUP BY content_type",
            (args.account_id,),
        ).fetchall()
        # 应用域覆盖盘面（选题规划会用：哪些应用域已铺、哪些空/挤）
        by_domain = c.execute(
            "SELECT COALESCE(NULLIF(application_domain,''),'(未标应用域)') AS application_domain, "
            "COUNT(*) as total, SUM(CASE WHEN is_used=0 THEN 1 ELSE 0 END) as unused "
            "FROM topic WHERE account_id=? GROUP BY 1 ORDER BY total DESC",
            (args.account_id,),
        ).fetchall()
    out({"total": total, "unused": unused, "used": total - unused,
         "by_type": [dict(r) for r in by_type],
         "by_domain": [dict(r) for r in by_domain]})


def _edit(args) -> None:
    """改某条选题的文本 / 类型 / 使用状态（按 id 定位，免去删了重加）。"""
    require_account(args.account_id)
    sets: list[str] = []
    params: list = []
    if getattr(args, "content", None) is not None:
        sets.append("content=?"); params.append(args.content.strip())
    if getattr(args, "type", None) is not None:
        sets.append("content_type=?"); params.append(args.type)
    if getattr(args, "used", None) is not None:
        sets.append("is_used=?"); params.append(args.used)
        if args.used:
            sets.append("used_at=?"); params.append(now_iso())
        else:
            sets.append("used_at=NULL")
    if getattr(args, "domain", None) is not None:
        sets.append("application_domain=?"); params.append(args.domain or None)
    if getattr(args, "problem_type", None) is not None:
        sets.append("problem_type=?"); params.append(args.problem_type or None)
    if not sets:
        err("没有要修改的字段，至少传 --content / --type / --used / --domain / --problem-type 其一")
    with database.cursor(commit=True) as c:
        row = c.execute("SELECT id FROM topic WHERE account_id=? AND id=?",
                        (args.account_id, args.id)).fetchone()
        if not row:
            err(f"选题 id={args.id} 不存在（账号 {args.account_id}）")
        c.execute(f"UPDATE topic SET {', '.join(sets)} WHERE account_id=? AND id=?",
                  params + [args.account_id, args.id])
        updated = c.execute("SELECT * FROM topic WHERE id=?", (args.id,)).fetchone()
    out(dict(updated))


def _reset(args) -> None:
    with database.cursor(commit=True) as c:
        if args.type:
            c.execute(
                "UPDATE topic SET is_used=0, used_at=NULL WHERE account_id=? AND content_type=?",
                (args.account_id, args.type),
            )
        else:
            c.execute("UPDATE topic SET is_used=0, used_at=NULL WHERE account_id=?", (args.account_id,))
    out({"ok": True})


def _delete(args) -> None:
    """物理删除选题（与 reset 不同，reset 只重置 is_used）。
    支持 --ids / --type / --used 过滤；都不传需显式 --all 才清空该账号全部。"""
    require_account(args.account_id)
    wheres = ["account_id=?"]
    params: list = [args.account_id]
    has_filter = False
    if getattr(args, "ids", None):
        try:
            ids = [int(x) for x in str(args.ids).split(",") if x.strip()]
        except ValueError:
            err("--ids 必须是逗号分隔的整数，如 3,4,5")
        if not ids:
            err("--ids 为空")
        wheres.append(f"id IN ({','.join('?' for _ in ids)})")
        params.extend(ids)
        has_filter = True
    if args.type:
        wheres.append("content_type=?")
        params.append(args.type)
        has_filter = True
    if args.used is not None:
        wheres.append("is_used=?")
        params.append(args.used)
        has_filter = True
    if not has_filter and not args.all:
        err("拒绝删除：未指定 --ids/--type/--used 任一条件。要清空该账号全部选题请显式加 --all",
            next=f"redbeacon topics delete --account-id {args.account_id} --all")
    where_sql = " AND ".join(wheres)
    with database.cursor(commit=True) as c:
        deleted = c.execute(f"DELETE FROM topic WHERE {where_sql}", params).rowcount
    out({"ok": True, "deleted": deleted})


def _types(args) -> None:
    with database.cursor() as c:
        rows = c.execute(
            "SELECT * FROM content_type WHERE account_id=? ORDER BY sort_order, id",
            (args.account_id,),
        ).fetchall()
    out([dict(r) for r in rows])


_DEFAULT_TYPES = ["干货科普", "痛点解析", "经验分享"]


def _types_init(args) -> None:
    require_account(args.account_id)
    with database.cursor(commit=True) as c:
        count = c.execute("SELECT COUNT(*) FROM content_type WHERE account_id=?",
                          (args.account_id,)).fetchone()[0]
        if count > 0:
            rows = c.execute("SELECT * FROM content_type WHERE account_id=? ORDER BY sort_order",
                             (args.account_id,)).fetchall()
            out([dict(r) for r in rows])
        now = now_iso()
        for i, name in enumerate(_DEFAULT_TYPES):
            c.execute(
                "INSERT INTO content_type (account_id, name, prompt_template, sort_order, created_at, updated_at) "
                "VALUES (?, ?, '', ?, ?, ?)",
                (args.account_id, name, i, now, now),
            )
        rows = c.execute("SELECT * FROM content_type WHERE account_id=? ORDER BY sort_order",
                         (args.account_id,)).fetchall()
    out([dict(r) for r in rows])


def _types_add(args) -> None:
    """新增一个内容类型（默认三类之外想加自定义类型时用）。"""
    require_account(args.account_id)
    name = (args.name or "").strip()
    if not name:
        err("内容类型名不能为空")
    with database.cursor(commit=True) as c:
        if c.execute("SELECT id FROM content_type WHERE account_id=? AND name=?",
                     (args.account_id, name)).fetchone():
            err(f"内容类型「{name}」已存在")
        maxsort = c.execute("SELECT COALESCE(MAX(sort_order), -1) FROM content_type WHERE account_id=?",
                            (args.account_id,)).fetchone()[0]
        now = now_iso()
        c.execute(
            "INSERT INTO content_type (account_id, name, prompt_template, sort_order, created_at, updated_at) "
            "VALUES (?, ?, ?, ?, ?, ?)",
            (args.account_id, name, (getattr(args, "prompt", None) or "").strip(), maxsort + 1, now, now),
        )
        row = c.execute("SELECT * FROM content_type WHERE account_id=? AND name=?",
                        (args.account_id, name)).fetchone()
    out(dict(row))


def _types_rename(args) -> None:
    """给内容类型改名，并级联更新选题 / 已生成内容的类型归属（不丢关联）。"""
    require_account(args.account_id)
    old = (args.name or "").strip()
    new = (args.to or "").strip()
    if not new:
        err("新名称不能为空")
    with database.cursor(commit=True) as c:
        if not c.execute("SELECT id FROM content_type WHERE account_id=? AND name=?",
                         (args.account_id, old)).fetchone():
            err(f"内容类型「{old}」不存在")
        if old != new and c.execute("SELECT id FROM content_type WHERE account_id=? AND name=?",
                                    (args.account_id, new)).fetchone():
            err(f"目标名称「{new}」已存在，不能重名")
        now = now_iso()
        c.execute("UPDATE content_type SET name=?, updated_at=? WHERE account_id=? AND name=?",
                  (new, now, args.account_id, old))
        t = c.execute("UPDATE topic SET content_type=? WHERE account_id=? AND content_type=?",
                      (new, args.account_id, old)).rowcount
        q = c.execute("UPDATE content_queue SET content_type=? WHERE account_id=? AND content_type=?",
                      (new, args.account_id, old)).rowcount
    out({"ok": True, "renamed": f"{old} → {new}", "topics_updated": t, "content_updated": q})


def _types_delete(args) -> None:
    """删除内容类型。该类型下还有未用选题时需 --force（选题本身不删，仍可被跨类型取用）。"""
    require_account(args.account_id)
    name = (args.name or "").strip()
    with database.cursor(commit=True) as c:
        if not c.execute("SELECT id FROM content_type WHERE account_id=? AND name=?",
                         (args.account_id, name)).fetchone():
            err(f"内容类型「{name}」不存在")
        unused = c.execute("SELECT COUNT(*) FROM topic WHERE account_id=? AND content_type=? AND is_used=0",
                           (args.account_id, name)).fetchone()[0]
        if unused > 0 and not getattr(args, "force", False):
            err(f"该类型下还有 {unused} 条未用选题；删类型会让它们失去归属（选题不删，仍可被跨类型生成取用）。确认请加 --force",
                next=f"redbeacon topics types-delete --account-id {args.account_id} --name \"{name}\" --force")
        c.execute("DELETE FROM content_type WHERE account_id=? AND name=?", (args.account_id, name))
    out({"ok": True, "deleted_type": name})
