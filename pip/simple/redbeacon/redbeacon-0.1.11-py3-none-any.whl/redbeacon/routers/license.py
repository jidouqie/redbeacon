"""license info / activate — 多账号解锁。

info：展示本机机器码 + 当前授权档位（free/pro）。机器码提交到购买页用。
activate：输入解锁码，绑定本机后解锁多账号。
"""
from __future__ import annotations

from redbeacon.services import license
from ._runtime import out, err


def dispatch(args) -> None:
    if args.sub == "info":
        out({
            "machine_code": license.machine_code(),
            "tier": license.tier(),
            "unlocked": license.is_unlocked(),
            "max_accounts": license.max_accounts(),
        })

    elif args.sub == "activate":
        if not license.activate(args.code):
            err("解锁码无效或与本机不匹配", next="redbeacon license info",
                kind="LICENSE_INVALID")
        out({
            "ok": True,
            "tier": license.tier(),
            "max_accounts": license.max_accounts(),
            "machine_code": license.machine_code(),
        })

    else:
        err(f"未知 license 子命令：{args.sub}")
