"""login start / verify / status / delete"""
from __future__ import annotations

import base64
import json
import subprocess
import sys
import tempfile
from pathlib import Path

from redbeacon import database
from redbeacon.services import xhs
from redbeacon.utils.logger import get_logger
from ._runtime import out, err, now_iso, require_account, update_account, DATA_DIR

log = get_logger("router.login")


def dispatch(args) -> None:
    if args.sub == "start":
        _start(args)
    elif args.sub == "verify":
        _verify(args)
    elif args.sub == "status":
        _status(args)
    elif args.sub == "delete":
        _delete(args)
    else:
        err(f"未知 login 子命令：{args.sub}")


def _start(args) -> None:
    require_account(args.account_id)
    cookie_path = str(Path(DATA_DIR) / f"cookies_{args.account_id}.json")
    Path(cookie_path).parent.mkdir(parents=True, exist_ok=True)
    update_account(args.account_id, cookie_file=cookie_path)

    xhs.session.stop(args.account_id)
    Path(cookie_path).unlink(missing_ok=True)

    try:
        xhs.session.start(args.account_id, headless=False, proxy=None)
    except Exception as e:
        err(f"启动浏览器失败：{e}")

    print(json.dumps({"status": "browser_started", "msg": "正在加载二维码…"}, ensure_ascii=False))
    sys.stdout.flush()

    try:
        data = xhs.login.fetch_qrcode(args.account_id)
    except Exception as e:
        xhs.session.stop(args.account_id)
        err(f"获取二维码失败：{e}")

    if data.get("already_logged_in"):
        xhs.login._save_cookies(args.account_id)
        update_account(args.account_id, login_status="logged_in", last_login_check=now_iso())
        xhs.session.stop(args.account_id)
        out({"logged_in": True, "msg": "账号已登录"})

    img_src = data.get("img", "")
    if img_src and img_src.startswith("data:image/"):
        header, b64 = img_src.split(",", 1)
        suffix = ".jpg" if ("jpeg" in header or "jpg" in header) else ".png"
        tmp = tempfile.NamedTemporaryFile(delete=False, suffix=suffix)
        tmp.write(base64.b64decode(b64))
        tmp.flush()
        tmp.close()
        if sys.platform == "darwin":
            subprocess.Popen(["open", tmp.name])
        elif sys.platform.startswith("linux"):
            subprocess.Popen(["xdg-open", tmp.name])
        print(json.dumps({"status": "qr_shown", "qr_file": tmp.name,
                           "msg": "请用小红书 App 扫描弹出的二维码（180s 内）"}, ensure_ascii=False))
        sys.stdout.flush()
    else:
        print(json.dumps({"status": "qr_no_image",
                           "msg": "无法获取二维码图片，请检查浏览器窗口"}, ensure_ascii=False))
        sys.stdout.flush()

    ok = xhs.login.wait_for_login(args.account_id, max_wait_sec=180)
    if not ok:
        xhs.session.stop(args.account_id)
        err("扫码超时或登录失败")

    nickname = ""
    try:
        status_data = xhs.login.check_login_status(args.account_id)
        nickname = status_data.get("username", "") or ""
    except Exception:
        pass
    update_account(args.account_id, login_status="logged_in",
                   nickname=nickname or None, last_login_check=now_iso())
    xhs.session.stop(args.account_id)
    out({"logged_in": True, "nickname": nickname})


def _verify(args) -> None:
    with database.cursor() as c:
        acc = c.execute(
            "SELECT cookie_file FROM account WHERE id=?", (args.account_id,)
        ).fetchone()
    if not acc or not acc["cookie_file"] or not Path(acc["cookie_file"]).exists():
        out({"logged_in": False})

    try:
        xhs.session.start(args.account_id, headless=True)
    except Exception as e:
        err(f"浏览器启动失败：{e}")

    try:
        data = xhs.login.check_login_status(args.account_id)
    except Exception as e:
        xhs.session.stop(args.account_id)
        err(f"登录态查询失败：{e}")

    is_in = bool(data.get("is_logged_in"))
    nickname = data.get("username", "") or ""
    xhs.session.stop(args.account_id)

    if is_in:
        update_account(args.account_id, login_status="logged_in",
                       nickname=nickname or None, last_login_check=now_iso())
        out({"logged_in": True, "nickname": nickname})
    else:
        update_account(args.account_id, login_status="logged_out")
        out({"logged_in": False})


def _status(args) -> None:
    with database.cursor() as c:
        row = c.execute("SELECT login_status, nickname FROM account WHERE id=?",
                        (args.account_id,)).fetchone()
    if not row:
        err(f"账号 {args.account_id} 不存在")
    out({"login_status": row["login_status"], "nickname": row["nickname"]})


def _delete(args) -> None:
    try:
        xhs.login.delete_cookies(args.account_id)
    except Exception as e:
        log.warning(f"清除 cookies 异常：{e}")
    xhs.session.stop(args.account_id)
    update_account(args.account_id, login_status="logged_out")
    out({"ok": True})
