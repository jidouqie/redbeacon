"""status: 系统总览"""
from __future__ import annotations

from pathlib import Path

from redbeacon import config as cfg
from redbeacon.config_keys import (
    CK_AI_API_KEY, CK_AI_BASE_URL, CK_AI_MODEL, CK_IMAGE_MODEL,
    CK_FEISHU_APP_ID, CK_FEISHU_APP_SECRET,
)
from redbeacon import database
from ._runtime import out, DATA_DIR, LOG_DIR


def dispatch(_args) -> None:
    with database.cursor() as c:
        accounts = c.execute(
            "SELECT id, display_name, login_status, nickname FROM account ORDER BY id"
        ).fetchall()
        contents = c.execute(
            "SELECT status, COUNT(*) as cnt FROM content_queue GROUP BY status"
        ).fetchall()
    out({
        "accounts": [dict(a) for a in accounts],
        "content_counts": {r["status"]: r["cnt"] for r in contents},
        "paths": {
            "data_dir":  DATA_DIR,
            "log_dir":   LOG_DIR,
            "db":        str(database.DB_PATH),
            "profiles":  str(Path(DATA_DIR) / "cb_profiles"),
            "images":    str(Path(DATA_DIR) / "images"),
        },
        "ai_base_url":       cfg.get(CK_AI_BASE_URL),
        "ai_api_key":        "__SET__" if cfg.get(CK_AI_API_KEY) else "",
        "ai_model":          cfg.get(CK_AI_MODEL),
        "image_model":       cfg.get(CK_IMAGE_MODEL),
        "feishu_app_id":     cfg.get(CK_FEISHU_APP_ID),
        "feishu_app_secret": "__SET__" if cfg.get(CK_FEISHU_APP_SECRET) else "",
    })
