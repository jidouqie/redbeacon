"""ui account — 把对话定下来的账号配置渲染成可视化两栏页，让用户审阅+微调+试生成。

设计（契合"无常驻服务"：服务生命周期完全包在本命令内，命令结束即退）：
  左栏：账号配置（人话标签，不暴露字段名），值已按对话结果预填，用户看哪不对改哪。
  右栏：一键「生成一篇预览」看效果——不消耗选题库、落库存起来、配图按左栏设定一起出；
        不推飞书（预览阶段不污染审核表）。可反复 改→生成→再改。
  用户点「完成返回」或超时 → 服务退出，把累计改了哪些字段汇报给 skill（stdout JSON）。

HTML 是内置固定模板（模型不在运行时手写）。浏览器 JS 只能通过 HTTP 跟本地通信，
故起一个 localhost 一次性服务；它不是 daemon，命令一结束就 server_close。
"""
from __future__ import annotations

import json
import socket
import subprocess
import sys
import threading
import time
from http.server import BaseHTTPRequestHandler, HTTPServer

from redbeacon import database
from ._runtime import out, err, now_iso, account_row, require_account

_TIMEOUT_SEC = 1800  # 30 分钟无操作自动退出

# 左栏可编辑项：字段名 → (人话标签, 是否多行, 分组, 兜底默认值)
# 默认值与 tasks/generate.py 内部兜底一致，保证"不改直接生成"无惊喜；绝不留空。
_GROUP_WHO = "这个号是做什么的"
_GROUP_STYLE = "内容怎么写"
# 用下拉选择（而非自由输入）的定位字段：字段名 → 选项列表
_STRATEGY_CHOICES = {
    "emoji_usage": ["较少", "适量", "丰富"],
}
_STRATEGY_FIELDS = [
    ("niche",                "赛道方向",   False, _GROUP_WHO,
     "生活方式分享"),
    ("target_audience",      "目标读者",   False, _GROUP_WHO,
     "对生活品质有要求的年轻人"),
    ("competitive_advantage","差异化亮点", False, _GROUP_WHO,
     "真实体验、不浮夸、给得出可落地的建议"),
    ("monetization",         "变现方向",   False, _GROUP_WHO,
     "涨粉沉淀，后续私域转化"),
    ("pain_points",          "读者痛点（一行一个）", True, _GROUP_WHO,
     "不知道怎么选\n踩过坑走过弯路\n想做但没方法"),
    ("tone",                 "语气",       False, _GROUP_STYLE,
     "亲切自然，专业但不刻板，像朋友分享而非说教"),
    ("opening_style",        "开头风格",   False, _GROUP_STYLE,
     "提问式或数字列举，前两行必须抓住读者注意力"),
    ("format_style",         "排版风格",   False, _GROUP_STYLE,
     "分段清晰，多用短句，每段2-3行，重点内容单独成行"),
    ("emoji_usage",          "表情用量",   False, _GROUP_STYLE,
     "适量"),
    ("content_length",       "篇幅",       False, _GROUP_STYLE,
     "300-500字"),
    ("visual_theme",         "视觉感觉",   False, _GROUP_STYLE,
     "简洁清爽，有高级感"),
]
# 文案风格框为空时填入的人话默认（让用户看得见、可改，而不是空白）。
# 注意：这里只放"这类内容怎么写"的人话指引——JSON 输出契约、占位符等程序逻辑
# 由 generate.py 的 DEFAULT_PROMPT 在生成时自动补，用户不可见、不用管。
_CT_DEFAULT_PROMPT = "紧扣这一类内容的角度来写，标题抓人，正文给得出干货或共鸣。"
# 内置类型的更贴切人话默认（按类型名匹配，匹配不上用 _CT_DEFAULT_PROMPT）
_CT_DEFAULT_BY_NAME = {
    "干货科普": "把一个知识点讲清楚讲透，多用具体步骤、清单、对比，让读者看完能直接照做。",
    "痛点解析": "戳中读者最头疼的那件事，先把痛点说到心坎里，再给出让人共鸣或恍然大悟的视角。",
    "经验分享": "用第一人称讲自己的真实经历或踩坑复盘，真诚、有细节，像朋友面对面聊。",
}

# 配图方式：值 → 人话
_IMAGE_MODE_LABELS = [
    ("cards", "图文卡片（把文字渲染成好看的卡片，稳定、不花钱）"),
    ("ai",    "AI 配图（让 AI 画封面图，需要配图片模型）"),
    ("both",  "两种都要（AI 封面 + 文字卡片）"),
]
# 卡片配色风格：内部值 → 人话（来自渲染器 _THEME_MAP 的合法键）
_CARD_THEME_LABELS = [
    ("default",           "默认·小红书紫"),
    ("botanical",         "森系绿"),
    ("professional",      "商务蓝"),
    ("retro",             "复古橙"),
    ("sketch",            "手绘铅笔"),
    ("terminal",          "极客终端"),
    ("neo-brutalism",     "撞色潮酷"),
    ("playful-geometric", "活泼几何"),
    ("macaron",           "马卡龙粉"),
    ("inkwash",           "水墨国风"),
    ("latte",             "奶咖拿铁"),
    ("skyblue",           "晴空蓝"),
    ("lavender",          "薰衣草紫"),
    ("midnight-gold",     "暗夜鎏金"),
    ("cyber",             "赛博霓虹"),
    ("morandi",           "莫兰迪灰"),
    ("random",            "随机"),
]
_VALID_MODES = {m for m, _ in _IMAGE_MODE_LABELS}
# 配图各项兜底默认（绝不留空）
_IMG_DEFAULTS = {
    "mode": "cards",
    "card_theme": "default",
    "ai_model": "",   # 仅 ai/both 模式才需要，cards 模式不强制
    # 封面「想要的样子」——大白话，不含占位符；赛道/标题/竖版骨架由程序生成时隐形补上
    "prompt_template": "明亮清新、简约高级，主体突出、画面干净，上方留白方便放标题",
}


def dispatch(args) -> None:
    if args.sub == "account":
        _account(args)
    elif args.sub == "dashboard":
        _dashboard(args)
    else:
        err(f"未知 ui 子命令：{args.sub}")


# ── 实时拉中转站可用模型（模型名会换代，写死/手敲迟早失效，故每次现拉）──────────

def _list_models() -> dict:
    """从配置的中转站拉可用模型，分成「写文案的」和「画图的」两类。
    返回 {ok, text:[...], image:[...], error}。拿不到时降级（ok=False），
    前端改用手填输入框，绝不卡死面板。"""
    from redbeacon import config as cfg
    import urllib.request

    base = (cfg.get("ai_base_url") or "").rstrip("/")
    key = cfg.get("ai_api_key") or ""
    if not base or not key:
        return {"ok": False, "text": [], "image": [], "error": "未配置 AI（base_url / key）"}
    url = base + "/models"
    try:
        req = urllib.request.Request(url, headers={"Authorization": f"Bearer {key}"})
        with urllib.request.urlopen(req, timeout=8) as r:
            data = json.loads(r.read().decode("utf-8"))
        ids = sorted(m.get("id", "") for m in data.get("data", []) if m.get("id"))
    except Exception as e:
        return {"ok": False, "text": [], "image": [], "error": str(e)[:120]}
    # 名字里带 image 的当画图模型，其余当写文案模型（贴合中转站命名）
    img = [i for i in ids if "image" in i.lower()]
    txt = [i for i in ids if "image" not in i.lower()]
    return {"ok": True, "text": txt, "image": img, "error": ""}


# ── 读取账号全貌 ──────────────────────────────────────────────────────────────

def _load_state(account_id: int) -> dict:
    acc = account_row(account_id)
    with database.cursor() as c:
        srow = c.execute(
            "SELECT data FROM strategy WHERE account_id=? ORDER BY version DESC LIMIT 1",
            (account_id,),
        ).fetchone()
        types = c.execute(
            "SELECT name, prompt_template FROM content_type WHERE account_id=? ORDER BY sort_order, id",
            (account_id,),
        ).fetchall()
        img = c.execute(
            "SELECT mode, card_theme, prompt_template, ai_model FROM image_strategy WHERE account_id=?",
            (account_id,),
        ).fetchone()
        topic_stats = c.execute(
            "SELECT COUNT(*) AS total, SUM(CASE WHEN is_used=0 THEN 1 ELSE 0 END) AS unused "
            "FROM topic WHERE account_id=?",
            (account_id,),
        ).fetchone()
    strategy = {}
    if srow:
        try:
            strategy = json.loads(srow["data"] or "{}")
        except Exception:
            strategy = {}

    def _fmt(v):
        return "\n".join(v) if isinstance(v, list) else (v or "")

    # 定位：库里有值用库里的，空则用兜底默认（绝不留空）
    strat_out = {}
    for k, _label, _ml, _grp, default in _STRATEGY_FIELDS:
        v = _fmt(strategy.get(k, "")).strip()
        v = v if v else default
        # 下拉字段：库里若是旧的自由文本（不在选项里），回落默认档，保证下拉有选中
        if k in _STRATEGY_CHOICES and v not in _STRATEGY_CHOICES[k]:
            v = default
        strat_out[k] = v

    # 文案风格：每类内容；prompt_template 空则填人话默认（让用户看得见、可改）
    ct_out = []
    for t in types:
        tpl = (t["prompt_template"] or "").strip()
        default = _CT_DEFAULT_BY_NAME.get(t["name"], _CT_DEFAULT_PROMPT)
        ct_out.append({"name": t["name"],
                       "prompt_template": tpl if tpl else default})

    # 配图：库里有值用库里的，空则兜底默认
    img_out = dict(_IMG_DEFAULTS)
    if img:
        for k in ("mode", "card_theme", "prompt_template", "ai_model"):
            v = (img[k] or "").strip() if img[k] else ""
            if v:
                img_out[k] = v
    # 卡片配色：库里若是无效值（如历史脏数据 cool），兜底回「默认」，保证下拉一定有选中
    _valid_themes = {t for t, _ in _CARD_THEME_LABELS}
    if img_out.get("card_theme") not in _valid_themes:
        img_out["card_theme"] = "default"

    from redbeacon import config as cfg
    text_model = cfg.get("ai_model") or ""        # 全局：写文案用的模型
    image_model_global = cfg.get("image_model") or ""

    return {
        "account_id": account_id,
        "display_name": acc.get("display_name") or f"redbeacon-{account_id}",
        "strategy": strat_out,
        "content_types": ct_out,
        "image": img_out,
        "text_model": text_model,
        # 账号配图模型为空时退回全局，供下拉默认选中
        "image_model": img_out.get("ai_model") or image_model_global,
        "models": _list_models(),
        "topics_unused": (topic_stats["unused"] or 0) if topic_stats else 0,
        "topics_total": (topic_stats["total"] or 0) if topic_stats else 0,
    }


# ── 落库（只写传回来的、且确有变化的字段）──────────────────────────────────────

# 这些定位字段在库里以数组存储，页面用换行分隔，回写时拆回数组
_LIST_FIELDS = {"pain_points"}


def _apply(account_id: int, before: dict, submitted: dict) -> dict:
    changed: dict = {"strategy": [], "content_types": [], "image": [], "config": []}
    now = now_iso()

    # 全局写文案模型（顶层 config.ai_model）——空字符串不覆盖，避免误清
    from redbeacon import config as cfg
    sub_cfg = submitted.get("config", {})
    new_text_model = (sub_cfg.get("ai_model") or "").strip()
    if new_text_model and new_text_model != (before.get("text_model") or ""):
        cfg.set("ai_model", new_text_model)
        changed["config"].append("ai_model")

    new_strat = submitted.get("strategy", {})
    valid_keys = {f[0] for f in _STRATEGY_FIELDS}
    diff_strat = {k: v for k, v in new_strat.items()
                  if k in valid_keys and v != before["strategy"].get(k, "")}
    if diff_strat:
        with database.cursor(commit=True) as c:
            row = c.execute(
                "SELECT id, data FROM strategy WHERE account_id=? ORDER BY version DESC LIMIT 1",
                (account_id,),
            ).fetchone()
            data = {}
            if row:
                try:
                    data = json.loads(row["data"] or "{}")
                except Exception:
                    data = {}
            for k, v in diff_strat.items():
                if k in _LIST_FIELDS:
                    data[k] = [ln.strip() for ln in v.splitlines() if ln.strip()]
                else:
                    data[k] = v
            if row is None:
                c.execute(
                    "INSERT INTO strategy (account_id, version, data, niche, posting_freq, created_at, updated_at) "
                    "VALUES (?, 1, ?, ?, '', ?, ?)",
                    (account_id, json.dumps(data, ensure_ascii=False), data.get("niche", ""), now, now),
                )
            else:
                c.execute(
                    "UPDATE strategy SET data=?, niche=?, updated_at=? WHERE id=?",
                    (json.dumps(data, ensure_ascii=False), data.get("niche", ""), now, row["id"]),
                )
        changed["strategy"] = list(diff_strat.keys())

    before_ct = {c["name"]: c["prompt_template"] for c in before["content_types"]}
    for ct in submitted.get("content_types", []):
        name = ct.get("name")
        tpl = ct.get("prompt_template", "")
        if name in before_ct and tpl != before_ct[name]:
            with database.cursor(commit=True) as c:
                c.execute(
                    "UPDATE content_type SET prompt_template=?, updated_at=? WHERE account_id=? AND name=?",
                    (tpl, now, account_id, name),
                )
            changed["content_types"].append(name)

    new_img = submitted.get("image", {})
    img_diff = {}
    for k in ("mode", "card_theme", "prompt_template", "ai_model"):
        if k in new_img and new_img[k] != before["image"].get(k, ""):
            if k == "mode" and new_img[k] not in _VALID_MODES:
                continue
            img_diff[k] = new_img[k]
    if img_diff:
        with database.cursor(commit=True) as c:
            row = c.execute("SELECT account_id FROM image_strategy WHERE account_id=?",
                            (account_id,)).fetchone()
            if row is None:
                c.execute(
                    "INSERT INTO image_strategy (account_id, mode, prompt_template, card_theme, "
                    "reference_images, ai_model, updated_at) VALUES (?, 'cards', '', 'default', '[]', NULL, ?)",
                    (account_id, now),
                )
            sets = ", ".join(f"{k}=?" for k in img_diff)
            c.execute(f"UPDATE image_strategy SET {sets}, updated_at=? WHERE account_id=?",
                      list(img_diff.values()) + [now, account_id])
        changed["image"] = list(img_diff.keys())

    return changed


# ── 一键生成预览（不消耗选题、落库、配图按设定、不推飞书）──────────────────────

def _pick_preview_topic(account_id: int) -> str:
    """挑一条未用选题的文本作为预览素材；不标记已用（不消耗）。
    选题库为空时返回一个合成选题——确保始终走 topic_override 路径，绝不消耗选题库。"""
    with database.cursor() as c:
        row = c.execute(
            "SELECT content FROM topic WHERE account_id=? AND is_used=0 ORDER BY id LIMIT 1",
            (account_id,),
        ).fetchone()
        if row:
            return row["content"]
        # 没有选题：用赛道名合成一个，避免 run_generate 回落到会消耗选题的取题逻辑
        srow = c.execute(
            "SELECT data FROM strategy WHERE account_id=? ORDER BY version DESC LIMIT 1",
            (account_id,),
        ).fetchone()
    niche = "这个领域"
    if srow:
        try:
            niche = json.loads(srow["data"] or "{}").get("niche") or niche
        except Exception:
            pass
    return f"新手如何入门{niche}"


def _generate_preview(account_id: int) -> dict:
    """生成一篇并落库；返回 {content_id, title, body, tags, images}。"""
    from redbeacon.tasks import generate as gen_mod

    topic = _pick_preview_topic(account_id)  # 始终非空 → 走 topic_override，不消耗选题库
    # 预览不推飞书：临时旁路 _push_to_feishu
    orig_push = gen_mod._push_to_feishu
    gen_mod._push_to_feishu = lambda *a, **k: None
    try:
        content_id = gen_mod.run_generate(
            account_id=account_id,
            topic_override=topic,   # None 时 run_generate 会自己从库里取（极端兜底）
            image_mode=None,        # None = 用账号 image_strategy 的设定
        )
    finally:
        gen_mod._push_to_feishu = orig_push

    with database.cursor() as c:
        row = c.execute("SELECT title, body, tags, images FROM content_queue WHERE id=?",
                        (content_id,)).fetchone()
        imode_row = c.execute("SELECT mode FROM image_strategy WHERE account_id=?",
                              (account_id,)).fetchone()
    def _arr(x):
        try:
            return json.loads(x) if x else []
        except Exception:
            return []
    images = _arr(row["images"]) if row else []
    # 按文件名分类：AI 封面 vs 文字卡片，好让前端说清"配图方式有没有真生效"
    ai_imgs = [p for p in images if "ai_image" in p.rsplit("/", 1)[-1].lower()]
    card_imgs = [p for p in images if p not in ai_imgs]
    mode = (imode_row["mode"] if imode_row else "cards") or "cards"
    want_ai = mode in ("ai", "both")
    if want_ai and not ai_imgs:
        note = "⚠️ 选了 AI 配图，但这次没生成出封面（多半是画图模型无效/额度问题）——换个「用哪个 AI 画图」再试。"
    else:
        bits = []
        if ai_imgs:   bits.append(f"AI 封面 {len(ai_imgs)} 张")
        if card_imgs: bits.append(f"文字卡片 {len(card_imgs)} 张")
        note = "本次配图：" + ("、".join(bits) if bits else "无")
    return {
        "content_id": content_id,
        "topic": topic or "(自动选题)",
        "title": row["title"] if row else "",
        "body": row["body"] if row else "",
        "tags": _arr(row["tags"]) if row else [],
        "images": images,
        "image_note": note,
    }


# ── 一次性本地服务 ────────────────────────────────────────────────────────────

def _free_port() -> int:
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.bind(("127.0.0.1", 0))
    port = s.getsockname()[1]
    s.close()
    return port


def _account(args) -> None:
    require_account(args.account_id)
    state = _load_state(args.account_id)
    html = _render_html(state)

    all_changed: dict = {"strategy": set(), "content_types": set(), "image": set(), "config": set()}
    finished = threading.Event()
    port = _free_port()

    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *a):
            pass

        def _json(self, code, obj):
            body = json.dumps(obj, ensure_ascii=False).encode("utf-8")
            self.send_response(code)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def do_GET(self):
            if self.path in ("/", "/index.html"):
                body = html.encode("utf-8")
                self.send_response(200)
                self.send_header("Content-Type", "text/html; charset=utf-8")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)
            elif self.path.startswith("/img?"):
                self._serve_image()
            elif self.path.startswith("/theme-preview"):
                self._serve_theme_preview()
            else:
                self.send_response(404); self.end_headers()

        def _serve_theme_preview(self):
            from urllib.parse import urlparse, parse_qs
            from pathlib import Path as _P
            q = parse_qs(urlparse(self.path).query)
            name = (q.get("name", [""])[0] or "")
            valid = {t for t, _ in _CARD_THEME_LABELS}
            if name not in valid or name == "random":
                self.send_response(404); self.end_headers(); return
            f = _P(__file__).resolve().parent.parent / "assets" / "theme_previews" / f"{name}.png"
            if not f.is_file():
                self.send_response(404); self.end_headers(); return
            data = f.read_bytes()
            self.send_response(200)
            self.send_header("Content-Type", "image/png")
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)

        def _serve_image(self):
            from urllib.parse import urlparse, parse_qs, unquote
            import os
            q = parse_qs(urlparse(self.path).query)
            path = unquote(q.get("p", [""])[0])
            # 只允许读数据目录下的图片
            from ._runtime import DATA_DIR
            real = os.path.realpath(path)
            if not real.startswith(os.path.realpath(DATA_DIR)) or not os.path.isfile(real):
                self.send_response(404); self.end_headers(); return
            ext = real.rsplit(".", 1)[-1].lower()
            ctype = {"png": "image/png", "jpg": "image/jpeg", "jpeg": "image/jpeg"}.get(ext, "application/octet-stream")
            with open(real, "rb") as f:
                data = f.read()
            self.send_response(200)
            self.send_header("Content-Type", ctype)
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)

        def do_POST(self):
            length = int(self.headers.get("Content-Length", 0))
            raw = self.rfile.read(length) if length else b"{}"
            try:
                payload = json.loads(raw.decode("utf-8"))
            except Exception:
                payload = {}

            if self.path == "/save":
                # 用最新库状态做 diff 基准，支持反复保存
                base = _load_state(args.account_id)
                changed = _apply(args.account_id, base, payload)
                for k in all_changed:
                    all_changed[k].update(changed[k])
                self._json(200, {"ok": True, "changed": changed})

            elif self.path == "/preview":
                # 先把当前页面的改动落库，再用最新设定生成
                base = _load_state(args.account_id)
                changed = _apply(args.account_id, base, payload)
                for k in all_changed:
                    all_changed[k].update(changed[k])
                try:
                    result = _generate_preview(args.account_id)
                    self._json(200, {"ok": True, "preview": result})
                except Exception as e:
                    self._json(200, {"ok": False, "error": str(e)})

            elif self.path == "/done":
                base = _load_state(args.account_id)
                changed = _apply(args.account_id, base, payload)
                for k in all_changed:
                    all_changed[k].update(changed[k])
                self._json(200, {"ok": True})
                finished.set()
            else:
                self.send_response(404); self.end_headers()

    httpd = HTTPServer(("127.0.0.1", port), Handler)
    httpd.timeout = 1

    url = f"http://127.0.0.1:{port}/"
    if sys.platform == "darwin":
        subprocess.Popen(["open", url])
    elif sys.platform.startswith("linux"):
        subprocess.Popen(["xdg-open", url])
    print(json.dumps({"status": "ui_opened", "url": url,
                      "msg": "已打开账号配置面板：左边看配置改配置，右边可生成一篇预览看效果，"
                             "弄好点「完成返回对话」"}, ensure_ascii=False))
    sys.stdout.flush()

    deadline = time.time() + _TIMEOUT_SEC
    while not finished.is_set() and time.time() < deadline:
        httpd.handle_request()
    httpd.server_close()

    changed_out = {k: sorted(v) for k, v in all_changed.items()}
    any_change = any(changed_out.values())
    out({
        "finished": finished.is_set(),
        "timed_out": not finished.is_set(),
        "account_id": args.account_id,
        "changed": changed_out,
        "any_change": any_change,
    })


# ── 运营看板（只读，一眼看全部账号）──────────────────────────────────────────

def _load_dashboard() -> dict:
    """聚合所有账号的运营态：在线状态、定位、审核表、内容数(按状态)、可用选题。
    全部字段已转人话，前端直接展示，不出现库字段/英文状态。"""
    from redbeacon.services import license as _lic

    accounts = []
    with database.cursor() as c:
        rows = c.execute(
            "SELECT id, display_name, nickname, login_status, last_login_check, proxy, "
            "feishu_app_token, feishu_table_id FROM account ORDER BY id"
        ).fetchall()
        for r in rows:
            aid = r["id"]
            niche_row = c.execute(
                "SELECT niche FROM strategy WHERE account_id=? AND niche IS NOT NULL "
                "ORDER BY version DESC, updated_at DESC LIMIT 1", (aid,)
            ).fetchone()
            counts = {"pending_review": 0, "published": 0, "failed": 0}
            for cr in c.execute(
                "SELECT status, COUNT(*) n FROM content_queue WHERE account_id=? GROUP BY status",
                (aid,),
            ):
                counts[cr["status"]] = cr["n"]
            unused = c.execute(
                "SELECT COUNT(*) FROM topic WHERE account_id=? AND is_used=0", (aid,)
            ).fetchone()[0]
            total_content = counts["pending_review"] + counts["published"] + counts["failed"]

            ls = r["login_status"]
            online = "在线" if ls == "logged_in" else ("已掉线" if ls == "logged_out" else "未登录")
            accounts.append({
                "id": aid,
                "name": r["display_name"] or r["nickname"] or f"账号{aid}",
                "online": online,
                "online_ok": ls == "logged_in",
                "last_check": (r["last_login_check"] or "")[:16].replace("T", " "),
                "niche": niche_row["niche"] if niche_row and niche_row["niche"] else "",
                "feishu_ok": bool(r["feishu_app_token"] and r["feishu_table_id"]),
                "proxy_on": bool(r["proxy"]),
                "pending": counts["pending_review"],
                "published": counts["published"],
                "failed": counts["failed"],
                "total": total_content,
                "unused_topics": unused,
                "topics_low": unused < 5,
            })

    return {
        "accounts": accounts,
        "summary": {
            "account_count": len(accounts),
            "max_accounts": _lic.max_accounts(),
            "tier": "已解锁多账号" if _lic.is_unlocked() else "免费版（单账号）",
            "online_count": sum(1 for a in accounts if a["online_ok"]),
            "pending_total": sum(a["pending"] for a in accounts),
            "published_total": sum(a["published"] for a in accounts),
            "low_topic_count": sum(1 for a in accounts if a["topics_low"]),
        },
    }


def _render_dashboard_html(data: dict) -> str:
    return _DASH_HTML.replace("__DATA__", json.dumps(data, ensure_ascii=False))


def _dashboard(args) -> None:
    if not _account_count():
        err("还没有账号，先建一个账号再看看板", next="redbeacon accounts create")

    finished = threading.Event()
    port = _free_port()

    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *a):
            pass

        def _json(self, code, obj):
            body = json.dumps(obj, ensure_ascii=False).encode("utf-8")
            self.send_response(code)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def do_GET(self):
            if self.path in ("/", "/index.html"):
                body = _render_dashboard_html(_load_dashboard()).encode("utf-8")
                self.send_response(200)
                self.send_header("Content-Type", "text/html; charset=utf-8")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)
            elif self.path == "/data":
                # 前端刷新按钮：拿最新聚合，不重开页面
                self._json(200, _load_dashboard())
            else:
                self.send_response(404); self.end_headers()

        def do_POST(self):
            if self.path == "/done":
                self._json(200, {"ok": True})
                finished.set()
            else:
                self.send_response(404); self.end_headers()

    httpd = HTTPServer(("127.0.0.1", port), Handler)
    httpd.timeout = 1

    url = f"http://127.0.0.1:{port}/"
    if sys.platform == "darwin":
        subprocess.Popen(["open", url])
    elif sys.platform.startswith("linux"):
        subprocess.Popen(["xdg-open", url])
    print(json.dumps({"status": "ui_opened", "url": url,
                      "msg": "已打开运营看板：一眼看全部账号的在线/内容/选题情况，看完点「关闭看板」"},
                     ensure_ascii=False))
    sys.stdout.flush()

    deadline = time.time() + _TIMEOUT_SEC
    while not finished.is_set() and time.time() < deadline:
        httpd.handle_request()
    httpd.server_close()

    out({"finished": finished.is_set(), "timed_out": not finished.is_set()})


def _account_count() -> int:
    with database.cursor() as c:
        return c.execute("SELECT COUNT(*) FROM account").fetchone()[0]


# ── HTML 模板（内置固定，不在运行时由模型生成）────────────────────────────────

def _render_html(state: dict) -> str:
    # 按分组拼字段；每个分组一张卡片，组内字段紧凑两列（多行项独占整行）
    groups: dict[str, list[str]] = {}
    for key, label, multiline, group, _default in _STRATEGY_FIELDS:
        if key in _STRATEGY_CHOICES:
            opts = "".join(f'<option value="{o}">{o}</option>' for o in _STRATEGY_CHOICES[key])
            ctrl = f'<select data-strat="{key}">{opts}</select>'
        elif multiline:
            ctrl = f'<textarea data-strat="{key}" rows="3"></textarea>'
        else:
            ctrl = f'<input data-strat="{key}">'
        cls = "fld wide" if multiline else "fld"
        groups.setdefault(group, []).append(
            f'<label class="{cls}"><span class="lab">{label}</span>{ctrl}</label>')
    group_cards = "".join(
        f'<div class="card"><h2>{name}</h2><div class="grid">{"".join(rows)}</div></div>'
        for name, rows in groups.items())
    mode_opts = "".join(f'<option value="{v}">{t}</option>' for v, t in _IMAGE_MODE_LABELS)
    theme_list = json.dumps(_CARD_THEME_LABELS, ensure_ascii=False)
    return (_HTML
            .replace("__DATA__", json.dumps(state, ensure_ascii=False))
            .replace("__GROUP_CARDS__", group_cards)
            .replace("__MODE_OPTS__", mode_opts)
            .replace("__THEME_LIST__", theme_list))


_HTML = r"""<!doctype html>
<html lang="zh"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>RedBeacon 账号配置</title>
<style>
  :root { --bg:#0f1115; --card:#1a1d24; --bd:#2a2f3a; --fg:#e8eaed; --mut:#8b93a1; --accent:#ff4d6d; --ok:#37d39b; }
  * { box-sizing:border-box; }
  body { margin:0; background:var(--bg); color:var(--fg);
         font:14px/1.65 -apple-system,BlinkMacSystemFont,"PingFang SC",sans-serif; }
  .top { padding:18px 28px; border-bottom:1px solid var(--bd); display:flex; align-items:baseline; gap:12px; }
  .top h1 { font-size:18px; margin:0; }
  .top .who { color:var(--accent); font-weight:600; }
  .top .tip { color:var(--mut); font-size:12.5px; margin-left:auto; }
  .layout { display:grid; grid-template-columns:1fr 1fr; gap:0; height:calc(100vh - 59px); }
  .col { overflow-y:auto; padding:22px 28px; }
  .col.left { border-right:1px solid var(--bd); }
  .card { background:var(--card); border:1px solid var(--bd); border-radius:12px; padding:18px 20px; margin-bottom:16px; }
  .card h2 { font-size:14px; margin:0 0 14px; color:var(--accent); letter-spacing:.3px; }
  .grid { display:grid; grid-template-columns:1fr 1fr; gap:11px 16px; }
  .fld { display:flex; flex-direction:column; gap:4px; }
  .fld.wide { grid-column:1 / -1; }
  .fld .lab { font-size:12.5px; font-weight:600; color:var(--mut); }
  input, select, textarea { background:var(--bg); border:1px solid var(--bd); color:var(--fg);
          border-radius:8px; padding:9px 11px; font:inherit; width:100%; }
  textarea { resize:vertical; }
  .ct { margin-bottom:11px; }
  .ct b { font-size:12.5px; color:var(--mut); display:block; margin-bottom:4px; }
  .ct textarea { min-height:64px; font-size:13px; }
  .actions { position:sticky; bottom:0; background:linear-gradient(transparent,var(--bg) 28%); padding:16px 0 6px; display:flex; gap:10px; }
  button { background:var(--accent); color:#fff; border:0; border-radius:8px; padding:11px 20px; font:inherit; font-weight:600; cursor:pointer; }
  button.ghost { background:transparent; border:1px solid var(--bd); color:var(--mut); }
  button:disabled { opacity:.5; cursor:default; }
  #msg { color:var(--mut); align-self:center; font-size:12.5px; }
  .pv-empty { color:var(--mut); text-align:center; margin-top:60px; line-height:2; }
  .pv-title { font-size:17px; font-weight:700; margin:0 0 12px; }
  .pv-body { white-space:pre-wrap; background:var(--card); border:1px solid var(--bd); border-radius:10px; padding:16px; }
  .pv-tags { margin-top:12px; color:#7fb4ff; font-size:13px; }
  .pv-imgs { display:flex; flex-wrap:wrap; gap:8px; margin-top:14px; }
  .pv-imgs img { width:130px; border-radius:8px; border:1px solid var(--bd); cursor:zoom-in; transition:transform .12s; }
  .pv-imgs img:hover { transform:scale(1.03); border-color:var(--accent); }
  .lightbox { position:fixed; inset:0; background:rgba(0,0,0,.86); display:none; align-items:center; justify-content:center; z-index:999; cursor:zoom-out; }
  .lightbox.show { display:flex; }
  .lightbox img { max-width:92vw; max-height:92vh; border-radius:10px; box-shadow:0 8px 40px rgba(0,0,0,.6); }
  .lightbox .x { position:absolute; top:18px; right:24px; color:#fff; font-size:30px; line-height:1; opacity:.8; cursor:pointer; }
  .lightbox .x:hover { opacity:1; }
  /* 卡片配色：缩略图选择网格 + 悬停放大浮层 */
  .theme-grid { display:grid; grid-template-columns:repeat(5,1fr); gap:7px; margin-top:5px; }
  .theme-cell { border:2px solid var(--bd); border-radius:8px; padding:4px; cursor:pointer; background:var(--bg); transition:border-color .12s, box-shadow .12s; }
  .theme-cell:hover { border-color:var(--accent); }
  .theme-cell.sel { border-color:var(--accent); box-shadow:0 0 0 2px rgba(255,77,109,.3); }
  .theme-cell img { width:100%; height:78px; object-fit:cover; object-position:top center; border-radius:5px; display:block; background:#222; }
  .theme-cell .tlab { font-size:10px; color:var(--mut); margin-top:4px; line-height:1.25; text-align:center; }
  .theme-cell.sel .tlab { color:var(--fg); }
  .theme-cell .dice-ico { height:78px; display:flex; align-items:center; justify-content:center; font-size:34px; }
  #theme-zoom { position:fixed; z-index:900; display:none; pointer-events:none; border-radius:12px; overflow:hidden; box-shadow:0 14px 48px rgba(0,0,0,.7); border:1px solid var(--bd); background:#000; }
  #theme-zoom img { width:330px; display:block; }
  .pv-meta { color:var(--mut); font-size:12px; margin-bottom:14px; }
  .spin { color:var(--accent); }
  @keyframes spin360 { to { transform:rotate(360deg); } }
  .loading-wrap { text-align:center; margin-top:64px; color:var(--mut); }
  .loading-wrap .ring { width:48px; height:48px; border:4px solid var(--bd); border-top-color:var(--accent);
                        border-radius:50%; margin:0 auto 20px; animation:spin360 .8s linear infinite; }
  .loading-wrap .big { color:var(--fg); font-size:15px; font-weight:600; }
  .loading-wrap .step { font-size:12.5px; margin-top:8px; }
  button.loading { position:relative; color:transparent !important; }
  button.loading::after { content:''; position:absolute; left:50%; top:50%; width:16px; height:16px;
        margin:-8px 0 0 -8px; border:2px solid rgba(255,255,255,.5); border-top-color:#fff;
        border-radius:50%; animation:spin360 .7s linear infinite; }
</style></head>
<body>
  <div class="top"><h1>账号配置 · <span class="who" id="who"></span></h1>
    <span class="tip">下面是按我们聊的内容帮你定好的方案，看哪不对就改哪，不用全填。右边能直接生成一篇看效果。</span></div>
  <div class="layout">
    <div class="col left">
      __GROUP_CARDS__
      <div class="card"><h2>各类内容的写法</h2><div id="cts"></div></div>
      <div class="card"><h2>用哪个 AI 写文案</h2>
        <div class="grid">
          <label class="fld wide"><span class="lab">写文案的模型（拿不准就保持当前）</span>
            <select id="text-model-sel"></select>
            <input id="text-model" style="display:none" placeholder="模型代号"></label>
        </div>
      </div>
      <div class="card"><h2>配图</h2>
        <div class="grid">
          <label class="fld"><span class="lab">配图方式</span><select id="img-mode">__MODE_OPTS__</select></label>
          <div class="fld wide" id="theme-wrap"><span class="lab">卡片配色（鼠标悬停看效果，点一下选中）</span>
            <div class="theme-grid" id="theme-grid"></div>
            <input type="hidden" id="img-theme"></div>
          <label class="fld" id="model-wrap"><span class="lab">用哪个 AI 画图</span>
            <select id="img-model-sel"></select>
            <input id="img-model" style="display:none" placeholder="模型代号"></label>
          <label class="fld wide" id="prompt-wrap"><span class="lab">封面想要的样子（大白话描述，比如：明亮清新、ins 简约、主体突出）</span><textarea id="img-prompt" rows="2"></textarea></label>
        </div>
      </div>
      <div class="actions">
        <button onclick="save()">保存修改</button>
        <button class="ghost" onclick="done()">完成返回对话</button>
        <span id="msg"></span>
      </div>
    </div>
    <div class="col right">
      <div class="card"><h2>试生成一篇看看效果</h2>
        <p style="color:var(--mut);font-size:12.5px;margin:0 0 12px">
          用左边的设定生成一篇笔记（会先存一下你的改动）。不占用选题库，生成的笔记会进内容队列。觉得不对就回左边改，或回到对话里告诉我怎么调。</p>
        <button id="gen" onclick="preview()">⚡ 生成一篇预览</button>
        <span id="gmsg" style="margin-left:10px;color:var(--mut);font-size:12.5px"></span>
      </div>
      <div id="pv"><div class="pv-empty">点上面的按钮，<br>这里会显示生成出来的笔记</div></div>
    </div>
  </div>
  <div id="lightbox" class="lightbox" onclick="closeZoom()"><span class="x">×</span><img id="lightbox-img" alt=""></div>
<script>
const S = __DATA__;
const PORT_BASE = location.origin;
document.getElementById('who').textContent = S.display_name;
document.querySelectorAll('[data-strat]').forEach(el => { el.value = S.strategy[el.dataset.strat] || ''; });
const ctBox = document.getElementById('cts');
S.content_types.forEach((ct,i) => {
  const d = document.createElement('div'); d.className='ct';
  d.innerHTML = '<b>'+ct.name+'</b><textarea data-ct="'+i+'"></textarea>';
  ctBox.appendChild(d); d.querySelector('textarea').value = ct.prompt_template || '';
});
document.getElementById('img-mode').value = S.image.mode || 'cards';
document.getElementById('img-prompt').value = S.image.prompt_template || '';

// 卡片配色：缩略图选择 + 悬停放大预览
const THEMES = __THEME_LIST__;
const themeGrid = document.getElementById('theme-grid');
const themeInput = document.getElementById('img-theme');
let curTheme = S.image.card_theme || 'default';
themeInput.value = curTheme;
const tzoom = document.createElement('div'); tzoom.id='theme-zoom'; tzoom.innerHTML='<img alt="">';
document.body.appendChild(tzoom);
function themeUrl(v){ return '/theme-preview?name='+encodeURIComponent(v); }
function showTZoom(e, v){
  const img = tzoom.querySelector('img'); const u = location.origin + themeUrl(v);
  if(img.getAttribute('src') !== u) img.src = u;
  tzoom.style.display='block';
  const w=332, h=445; let x=e.clientX+22, y=e.clientY-h/2;
  if(x+w>window.innerWidth) x=e.clientX-w-22;
  if(y<10) y=10; if(y+h>window.innerHeight) y=window.innerHeight-h-10;
  tzoom.style.left=x+'px'; tzoom.style.top=y+'px';
}
function hideTZoom(){ tzoom.style.display='none'; }
function renderThemeGrid(){
  themeGrid.innerHTML = THEMES.map(([v,label]) => {
    const sel = (v===curTheme) ? ' sel' : '';
    if(v==='random')
      return '<div class="theme-cell'+sel+'" data-theme="random"><div class="dice-ico">🎲</div><div class="tlab">'+label+'</div></div>';
    return '<div class="theme-cell'+sel+'" data-theme="'+v+'"><img src="'+themeUrl(v)+'" loading="lazy" alt=""><div class="tlab">'+label+'</div></div>';
  }).join('');
  themeGrid.querySelectorAll('.theme-cell').forEach(c => {
    const v = c.dataset.theme;
    c.onclick = () => { curTheme=v; themeInput.value=v; renderThemeGrid(); };
    if(v!=='random'){
      c.onmousemove = (e)=>showTZoom(e, v);
      c.onmouseleave = hideTZoom;
    } else { c.onmouseenter = hideTZoom; }
  });
}
renderThemeGrid();

// 模型选择：能从中转站拉到就用下拉，拉不到降级成手填输入框（绝不卡住）
const MODELS = S.models || {ok:false, text:[], image:[], error:''};
function setupModel(selId, inpId, options, current){
  const sel = document.getElementById(selId), inp = document.getElementById(inpId);
  current = current || '';
  if (MODELS.ok && options && options.length){
    sel.style.display=''; inp.style.display='none';
    let opts = options.slice();
    if (current && opts.indexOf(current)===-1) opts.unshift(current); // 当前值即便已下架也保留可见
    sel.innerHTML = opts.map(m => '<option value="'+m+'"'+(m===current?' selected':'')+'>'+m+'</option>').join('');
    if (current) sel.value = current;
  } else {
    // 没连上模型列表：手填，并把原因写进 placeholder
    sel.style.display='none'; inp.style.display='';
    inp.value = current;
    inp.placeholder = MODELS.error ? ('手填模型代号（没拉到列表：'+MODELS.error+'）') : '手填模型代号';
  }
}
setupModel('text-model-sel','text-model', MODELS.text,  S.text_model);
setupModel('img-model-sel','img-model',   MODELS.image, S.image_model);
function modelVal(selId, inpId){
  const sel=document.getElementById(selId);
  return (sel.style.display!=='none') ? sel.value : document.getElementById(inpId).value;
}
function syncImgFields(){
  const m = document.getElementById('img-mode').value;
  document.getElementById('theme-wrap').style.display  = (m==='cards'||m==='both') ? '' : 'none';
  document.getElementById('model-wrap').style.display  = (m==='ai'||m==='both') ? '' : 'none';
  document.getElementById('prompt-wrap').style.display = (m==='ai'||m==='both') ? '' : 'none';
}
document.getElementById('img-mode').addEventListener('change', syncImgFields); syncImgFields();

function collect(){
  const strategy = {};
  document.querySelectorAll('[data-strat]').forEach(el => { strategy[el.dataset.strat] = el.value; });
  const content_types = S.content_types.map((ct,i) => ({ name: ct.name,
    prompt_template: document.querySelector('[data-ct="'+i+'"]').value }));
  const image = { mode: document.getElementById('img-mode').value,
    card_theme: document.getElementById('img-theme').value,
    ai_model: modelVal('img-model-sel','img-model'),
    prompt_template: document.getElementById('img-prompt').value };
  const config = { ai_model: modelVal('text-model-sel','text-model') };
  return {strategy, content_types, image, config};
}
async function post(path, body){
  const r = await fetch(PORT_BASE+path, {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(body)});
  return r.json();
}
async function save(){
  const msg = document.getElementById('msg');
  msg.textContent = '保存中…';
  try {
    await post('/save', collect());
    msg.textContent = '已保存 ✓';
    setTimeout(()=>{ msg.textContent=''; }, 2000);
  } catch(e) {
    msg.textContent = '保存失败：' + (e && e.message || e);
  }
}
async function preview(){
  const btn = document.getElementById('gen'); btn.disabled = true; btn.classList.add('loading');
  const gmsg = document.getElementById('gmsg');
  const pv = document.getElementById('pv');
  gmsg.textContent = '';
  // 右栏直观 loading：旋转圈 + 阶段文字（单次请求，阶段按时间推进，给"在动"的感觉）
  const withCards = (document.getElementById('img-mode').value)!=='ai';
  const steps = ['调用 AI 写文案…'].concat(withCards?['根据配色渲染卡片…']:[]).concat(['快好了…']);
  pv.innerHTML = '<div class="loading-wrap"><div class="ring"></div><div class="big">正在生成预览</div>'
               + '<div class="step" id="lstep">'+steps[0]+'</div>'
               + '<div class="step" style="opacity:.7">大约十几秒，请稍候</div></div>';
  let si = 0;
  const stepTimer = setInterval(()=>{ si=Math.min(si+1,steps.length-1);
    const el=document.getElementById('lstep'); if(el) el.textContent=steps[si]; }, 4500);
  let j;
  try {
    j = await post('/preview', collect());
  } catch(e) {
    clearInterval(stepTimer); btn.disabled=false; btn.classList.remove('loading'); gmsg.textContent='';
    pv.innerHTML = '<div class="pv-empty">生成请求没发出去或中断了：<br>'+((e&&e.message)||e)+'<br><br>可重试，或回到对话里告诉我。</div>';
    return;
  }
  clearInterval(stepTimer);
  btn.disabled = false; btn.classList.remove('loading'); gmsg.textContent='';
  if(!j.ok){
    pv.innerHTML = '<div class="pv-empty" style="color:var(--accent)">生成失败 ✗<br><br>'+
      (j.error||'未知错误')+
      '<br><br><span style="color:var(--mut);font-size:12px">多半是 AI 配置问题（比如 API Key 失效）。回到对话里说一声，我帮你查配置。</span></div>';
    return;
  }
  const p = j.preview;
  let imgs = (p.images||[]).map(src => '<img src="/img?p='+encodeURIComponent(src)+'" onclick="zoom(this.src)">').join('');
  const noteWarn = (p.image_note||'').indexOf('⚠️')===0;
  pv.innerHTML =
    '<div class="pv-meta">选题：'+(p.topic||'')+' ｜ 已存入内容队列 #'+p.content_id+'（不消耗选题库）</div>'+
    '<div class="pv-title">'+ (p.title||'(无标题)') +'</div>'+
    '<div class="pv-body">'+ (p.body||'').replace(/</g,'&lt;') +'</div>'+
    (p.tags&&p.tags.length ? '<div class="pv-tags">'+p.tags.join(' ')+'</div>' : '')+
    (p.image_note ? '<div style="margin-top:14px;font-size:12.5px;color:'+(noteWarn?'var(--accent)':'var(--mut)')+'">'+p.image_note+'</div>' : '')+
    (imgs ? '<div class="pv-imgs">'+imgs+'</div>' : '');
}
function zoom(src){
  document.getElementById('lightbox-img').src = src;
  document.getElementById('lightbox').classList.add('show');
}
function closeZoom(){ document.getElementById('lightbox').classList.remove('show'); }
document.addEventListener('keydown', e => { if(e.key==='Escape') closeZoom(); });
async function done(){
  try { await post('/done', collect()); } catch(e) { /* 即便回报失败也照常收尾，服务端会超时退出 */ }
  document.body.innerHTML = '<div style="padding:80px;text-align:center;color:#8b93a1;font-size:16px">已保存并返回 ✓<br><br>请关闭本页，回到对话继续。</div>';
  setTimeout(()=>{ try{window.close()}catch(e){} }, 600);
}
</script></body></html>"""


# ── 运营看板 HTML（只读，自包含）──────────────────────────────────────────────

_DASH_HTML = r"""<!DOCTYPE html>
<html lang="zh-CN"><head><meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>运营看板 · RedBeacon</title>
<style>
:root{--bg:#0e0d10;--card:#1b1a20;--line:#2a2930;--ink:#f4f2ef;--soft:#b8b4ad;--dim:#76726c;
--beacon:#ff3d54;--ok:#34d399;--warn:#fbbf24;--off:#9ca3af;}
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:-apple-system,"PingFang SC","Microsoft YaHei",sans-serif;background:var(--bg);color:var(--ink);padding:32px}
.wrap{max-width:1180px;margin:0 auto}
.head{display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:16px;margin-bottom:28px}
.title{display:flex;align-items:center;gap:12px;font-size:24px;font-weight:800}
.dot{width:12px;height:12px;border-radius:50%;background:var(--beacon);box-shadow:0 0 0 0 rgba(255,61,84,.6);animation:p 2.4s infinite}
@keyframes p{0%{box-shadow:0 0 0 0 rgba(255,61,84,.55)}70%{box-shadow:0 0 0 12px rgba(255,61,84,0)}100%{box-shadow:0 0 0 0 rgba(255,61,84,0)}}
.btns{display:flex;gap:10px}
.btn{padding:9px 16px;border-radius:999px;font-size:14px;font-weight:600;cursor:pointer;border:1px solid var(--line);background:transparent;color:var(--ink)}
.btn:hover{border-color:var(--beacon)}
.btn.primary{background:linear-gradient(120deg,var(--beacon),#ff7a3d);border-color:transparent;color:#fff}
.stats{display:grid;grid-template-columns:repeat(5,1fr);gap:14px;margin-bottom:26px}
.stat{background:var(--card);border:1px solid var(--line);border-radius:14px;padding:18px}
.stat .n{font-size:30px;font-weight:800;letter-spacing:-1px}
.stat .l{font-size:13px;color:var(--dim);margin-top:4px}
table{width:100%;border-collapse:collapse;background:var(--card);border:1px solid var(--line);border-radius:14px;overflow:hidden}
th,td{text-align:left;padding:14px 16px;font-size:14px;border-bottom:1px solid var(--line)}
th{color:var(--dim);font-weight:600;font-size:12px;letter-spacing:.5px;text-transform:uppercase}
tr:last-child td{border-bottom:none}
tr:hover td{background:rgba(255,255,255,.02)}
.name{font-weight:700}
.id{color:var(--dim);font-size:12px;font-family:monospace;margin-right:8px}
.niche{color:var(--soft)}
.pill{display:inline-flex;align-items:center;gap:5px;padding:3px 10px;border-radius:999px;font-size:12px;font-weight:600}
.pill::before{content:"";width:6px;height:6px;border-radius:50%;background:currentColor}
.on{color:var(--ok);background:rgba(52,211,153,.12)}
.off{color:var(--off);background:rgba(156,163,175,.12)}
.down{color:var(--beacon);background:rgba(255,61,84,.12)}
.tag{display:inline-block;padding:2px 8px;border-radius:6px;font-size:12px}
.tag.ok{color:var(--ok);background:rgba(52,211,153,.1)}
.tag.no{color:var(--dim);background:rgba(118,114,108,.12)}
.num{font-variant-numeric:tabular-nums;font-weight:700}
.low{color:var(--warn)}
.muted{color:var(--dim)}
.foot{margin-top:18px;color:var(--dim);font-size:13px;text-align:center}
@media(max-width:820px){.stats{grid-template-columns:repeat(2,1fr)}td:nth-child(6),th:nth-child(6){display:none}}
</style></head>
<body><div class="wrap">
  <div class="head">
    <div class="title"><span class="dot"></span> 运营看板</div>
    <div class="btns">
      <button class="btn" onclick="refresh()">刷新</button>
      <button class="btn primary" onclick="done()">关闭看板</button>
    </div>
  </div>
  <div class="stats" id="stats"></div>
  <table><thead><tr>
    <th>账号</th><th>定位</th><th>登录</th><th>审核表</th><th>待审 / 已发 / 失败</th><th>可用选题</th>
  </tr></thead><tbody id="rows"></tbody></table>
  <div class="foot" id="foot"></div>
</div>
<script>
let DATA = __DATA__;
function esc(s){return (s==null?'':String(s)).replace(/[&<>]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;'}[c]));}
function render(){
  const s = DATA.summary;
  document.getElementById('stats').innerHTML = [
    ['账号数', s.account_count + ' / ' + s.max_accounts],
    ['在线', s.online_count],
    ['待审核', s.pending_total],
    ['已发布', s.published_total],
    ['选题告急', s.low_topic_count],
  ].map(([l,n],i)=>`<div class="stat"><div class="n${i===4&&s.low_topic_count>0?' low':''}">${esc(n)}</div><div class="l">${esc(l)}</div></div>`).join('');

  document.getElementById('rows').innerHTML = DATA.accounts.map(a=>{
    const onCls = a.online==='在线'?'on':(a.online==='已掉线'?'down':'off');
    const fei = a.feishu_ok?'<span class="tag ok">已连</span>':'<span class="tag no">未连</span>';
    const topics = a.unused_topics<5
      ? `<span class="num low">${a.unused_topics}</span> <span class="muted">条 · 该补题</span>`
      : `<span class="num">${a.unused_topics}</span> <span class="muted">条</span>`;
    const niche = a.niche? esc(a.niche) : '<span class="muted">未设定位</span>';
    return `<tr>
      <td class="name"><span class="id">#${a.id}</span>${esc(a.name)}</td>
      <td class="niche">${niche}</td>
      <td><span class="pill ${onCls}">${esc(a.online)}</span></td>
      <td>${fei}${a.proxy_on?' <span class="tag ok">代理</span>':''}</td>
      <td><span class="num">${a.pending}</span> / <span class="num">${a.published}</span> / <span class="num${a.failed>0?' low':''}">${a.failed}</span></td>
      <td>${topics}</td>
    </tr>`;
  }).join('');

  const low = DATA.accounts.filter(a=>a.topics_low).map(a=>a.name);
  document.getElementById('foot').textContent = low.length
    ? '⚠ 选题快用完的账号：' + low.join('、') + ' —— 回对话让我按定位补题'
    : '全部账号选题充足 · 数据只读，改动去对应 skill';
}
async function refresh(){
  try{ const r=await fetch('/data'); DATA=await r.json(); render(); }catch(e){}
}
async function done(){
  try{ await fetch('/done',{method:'POST'}); }catch(e){}
  document.body.innerHTML='<div style="padding:90px;text-align:center;color:#8b93a1;font-size:16px">看板已关闭 ✓<br><br>请关闭本页，回到对话继续。</div>';
  setTimeout(()=>{try{window.close()}catch(e){}},600);
}
render();
</script></body></html>"""
