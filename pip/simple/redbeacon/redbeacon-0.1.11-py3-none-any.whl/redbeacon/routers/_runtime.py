"""Router 共享运行时：stdout/stderr 输出契约 + 账号读写助手。

约定（P3 错误风格）：
  - 成功：sys.exit(0) + stdout 一行 JSON
  - 失败：sys.exit(非0) + stderr {"error": str}
  - 流式进度：stderr 多行 JSON（cli.py 用，router 内一般不用）
"""
from __future__ import annotations

import json
import os
import sys
from datetime import datetime, timezone
from pathlib import Path

from redbeacon import database
from redbeacon.utils.logger import get_logger
from redbeacon.utils.paths import default_data_dir, default_log_dir
from redbeacon.services import xhs

log = get_logger("router")

DATA_DIR = str(os.environ.get("REDBEACON_DATA_DIR", default_data_dir()))
LOG_DIR  = str(os.environ.get("REDBEACON_LOG_DIR",  default_log_dir()))


def out(data) -> None:
    """成功响应：JSON → stdout，exit 0。

    TTY 输出可读 JSON（indent=2, 中文不转义）；管道/重定向输出紧凑单行（机器友好）。
    强制紧凑：环境变量 REDBEACON_OUT=compact。
    强制可读：环境变量 REDBEACON_OUT=pretty。
    """
    force = os.environ.get("REDBEACON_OUT", "")
    pretty = (force == "pretty") or (force != "compact" and sys.stdout.isatty())
    if pretty:
        print(json.dumps(data, ensure_ascii=False, default=str, indent=2))
    else:
        print(json.dumps(data, ensure_ascii=False, default=str))
    sys.exit(0)


def err(msg: str, code: int = 1, next: str = "", kind: str = ""):
    """失败响应：{"error": msg, "next"?: cmd, "code"?: kind} → stderr，exit code。

    next: 建议的修复 cli 命令，skill 端可据此自愈或提示。
    kind: 机器可读错误码（如 "ACCOUNT_LIMIT"），skill 端据此分支处理。
    """
    body: dict = {"error": msg}
    if next:
        body["next"] = next
    if kind:
        body["code"] = kind
    print(json.dumps(body, ensure_ascii=False), file=sys.stderr)
    sys.exit(code)


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def require_account(account_id: int) -> None:
    with database.cursor() as c:
        row = c.execute("SELECT id FROM account WHERE id=?", (account_id,)).fetchone()
    if not row:
        err(f"账号 {account_id} 不存在")


def account_row(account_id: int) -> dict:
    with database.cursor() as c:
        row = c.execute("SELECT * FROM account WHERE id=?", (account_id,)).fetchone()
    if not row:
        err(f"账号 {account_id} 不存在")
    d = dict(row)
    d["session_running"] = xhs.session.is_running(account_id)
    return d


def update_account(account_id: int, **kwargs) -> None:
    if not kwargs:
        return
    sets = ", ".join(f"{k}=?" for k in kwargs)
    vals = list(kwargs.values()) + [now_iso(), account_id]
    with database.cursor(commit=True) as c:
        c.execute(f"UPDATE account SET {sets}, updated_at=? WHERE id=?", vals)
