"""setup: 安装/校验浏览器内核（playwright chromium）。

首装最重、最易失败的一步：下载 chromium 内核（cloakbrowser/发布自动化都依赖它）。
install.sh 会调用它；用户也可在内核缺失/损坏时手动重跑。

输出契约：进度走 stderr（让用户看到下载过程），stdout 只放最终 JSON 结果。
"""
from __future__ import annotations

import os
import subprocess
import sys

from redbeacon.utils.logger import get_logger
from ._runtime import out, err

log = get_logger("router.setup")


def dispatch(_args) -> None:
    try:
        out(_run_setup())
    except Exception as e:
        log.error(f"setup 失败：{e}", exc_info=True)
        err(f"环境初始化失败：{e}", next="网络不稳可重跑 redbeacon setup")


def _run_setup() -> dict:
    # 1) 下载 chromium 内核。子进程输出全部导到 stderr，保持本命令 stdout 为纯 JSON。
    log.info("开始下载浏览器内核（playwright chromium）…")
    try:
        proc = subprocess.run(
            [sys.executable, "-m", "playwright", "install", "chromium"],
            stdout=sys.stderr, stderr=sys.stderr, timeout=900,
        )
        installed = proc.returncode == 0
    except Exception as e:
        log.error(f"chromium 下载失败：{e}")
        installed = False

    # 2) 校验可执行文件就位（cloakbrowser 走 playwright 的 chromium）
    exe, exe_ok = "", False
    try:
        from playwright.sync_api import sync_playwright
        with sync_playwright() as p:
            exe = p.chromium.executable_path
        exe_ok = bool(exe) and os.path.exists(exe)
    except Exception as e:
        log.warning(f"chromium 可执行校验失败：{e}")

    ok = installed and exe_ok
    return {
        "ok": ok,
        "chromium_installed": installed,
        "chromium_executable": exe,
        "chromium_executable_exists": exe_ok,
        "next": "" if ok else "未装全，网络不稳可多试几次：redbeacon setup",
    }
