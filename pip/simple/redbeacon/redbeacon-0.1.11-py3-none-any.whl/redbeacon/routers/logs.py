"""logs: 读最近 N 行 redbeacon.log"""
from __future__ import annotations

from pathlib import Path

from ._runtime import out, err, LOG_DIR


def dispatch(args) -> None:
    log_file = Path(LOG_DIR) / "redbeacon.log"
    if not log_file.exists():
        out({"lines": []})
    try:
        with open(log_file, "r", encoding="utf-8", errors="replace") as f:
            lines = f.readlines()
        out({"lines": [l.rstrip("\n") for l in lines[-args.tail:]]})
    except Exception as e:
        err(f"读取日志失败：{e}")
