"""backup export / import — 把账号/策略/选题/内容/配置导出为可移植 JSON，换机或重装时恢复。

注意：
  - 加密字段（API Key / App Secret / 解锁码）绑当前机器，**不导出明文**，换机后需重新填。
  - 图片是磁盘文件，导出只含路径不含像素；同机恢复路径仍有效，跨机需另行拷贝 images/。
  - 登录 cookie 是文件且与设备绑定，不在备份内——换机后重新扫码登录即可。
"""
from __future__ import annotations

import json
from datetime import datetime
from pathlib import Path

from redbeacon import database
from redbeacon.config_keys import ENCRYPTED_KEY_NAMES
from ._runtime import out, err

# 导入顺序 = 外键依赖顺序（account 先于引用它的表）
_EXPORT_TABLES = [
    "settings", "account", "strategy", "prompt", "content_type",
    "topic", "image_strategy", "image_template", "content_queue", "publish_log",
]
_SCHEMA_VERSION = 1


def dispatch(args) -> None:
    if args.sub == "export":   _export(args)
    elif args.sub == "import": _import(args)
    else:                      err(f"未知 backup 子命令：{args.sub}")


def _export(args) -> None:
    data: dict = {"schema": _SCHEMA_VERSION, "exported_at": datetime.now().isoformat(), "tables": {}}
    skipped_secrets: list[str] = []
    with database.cursor() as c:
        for t in _EXPORT_TABLES:
            rows = [dict(r) for r in c.execute(f"SELECT * FROM {t}").fetchall()]
            if t == "settings":
                kept = []
                for r in rows:
                    if r["key"] in ENCRYPTED_KEY_NAMES:
                        skipped_secrets.append(r["key"])   # 密文换机无效，不导出
                        continue
                    kept.append(r)
                rows = kept
            data["tables"][t] = rows

    out_path = getattr(args, "out", None) or \
        f"redbeacon-backup-{datetime.now().strftime('%Y%m%d-%H%M%S')}.json"
    Path(out_path).write_text(json.dumps(data, ensure_ascii=False, indent=2, default=str),
                              encoding="utf-8")
    out({
        "ok": True,
        "path": str(Path(out_path).resolve()),
        "counts": {t: len(data["tables"][t]) for t in _EXPORT_TABLES},
        "skipped_secrets": sorted(set(skipped_secrets)),
        "note": "密文密钥未导出，换机后需重新填 API Key / App Secret / 解锁码",
    })


def _import(args) -> None:
    p = Path(args.file)
    if not p.exists():
        err(f"备份文件不存在：{args.file}")
    try:
        data = json.loads(p.read_text(encoding="utf-8"))
    except Exception as e:
        err(f"备份文件解析失败：{e}")
    tables = data.get("tables", {})
    if not tables:
        err("备份文件里没有 tables 数据，可能不是 RedBeacon 备份文件")

    with database.cursor() as c:
        existing = c.execute("SELECT COUNT(*) FROM account").fetchone()[0]
    if existing and not getattr(args, "force", False):
        err(f"当前库已有 {existing} 个账号；导入会清空并覆盖工作数据。确认请加 --force（建议先 export 当前数据备份）",
            next=f"redbeacon backup import --file {args.file} --force")

    counts: dict[str, int] = {}
    with database.cursor(commit=True) as c:
        c.execute("PRAGMA foreign_keys=OFF")
        for t in _EXPORT_TABLES:
            rows = tables.get(t, [])
            if t == "settings":
                # 配置用 upsert：不删本机已填的密钥，只补/盖非密文项
                for r in rows:
                    cols = list(r.keys())
                    placeholders = ",".join("?" for _ in cols)
                    c.execute(
                        f"INSERT INTO settings ({','.join(cols)}) VALUES ({placeholders}) "
                        "ON CONFLICT(key) DO UPDATE SET "
                        "value=excluded.value, is_encrypted=excluded.is_encrypted, updated_at=excluded.updated_at",
                        [r[k] for k in cols],
                    )
                counts[t] = len(rows)
                continue
            c.execute(f"DELETE FROM {t}")
            for r in rows:
                cols = list(r.keys())
                placeholders = ",".join("?" for _ in cols)
                c.execute(f"INSERT INTO {t} ({','.join(cols)}) VALUES ({placeholders})",
                          [r[k] for k in cols])
            counts[t] = len(rows)
    out({"ok": True, "imported": counts,
         "note": "工作数据已恢复；如缺密钥请 redbeacon config 重新填，账号需重新扫码登录"})
