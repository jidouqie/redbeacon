"""
发图文 / 发视频 — 1:1 复刻 xiaohongshu-mcp/xiaohongshu/publish.go + publish_video.go。
DOM 选择器与等待策略一致，不做"优化"以减少出错风险。
"""
from __future__ import annotations

import os
import random
import time
from datetime import datetime
from pathlib import Path
from typing import Optional

from redbeacon.utils.logger import get_logger
from . import session as _session

logger = get_logger("xhs.publish")

URL_PUBLIC = "https://creator.xiaohongshu.com/publish/publish?source=official"

VISIBILITY_DEFAULT = "公开可见"
VISIBILITY_SUPPORTED = {"公开可见", "仅自己可见", "仅互关好友可见"}


# ──────────────────────────────────────────────────────────────────────────────
# 入口
# ──────────────────────────────────────────────────────────────────────────────

def publish_image(
    account_id: int,
    *,
    title: str,
    content: str,
    images: list[str],
    tags: Optional[list[str]] = None,
    schedule_time: Optional[datetime] = None,
    is_original: bool = False,
    is_ai_generated: bool = False,
    visibility: str = VISIBILITY_DEFAULT,
    products: Optional[list[str]] = None,
) -> dict:
    """
    发图文笔记。返回 {"success": True, "post_id": ""}。
    异常时抛出 RuntimeError(msg)。
    """
    if not images:
        raise RuntimeError("图片不能为空")

    tags = (tags or [])[:10]
    products = products or []
    visibility = visibility or VISIBILITY_DEFAULT

    sess = _session.get(account_id)
    if sess is None:
        raise RuntimeError(f"账号 {account_id} 会话未启动")

    def _do(ctx) -> dict:
        page = ctx.pages[0] if ctx.pages else ctx.new_page()
        page.set_default_timeout(60_000)

        _open_publish_page(page, tab="上传图文")
        _upload_images(page, images)
        _submit_publish(
            page,
            title=title,
            content=content,
            tags=tags,
            schedule_time=schedule_time,
            is_original=is_original,
            is_ai_generated=is_ai_generated,
            visibility=visibility,
            products=products,
            video=False,
        )
        return {"success": True, "post_id": ""}

    return sess.exec(_do, timeout=600)


def publish_video(
    account_id: int,
    *,
    title: str,
    content: str,
    video: str,
    tags: Optional[list[str]] = None,
    schedule_time: Optional[datetime] = None,
    visibility: str = VISIBILITY_DEFAULT,
    products: Optional[list[str]] = None,
) -> dict:
    if not video:
        raise RuntimeError("视频不能为空")

    tags = (tags or [])[:10]
    products = products or []
    visibility = visibility or VISIBILITY_DEFAULT

    sess = _session.get(account_id)
    if sess is None:
        raise RuntimeError(f"账号 {account_id} 会话未启动")

    def _do(ctx) -> dict:
        page = ctx.pages[0] if ctx.pages else ctx.new_page()
        page.set_default_timeout(60_000)

        _open_publish_page(page, tab="上传视频")
        _upload_video(page, video)
        _submit_publish(
            page,
            title=title,
            content=content,
            tags=tags,
            schedule_time=schedule_time,
            is_original=False,
            is_ai_generated=False,
            visibility=visibility,
            products=products,
            video=True,
        )
        return {"success": True, "post_id": ""}

    return sess.exec(_do, timeout=900)


# ──────────────────────────────────────────────────────────────────────────────
# 通用步骤
# ──────────────────────────────────────────────────────────────────────────────

def _open_publish_page(page, tab: str) -> None:
    """打开发布页并切换到对应 tab。复刻 NewPublishImageAction/NewPublishVideoAction。"""
    page.goto(URL_PUBLIC, wait_until="load", timeout=300_000)
    page.wait_for_timeout(2_000)
    try:
        page.wait_for_load_state("domcontentloaded", timeout=10_000)
    except Exception:
        pass
    page.wait_for_timeout(1_000)
    _must_click_publish_tab(page, tab)
    page.wait_for_timeout(1_000)


def _must_click_publish_tab(page, tabname: str) -> None:
    """点击「上传图文 / 上传视频」TAB，必要时移除遮挡。"""
    page.wait_for_selector("div.upload-content", state="visible", timeout=30_000)

    deadline = time.time() + 15
    while time.time() < deadline:
        tab, blocked = _find_tab(page, tabname)
        if tab is None:
            page.wait_for_timeout(200)
            continue
        if blocked:
            logger.info("[publish] tab 被遮挡，尝试 JS click 并清理遮挡层")
            # 先尝试 JS click 绕过 overlay
            try:
                tab.evaluate("el => el.click()")
                logger.info("[publish] tab JS click 成功")
                return
            except Exception:
                pass
            _remove_pop_cover(page)
            page.wait_for_timeout(200)
            continue
        try:
            tab.click()
            return
        except Exception as e:
            logger.warning(f"[publish] 点击 TAB 失败：{e}")
            page.wait_for_timeout(200)

    # 截图留存方便调试
    try:
        ss_path = f"/tmp/xhs_publish_tab_fail_{int(time.time())}.png"
        page.screenshot(path=ss_path)
        logger.info(f"[publish] 截图已保存：{ss_path}")
    except Exception:
        pass
    raise RuntimeError(f"没有找到发布 TAB - {tabname}")


def _find_tab(page, tabname: str):
    """返回 (locator|None, blocked)。"""
    try:
        elems = page.locator("div.creator-tab")
        n = elems.count()
    except Exception:
        return None, False
    for i in range(n):
        elem = elems.nth(i)
        try:
            if not elem.is_visible():
                continue
            text = (elem.inner_text() or "").strip()
        except Exception:
            continue
        if text != tabname:
            continue
        blocked = False
        try:
            blocked = bool(elem.evaluate("""el => {
                const rect = el.getBoundingClientRect();
                if (rect.width === 0 || rect.height === 0) return true;
                const x = rect.left + rect.width / 2;
                const y = rect.top + rect.height / 2;
                const target = document.elementFromPoint(x, y);
                return !(target === el || el.contains(target));
            }"""))
        except Exception:
            pass
        return elem, blocked
    return None, False


def _remove_pop_cover(page) -> None:
    """移除可能的弹窗封面 + 兜底点空位。"""
    try:
        page.evaluate("""() => {
            // 移除各种可能的遮挡层（弹窗、引导、通知等）
            const selectors = [
                'div.d-popover',
                '.el-dialog__wrapper',
                '.el-overlay',
                '.mfe-creator-modal',
                '[class*="modal"]',
                '[class*="dialog"]',
                '[class*="overlay"]',
                '[class*="mask"]',
                '[class*="popup"]',
                '[class*="guide"]',
                '[class*="toast"]',
            ];
            selectors.forEach(sel => {
                document.querySelectorAll(sel).forEach(e => {
                    const style = window.getComputedStyle(e);
                    if (style.position === 'fixed' || style.position === 'absolute') {
                        e.remove();
                    }
                });
            });
        }""")
    except Exception:
        pass
    try:
        x = 380 + random.randint(0, 99)
        y = 20 + random.randint(0, 59)
        page.mouse.move(x, y)
        page.mouse.click(x, y)
    except Exception:
        pass


# ──────────────────────────────────────────────────────────────────────────────
# 上传图片 / 视频
# ──────────────────────────────────────────────────────────────────────────────

def _upload_images(page, image_paths: list[str]) -> None:
    valid = [p for p in image_paths if Path(p).exists()]
    if not valid:
        raise RuntimeError("所有图片文件都不存在")

    for i, path in enumerate(valid):
        selector = ".upload-input" if i == 0 else 'input[type="file"]'
        try:
            page.locator(selector).first.set_input_files(path)
        except Exception as e:
            raise RuntimeError(f"上传第 {i+1} 张图片失败: {e}") from e
        logger.info(f"[publish] 已提交第 {i+1} 张图片：{path}")
        _wait_upload_complete(page, i + 1)
        page.wait_for_timeout(1_000)


def _wait_upload_complete(page, expected_count: int, max_wait_sec: int = 60) -> None:
    deadline = time.time() + max_wait_sec
    last_logged = expected_count - 1
    while time.time() < deadline:
        try:
            n = page.locator(".img-preview-area .pr").count()
        except Exception:
            n = 0
        if n != last_logged:
            logger.info(f"[publish] 上传进度 {n}/{expected_count}")
            last_logged = n
        if n >= expected_count:
            return
        page.wait_for_timeout(500)
    raise RuntimeError(f"第 {expected_count} 张图片上传超时（60s）")


def _upload_video(page, video_path: str) -> None:
    if not Path(video_path).exists():
        raise RuntimeError(f"视频文件不存在：{video_path}")
    # 先用 .upload-input，找不到退化到 input[type=file]
    try:
        page.locator(".upload-input").first.set_input_files(video_path, timeout=10_000)
    except Exception:
        try:
            page.locator('input[type="file"]').first.set_input_files(video_path, timeout=10_000)
        except Exception as e:
            raise RuntimeError(f"未找到视频上传输入框：{e}") from e
    _wait_publish_button_clickable(page, max_wait_sec=600)
    logger.info("[publish] 视频上传/处理完成")


def _wait_publish_button_clickable(page, max_wait_sec: int = 30):
    """等发布按钮变可点击（对齐 xiaohongshu-mcp dee6c25 fix）。

    优先 <xhs-publish-btn> Web Component（host 即按钮）：
      - 用 host 上的属性 is-publish/submit-disabled 判定，不进 shadow root
      - 点击：移到 host 包围盒右侧 65% 位置 + 鼠标点击（host 包含暂存+发布两块）
    回退 .publish-page-publish-btn button.bg-red（旧版）。

    返回 None — 调用方据此跳过 btn.click()（点击已在内部完成）。
    """
    deadline = time.time() + max_wait_sec
    last_reason = ""
    last_ss = 0.0
    while time.time() < deadline:
        # 1. 新版 <xhs-publish-btn>
        try:
            widgets = page.locator("xhs-publish-btn")
            wcount = widgets.count()
        except Exception:
            wcount = 0
        for i in range(wcount):
            w = widgets.nth(i)
            try:
                if not w.is_visible():
                    continue
                is_publish = w.get_attribute("is-publish")
                if is_publish == "false":
                    continue
                if w.get_attribute("submit-disabled") == "true":
                    last_reason = "新版按钮 submit-disabled=true"
                    continue
                _click_publish_widget(page, w)
                logger.info("[publish] 新版 xhs-publish-btn 点击完成")
                return None
            except Exception as e:
                logger.debug(f"[publish] widget {i} 检查失败：{e}")
                continue

        # 2. 旧版 button.bg-red 兜底
        try:
            old_btns = page.locator(".publish-page-publish-btn button.bg-red")
            ocount = old_btns.count()
        except Exception:
            ocount = 0
        for i in range(ocount):
            b = old_btns.nth(i)
            try:
                if not b.is_visible():
                    continue
                if b.get_attribute("disabled") is not None:
                    last_reason = "旧版按钮 disabled"
                    continue
                if b.get_attribute("aria-disabled") == "true":
                    last_reason = "旧版按钮 aria-disabled=true"
                    continue
                cls = b.get_attribute("class") or ""
                if " disabled " in f" {cls} ":
                    last_reason = "旧版按钮 class 含 disabled"
                    continue
                b.scroll_into_view_if_needed()
                page.wait_for_timeout(200)
                b.click()
                logger.info("[publish] 旧版 .bg-red 点击完成")
                return None
            except Exception as e:
                logger.debug(f"[publish] old btn {i} 检查失败：{e}")
                continue

        now = time.time()
        if now - last_ss >= 5:
            try:
                ss_path = f"/tmp/xhs_publish_wait_{int(now)}.png"
                page.screenshot(path=ss_path)
                logger.info(f"[publish] 等待按钮截图：{ss_path}")
                last_ss = now
            except Exception:
                pass
        page.wait_for_timeout(1_000)

    try:
        ss_path = f"/tmp/xhs_publish_btn_fail_{int(time.time())}.png"
        page.screenshot(path=ss_path)
        logger.info(f"[publish] 超时截图：{ss_path}")
    except Exception:
        pass
    suffix = f"：{last_reason}" if last_reason else ""
    raise RuntimeError(f"等待发布按钮可点击超时{suffix}")


def _click_publish_widget(page, widget) -> None:
    """点击 <xhs-publish-btn> host 右侧 65% 位置（避开"暂存离开"那一半）。"""
    widget.scroll_into_view_if_needed()
    page.wait_for_timeout(200)
    box = widget.bounding_box()
    if not box:
        raise RuntimeError("新版发布按钮位置获取失败")
    x = box["x"] + box["width"] * 0.65
    y = box["y"] + box["height"] / 2
    page.mouse.move(x, y)
    page.mouse.click(x, y)


# ──────────────────────────────────────────────────────────────────────────────
# 提交：标题 / 正文 / 标签 / 选项 / 发布
# ──────────────────────────────────────────────────────────────────────────────

def _submit_publish(
    page,
    *,
    title: str,
    content: str,
    tags: list[str],
    schedule_time: Optional[datetime],
    is_original: bool,
    is_ai_generated: bool,
    visibility: str,
    products: list[str],
    video: bool,
) -> None:
    # 1. 标题
    title_input = page.locator("div.d-input input").first
    title_input.fill(title)
    page.wait_for_timeout(500)
    if not video:
        _check_title_max_length(page)
    page.wait_for_timeout(1_000)

    # 2. 正文
    content_elem = _get_content_element(page)
    content_elem.fill(content)
    # 回点标题输入框（增强后续操作稳定性，复刻 waitAndClickTitleInput）
    page.wait_for_timeout(1_000)
    title_input.click()

    # 3. 标签
    _input_tags(page, content_elem, tags)
    page.wait_for_timeout(1_000)
    if not video:
        _check_content_max_length(page)

    # 4. 定时发布
    if schedule_time is not None:
        _set_schedule_publish(page, schedule_time)

    # 5. 可见范围
    _set_visibility(page, visibility)

    # 6. 原创声明 / AI 声明（仅图文）
    if not video and is_original:
        try:
            _set_original(page)
        except Exception as e:
            logger.warning(f"[publish] 设置原创声明失败，继续发布：{e}")
    if not video and is_ai_generated:
        try:
            _set_ai_declaration(page)
        except Exception as e:
            logger.warning(f"[publish] 设置 AI 声明失败，继续发布：{e}")

    # 7. 商品
    if products:
        _bind_products(page, products)

    # 8. 点击发布（图文和视频都等按钮就绪再点）
    btn = _wait_publish_button_clickable(page)
    if btn is not None:
        btn.click()
    # 等待发布结果（页面跳转或成功提示）
    page.wait_for_timeout(5_000)
    try:
        ss_path = f"/tmp/xhs_after_publish_{int(time.time())}.png"
        page.screenshot(path=ss_path)
        logger.info(f"[publish] 发布后截图：{ss_path}")
    except Exception:
        pass


def _check_title_max_length(page) -> None:
    loc = page.locator("div.title-container div.max_suffix")
    if loc.count() == 0:
        return
    text = loc.first.inner_text() or ""
    raise RuntimeError(_format_max_length_error(text))


def _check_content_max_length(page) -> None:
    loc = page.locator("div.edit-container div.length-error")
    if loc.count() == 0:
        return
    text = loc.first.inner_text() or ""
    raise RuntimeError(_format_max_length_error(text))


def _format_max_length_error(elem_text: str) -> str:
    parts = elem_text.split("/")
    if len(parts) != 2:
        return f"长度超过限制: {elem_text}"
    return f"当前输入长度为{parts[0]}，最大长度为{parts[1]}"


def _get_content_element(page):
    """正文输入框：先试 div.ql-editor，否则按 placeholder 找 [role=textbox]。"""
    # 简单 race：先看 ql-editor
    try:
        loc = page.locator("div.ql-editor").first
        loc.wait_for(state="visible", timeout=3_000)
        return loc
    except Exception:
        pass
    # placeholder fallback
    try:
        cand = page.locator('p[data-placeholder*="输入正文描述"]').first
        cand.wait_for(state="attached", timeout=3_000)
        # 向上找最多 5 层 [role=textbox]
        textbox = cand.evaluate_handle("""el => {
            let cur = el;
            for (let i = 0; i < 5 && cur; i++) {
                cur = cur.parentElement;
                if (cur && cur.getAttribute('role') === 'textbox') return cur;
            }
            return null;
        }""")
        if textbox:
            return textbox.as_element()
    except Exception:
        pass
    raise RuntimeError("没有找到内容输入框")


def _input_tags(page, content_elem, tags: list[str]) -> None:
    if not tags:
        return
    page.wait_for_timeout(1_000)
    # 复刻 Go：先按 20 下 ArrowDown 跳到末尾
    for _ in range(20):
        content_elem.press("ArrowDown")
        page.wait_for_timeout(10)
    content_elem.press("Enter")
    content_elem.press("Enter")
    page.wait_for_timeout(1_000)

    for raw in tags:
        tag = raw.lstrip("#")
        if not tag:
            continue
        _input_one_tag(page, content_elem, tag)


def _input_one_tag(page, content_elem, tag: str) -> None:
    content_elem.type("#")
    page.wait_for_timeout(200)
    for ch in tag:
        content_elem.type(ch)
        page.wait_for_timeout(50)
    page.wait_for_timeout(1_000)
    # 找联想下拉
    container = page.locator("#creator-editor-topic-container").first
    if container.count() == 0:
        content_elem.type(" ")
        return
    first_item = container.locator(".item").first
    if first_item.count() == 0:
        content_elem.type(" ")
        return
    try:
        first_item.click()
        page.wait_for_timeout(700)
    except Exception:
        content_elem.type(" ")


# ── 可见范围 ───────────────────────────────────────────────────────────────────

def _set_visibility(page, visibility: str) -> None:
    if not visibility or visibility == VISIBILITY_DEFAULT:
        return
    if visibility not in VISIBILITY_SUPPORTED:
        raise RuntimeError(f"不支持的可见范围: {visibility}")

    dropdown = page.locator("div.permission-card-wrapper div.d-select-content").first
    dropdown.click()
    page.wait_for_timeout(500)

    opts = page.locator("div.d-options-wrapper div.d-grid-item div.custom-option")
    n = opts.count()
    for i in range(n):
        opt = opts.nth(i)
        try:
            text = opt.inner_text() or ""
        except Exception:
            continue
        if visibility in text:
            opt.click()
            page.wait_for_timeout(200)
            return
    raise RuntimeError(f"未找到可见范围选项: {visibility}")


# ── 定时发布 ───────────────────────────────────────────────────────────────────

def _set_schedule_publish(page, t: datetime) -> None:
    """开启小红书「定时发布」并填入时间。

    全程走 JS：① 开关用原生 .click() 绕过 Playwright 的 pointer_events 检查
    （Playwright 的 .click() 会因开关被遮挡而 "covered by <none>" 失败）；
    ② 日期框用原生 value setter + 派发 input/change/blur，React/Vue 才会认值。
    取法对齐上游 XiaohongshuSkills/scripts/cdp_publish.py 的 _set_schedule_post_time。
    """
    dt_str = t.strftime("%Y-%m-%d %H:%M")
    result = page.evaluate(
        """async (postTime) => {
            const sleep = (ms) => new Promise(r => setTimeout(r, ms));
            const visible = (n) => (
                n instanceof HTMLElement && n.offsetParent !== null &&
                n.getBoundingClientRect().width > 0 && n.getBoundingClientRect().height > 0
            );
            const sw = document.querySelector('.post-time-wrapper .d-switch');
            if (!(sw instanceof HTMLElement) || !visible(sw)) return '定时发布开关未找到';
            if (sw.getAttribute('aria-checked') !== 'true') {
                sw.click();
                await sleep(400);
            }
            const el = document.querySelector('.date-picker-container input');
            if (!(el instanceof HTMLInputElement)) return '定时发布日期输入框未找到';
            const setter = Object.getOwnPropertyDescriptor(
                window.HTMLInputElement.prototype, 'value').set;
            el.focus();
            el.select();
            setter.call(el, postTime);
            el.dispatchEvent(new Event('input',  { bubbles: true }));
            el.dispatchEvent(new Event('change', { bubbles: true }));
            el.dispatchEvent(new Event('blur',   { bubbles: true }));
            return 'ok';
        }""",
        dt_str,
    )
    if result != "ok":
        raise RuntimeError(f"设置定时发布失败：{result}")
    page.wait_for_timeout(600)


# ── 原创声明 ───────────────────────────────────────────────────────────────────

def _set_original(page) -> None:
    cards = page.locator("div.custom-switch-card")
    n = cards.count()
    for i in range(n):
        card = cards.nth(i)
        try:
            text = card.inner_text() or ""
        except Exception:
            continue
        if "原创声明" not in text:
            continue
        sw = card.locator("div.d-switch").first
        if sw.count() == 0:
            continue
        checked = sw.evaluate("""el => {
            const inp = el.querySelector('input[type="checkbox"]');
            return inp ? inp.checked : false;
        }""")
        if checked:
            return
        sw.click()
        page.wait_for_timeout(500)
        _confirm_original_declaration(page)
        return
    raise RuntimeError("未找到原创声明选项")


def _confirm_original_declaration(page) -> None:
    page.wait_for_timeout(800)
    try:
        page.evaluate("""() => {
            const footers = document.querySelectorAll('div.footer');
            for (const f of footers) {
                if (!f.textContent.includes('原创声明须知')) continue;
                const cb = f.querySelector('div.d-checkbox input[type="checkbox"]');
                if (cb && !cb.checked) cb.click();
                return 'found';
            }
            return 'not_found';
        }""")
    except Exception:
        pass
    page.wait_for_timeout(500)
    status = page.evaluate("""() => {
        const footers = document.querySelectorAll('div.footer');
        for (const f of footers) {
            if (!f.textContent.includes('声明原创')) continue;
            const btn = f.querySelector('button.custom-button');
            if (!btn) continue;
            if (btn.classList.contains('disabled') || btn.disabled) {
                const cb = f.querySelector('div.d-checkbox input[type="checkbox"]');
                if (cb && !cb.checked) cb.click();
                return 'button_disabled';
            }
            btn.click();
            return 'clicked';
        }
        return 'button_not_found';
    }""")
    if status == "button_not_found":
        raise RuntimeError("未找到声明原创按钮")
    if status == "button_disabled":
        raise RuntimeError("声明原创按钮仍处于禁用状态")
    page.wait_for_timeout(300)


# ── AI 声明 ────────────────────────────────────────────────────────────────────

def _set_ai_declaration(page) -> None:
    already = page.evaluate("""() => {
        const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
        let node;
        while ((node = walker.nextNode())) {
            if (node.textContent.trim() === '笔记含AI合成内容') {
                const p = node.parentElement;
                if (p && !p.closest('[class*="options"], [class*="popover"], [class*="dropdown"]')) return true;
            }
        }
        return false;
    }""")
    if already:
        return

    clicked = page.evaluate("""() => {
        const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
        let node;
        while ((node = walker.nextNode())) {
            const t = node.textContent.trim();
            if (t === '添加内容类型声明' || t === '内容类型声明') {
                let el = node.parentElement;
                for (let i = 0; i < 5; i++) {
                    if (!el) break;
                    el.click();
                    return true;
                }
            }
        }
        return false;
    }""")
    if not clicked:
        raise RuntimeError("未找到内容类型声明下拉框")
    page.wait_for_timeout(800)

    result = page.evaluate("""() => {
        const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
        let node;
        while ((node = walker.nextNode())) {
            if (node.textContent.trim() === '笔记含AI合成内容') {
                let el = node.parentElement;
                for (let i = 0; i < 5; i++) {
                    if (!el) break;
                    const s = window.getComputedStyle(el);
                    if (s.cursor === 'pointer' || el.onclick || el.tagName === 'LI') {
                        el.click();
                        return 'clicked';
                    }
                    el = el.parentElement;
                }
                node.parentElement.click();
                return 'clicked_fallback';
            }
        }
        return 'not_found';
    }""")
    if result == "not_found":
        raise RuntimeError("未找到[笔记含AI合成内容]选项")
    page.wait_for_timeout(300)


# ── 绑定商品 ───────────────────────────────────────────────────────────────────

def _bind_products(page, products: list[str]) -> None:
    _click_add_product_button(page)
    page.wait_for_timeout(1_000)

    modal = _wait_product_modal(page)
    failed: list[str] = []
    for kw in products:
        try:
            _search_and_select_product(page, modal, kw)
        except Exception as e:
            logger.warning(f"[publish] 选商品失败 keyword={kw}: {e}")
            failed.append(kw)
        page.wait_for_timeout(500)

    _click_modal_save_button(modal)
    _wait_modal_close(page)

    if failed:
        raise RuntimeError(f"部分商品未找到: {failed}")


def _click_add_product_button(page) -> None:
    spans = page.locator("span.d-text")
    n = spans.count()
    for i in range(n):
        span = spans.nth(i)
        try:
            text = (span.inner_text() or "").strip()
        except Exception:
            continue
        if text != "添加商品":
            continue
        # 向上找最多 5 层可点击父
        cur = span
        for _ in range(5):
            try:
                parent = cur.locator("xpath=..")
            except Exception:
                break
            try:
                tag = (parent.evaluate("el => el.tagName.toLowerCase()") or "").lower()
            except Exception:
                cur = parent
                continue
            cls = parent.get_attribute("class") or ""
            if tag == "button" or "d-button" in cls:
                parent.click()
                page.wait_for_timeout(300)
                return
            cur = parent
    raise RuntimeError("未找到添加商品按钮，账号可能未开通商品功能")


def _wait_product_modal(page):
    deadline = time.time() + 10
    while time.time() < deadline:
        modal = page.locator(".multi-goods-selector-modal").first
        if modal.count() > 0 and modal.is_visible():
            return modal
        page.wait_for_timeout(100)
    raise RuntimeError("等待商品选择弹窗超时")


def _search_and_select_product(page, modal, keyword: str) -> None:
    search_input = modal.locator('input[placeholder="搜索商品ID 或 商品名称"]').first
    try:
        search_input.fill(keyword)
    except Exception as e:
        raise RuntimeError(f"输入搜索关键词失败: {e}") from e
    page.wait_for_timeout(300)
    page.keyboard.press("Enter")
    page.wait_for_timeout(1_000)

    # 等 loading 消失
    deadline = time.time() + 10
    while time.time() < deadline:
        loading = modal.locator(".goods-list-loading").first
        if loading.count() == 0 or not loading.is_visible():
            break
        page.wait_for_timeout(100)

    # 等商品出现
    while time.time() < deadline:
        if modal.locator(".goods-list-normal .good-card-container").count() > 0:
            break
        page.wait_for_timeout(100)
    page.wait_for_timeout(500)

    cb = modal.locator(".goods-list-normal .good-card-container .d-checkbox").first
    if cb.count() == 0:
        raise RuntimeError("未找到商品选择框")

    already = cb.evaluate("""el => (
        el.querySelector('.d-checkbox-simulator.checked') !== null ||
        el.querySelector('input[type="checkbox"]:checked') !== null
    )""")
    if already:
        return
    cb.click()
    page.wait_for_timeout(800 + random.randint(0, 700))


def _click_modal_save_button(modal) -> None:
    btn = modal.locator(".goods-selected-footer button").first
    if btn.count() > 0:
        try:
            btn.click()
            return
        except Exception:
            pass
    primary = modal.locator(".goods-selected-footer .d-button--primary").first
    if primary.count() > 0:
        try:
            primary.click()
        except Exception:
            pass


def _wait_modal_close(page) -> None:
    deadline = time.time() + 5
    while time.time() < deadline:
        if page.locator(".multi-goods-selector-modal").count() == 0:
            return
        page.wait_for_timeout(200)
    # 关不掉不致命，只警告
    logger.warning("[publish] 商品弹窗 5s 内未关闭，继续")
