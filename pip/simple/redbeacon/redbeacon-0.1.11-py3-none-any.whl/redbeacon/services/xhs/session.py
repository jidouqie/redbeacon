"""
每账号一个浏览器会话：CloakBrowser persistent_context + 专属 worker 线程。

Playwright sync API 有线程亲和性，所有调用必须在创建它的线程里完成。
所以每个 account_id 配一个守护线程，外部通过 exec(fn) 把回调投到该线程执行。
"""
from __future__ import annotations

import os
import queue
import threading
import time
from collections import deque
from concurrent.futures import Future
from pathlib import Path
from typing import Any, Callable, Optional

from redbeacon.utils.logger import get_logger

logger = get_logger("xhs.session")

# 命令队列里的哨兵，表示请求线程退出。
_STOP = object()

# 日志缓冲，复刻旧 mcp_manager.get_logs 行为，供调试页继续使用。
_LOG_MAX = 300
_log_buffers: dict[int, deque] = {}
_log_lock = threading.Lock()


def _log(account_id: int, line: str) -> None:
    with _log_lock:
        buf = _log_buffers.setdefault(account_id, deque(maxlen=_LOG_MAX))
        buf.append(line)


def get_logs(account_id: int, tail: int = 100) -> list[str]:
    with _log_lock:
        buf = _log_buffers.get(account_id, deque())
        lines = list(buf)
    return lines[-tail:] if tail < len(lines) else lines


class Session:
    """
    一个账号对应一个 CloakBrowser persistent_context + 一个 worker 线程。
    所有 Playwright 调用通过 exec(fn) 进入该线程。
    """

    def __init__(
        self,
        account_id: int,
        user_data_dir: str,
        headless: bool = True,
        proxy: Optional[str] = None,
        humanize: bool = True,
    ) -> None:
        self.account_id = account_id
        self.user_data_dir = user_data_dir
        self.headless = headless
        self.proxy = proxy
        self.humanize = humanize

        self._q: queue.Queue = queue.Queue()
        self._ready = threading.Event()
        self._stopped = threading.Event()
        self._init_error: Optional[BaseException] = None
        self._thread = threading.Thread(
            target=self._run,
            name=f"xhs-session-{account_id}",
            daemon=True,
        )
        self._thread.start()

    def wait_ready(self, timeout: float = 60.0) -> None:
        if not self._ready.wait(timeout):
            raise RuntimeError(f"账号 {self.account_id} 浏览器启动超时（{timeout}s）")
        if self._init_error:
            raise self._init_error

    # ── worker 线程主循环 ─────────────────────────────────────────────────────
    def _run(self) -> None:
        from cloakbrowser import launch_persistent_context

        # 准备 profile 目录
        Path(self.user_data_dir).mkdir(parents=True, exist_ok=True)

        ctx = None
        try:
            kwargs: dict[str, Any] = dict(
                headless=self.headless,
                humanize=self.humanize,
            )
            if self.proxy:
                kwargs["proxy"] = self.proxy

            _log(self.account_id, f"[session] launching CloakBrowser headless={self.headless} proxy={'*'*4 if self.proxy else 'none'}")
            ctx = launch_persistent_context(self.user_data_dir, **kwargs)
            # 持久 context 自带一个空白 page；保证至少有一个 page 可用
            if not ctx.pages:
                ctx.new_page()
            _log(self.account_id, "[session] launched")
        except BaseException as e:
            self._init_error = e
            self._ready.set()
            logger.exception(f"[xhs] account {self.account_id} 浏览器启动失败")
            return

        self._ready.set()

        try:
            while True:
                item = self._q.get()
                if item is _STOP:
                    break
                fn, fut = item
                try:
                    result = fn(ctx)
                    fut.set_result(result)
                except BaseException as e:
                    logger.exception(f"[xhs] account {self.account_id} 任务执行失败：{e}")
                    fut.set_exception(e)
        finally:
            try:
                if ctx is not None:
                    ctx.close()
            except Exception as e:
                logger.warning(f"[xhs] account {self.account_id} ctx.close 异常：{e}")
            self._stopped.set()
            _log(self.account_id, "[session] closed")

    # ── 外部 API ─────────────────────────────────────────────────────────────
    def exec(self, fn: Callable[[Any], Any], timeout: float = 300.0) -> Any:
        if self._stopped.is_set():
            raise RuntimeError(f"账号 {self.account_id} 会话已停止")
        self.wait_ready()
        fut: Future = Future()
        self._q.put((fn, fut))
        return fut.result(timeout=timeout)

    def stop(self, timeout: float = 15.0) -> None:
        if self._stopped.is_set():
            return
        self._q.put(_STOP)
        self._thread.join(timeout=timeout)

    def is_alive(self) -> bool:
        return self._thread.is_alive() and not self._stopped.is_set()


# ── 单例管理器 ───────────────────────────────────────────────────────────────
_sessions: dict[int, Session] = {}
_mgr_lock = threading.Lock()


def _profile_dir(account_id: int) -> str:
    from redbeacon import config as cfg
    from redbeacon.config_keys import CK_DATA_DIR
    data_dir = os.environ.get("REDBEACON_DATA_DIR") or cfg.get(CK_DATA_DIR)
    return str(Path(data_dir).resolve() / "cb_profiles" / str(account_id))


def start(
    account_id: int,
    headless: bool = True,
    proxy: Optional[str] = None,
    humanize: bool = True,
) -> Session:
    """
    启动账号会话；若已存在且参数一致直接返回，参数变化则先关后重启。
    """
    with _mgr_lock:
        sess = _sessions.get(account_id)
        if sess and sess.is_alive():
            if (sess.headless == headless and sess.proxy == proxy and sess.humanize == humanize):
                logger.info(f"[xhs] account {account_id} 会话已运行，复用")
                return sess
            logger.info(f"[xhs] account {account_id} 参数变化，重启会话")
            sess.stop()
            _sessions.pop(account_id, None)

        sess = Session(
            account_id=account_id,
            user_data_dir=_profile_dir(account_id),
            headless=headless,
            proxy=proxy,
            humanize=humanize,
        )
        _sessions[account_id] = sess

    try:
        sess.wait_ready()
    except BaseException:
        with _mgr_lock:
            _sessions.pop(account_id, None)
        raise
    return sess


def stop(account_id: int) -> None:
    with _mgr_lock:
        sess = _sessions.pop(account_id, None)
    if sess:
        sess.stop()


def stop_all() -> None:
    with _mgr_lock:
        ids = list(_sessions.keys())
    for aid in ids:
        stop(aid)


def is_running(account_id: int) -> bool:
    sess = _sessions.get(account_id)
    return sess is not None and sess.is_alive()


def get(account_id: int) -> Optional[Session]:
    sess = _sessions.get(account_id)
    if sess and sess.is_alive():
        return sess
    return None


def exec_in(account_id: int, fn: Callable[[Any], Any], timeout: float = 300.0) -> Any:
    sess = get(account_id)
    if sess is None:
        raise RuntimeError(f"账号 {account_id} 会话未启动")
    return sess.exec(fn, timeout=timeout)
