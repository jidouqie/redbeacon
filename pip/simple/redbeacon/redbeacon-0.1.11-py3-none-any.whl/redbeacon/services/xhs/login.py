"""
扫码登录 / 状态查询 / 退出登录。
DOM 选择器直接复刻自 xiaohongshu-mcp/xiaohongshu/login.go。
"""
from __future__ import annotations

import base64
import json
import os
import time
from pathlib import Path
from typing import Optional

from redbeacon.utils.logger import get_logger
from . import session as _session

logger = get_logger("xhs.login")

URL_EXPLORE = "https://www.xiaohongshu.com/explore"

# 登录成功后页面会出现的标志元素（来自 login.go）
SEL_LOGGED_IN = ".main-container .user .link-wrapper .channel"
SEL_QRCODE_IMG = ".login-container .qrcode-img"


def _ensure_session(account_id: int, headless: bool, proxy: Optional[str] = None) -> _session.Session:
    sess = _session.get(account_id)
    if sess is None or sess.headless != headless:
        if sess is not None:
            _session.stop(account_id)
        sess = _session.start(account_id, headless=headless, proxy=proxy)
    return sess


def check_login_status(account_id: int, proxy: Optional[str] = None) -> dict:
    """
    访问 explore 页判断是否已登录。
    返回 {"is_logged_in": bool, "username": str}.
    """
    sess = _ensure_session(account_id, headless=True, proxy=proxy)

    def _do(ctx) -> dict:
        page = ctx.pages[0] if ctx.pages else ctx.new_page()
        try:
            page.goto(URL_EXPLORE, wait_until="load", timeout=60_000)
        except Exception as e:
            logger.warning(f"[login] goto explore 异常：{e}")
        page.wait_for_timeout(1500)
        try:
            el = page.locator(SEL_LOGGED_IN).first
            if el.count() > 0:
                username = ""
                try:
                    username = (el.inner_text(timeout=2_000) or "").strip()
                except Exception:
                    pass
                return {"is_logged_in": True, "username": username}
        except Exception as e:
            logger.debug(f"[login] 检测登录态异常：{e}")
        return {"is_logged_in": False, "username": ""}

    return sess.exec(_do, timeout=90)


def fetch_qrcode(account_id: int, proxy: Optional[str] = None) -> dict:
    """
    弹出二维码。返回 {"img": "data:image/png;base64,...", "timeout": 180, "already_logged_in": bool}。
    实现：headed CloakBrowser 打开 explore，截取 .qrcode-img 的 src（已经是 base64）。
    """
    # 登录需要 headed=False（小红书有时会拒绝 headless），但 RedBeacon 现网默认 headless=True。
    # 这里强制 headed 模式以保证扫码成功率。
    sess = _ensure_session(account_id, headless=False, proxy=proxy)

    def _do(ctx) -> dict:
        page = ctx.pages[0] if ctx.pages else ctx.new_page()
        try:
            page.goto(URL_EXPLORE, wait_until="load", timeout=60_000)
        except Exception as e:
            logger.warning(f"[login] goto explore 异常：{e}")
        page.wait_for_timeout(2_000)

        # 已登录直接返回
        try:
            if page.locator(SEL_LOGGED_IN).count() > 0:
                return {"img": "", "timeout": 0, "already_logged_in": True}
        except Exception:
            pass

        # 等二维码出现
        try:
            page.wait_for_selector(SEL_QRCODE_IMG, timeout=15_000)
        except Exception as e:
            return {"img": "", "timeout": 0, "already_logged_in": False, "error": f"未找到二维码：{e}"}

        src = page.locator(SEL_QRCODE_IMG).first.get_attribute("src") or ""
        if not src:
            return {"img": "", "timeout": 0, "already_logged_in": False, "error": "二维码 src 为空"}
        return {"img": src, "timeout": 180, "already_logged_in": False}

    return sess.exec(_do, timeout=60)


def wait_for_login(account_id: int, max_wait_sec: int = 180) -> bool:
    """
    阻塞等扫码成功。轮询 SEL_LOGGED_IN 出现。
    成功后立即把 cookies 落盘（保留旧 cookie 文件路径兼容性）。
    """
    sess = _session.get(account_id)
    if sess is None:
        raise RuntimeError(f"账号 {account_id} 会话未启动，无法等待登录")

    def _do(ctx) -> bool:
        page = ctx.pages[0] if ctx.pages else ctx.new_page()
        deadline = time.time() + max_wait_sec
        while time.time() < deadline:
            try:
                if page.locator(SEL_LOGGED_IN).count() > 0:
                    return True
            except Exception:
                pass
            page.wait_for_timeout(800)
        return False

    ok = sess.exec(_do, timeout=max_wait_sec + 30)
    if ok:
        _save_cookies(account_id)
    return ok


def _cookies_path(account_id: int) -> str:
    from redbeacon import config as cfg
    from redbeacon.config_keys import CK_DATA_DIR
    data_dir = os.environ.get("REDBEACON_DATA_DIR") or cfg.get(CK_DATA_DIR)
    return str(Path(data_dir).resolve() / f"cookies_{account_id}.json")


def _save_cookies(account_id: int) -> None:
    """
    把当前 context 的 cookies 序列化到 cookies_{id}.json。
    persistent_context 自己已经持久化在 user_data_dir 里了，这里只是
    保留旧 cookie 文件接口给前端/调试用，并作为「已登录」的快速判定标志。
    """
    sess = _session.get(account_id)
    if sess is None:
        return
    path = _cookies_path(account_id)

    def _do(ctx) -> None:
        cookies = ctx.cookies()
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        Path(path).write_text(json.dumps(cookies, ensure_ascii=False, indent=2), encoding="utf-8")

    try:
        sess.exec(_do, timeout=30)
        logger.info(f"[login] account {account_id} cookies 已保存到 {path}")
    except Exception as e:
        logger.warning(f"[login] account {account_id} 保存 cookies 失败：{e}")


def delete_cookies(account_id: int) -> None:
    """
    退出登录：清空 context cookies + 删除 cookies_{id}.json。
    会话保持运行，方便用户立即重新扫码。
    """
    sess = _session.get(account_id)
    if sess is not None:
        def _do(ctx):
            try:
                ctx.clear_cookies()
            except Exception:
                pass
        try:
            sess.exec(_do, timeout=10)
        except Exception:
            pass

    path = _cookies_path(account_id)
    try:
        if Path(path).exists():
            Path(path).unlink()
            logger.info(f"[login] account {account_id} cookies 文件已删除：{path}")
    except Exception as e:
        logger.warning(f"[login] 删除 cookies 文件失败：{e}")
