"""
xhs — CloakBrowser 直连小红书。
完全替代旧 xiaohongshu-mcp Go 子进程方案：进程内 Playwright + 源码级反检测。

公开 API（与旧 mcp_manager 对齐）：
- session.start / stop / is_running / get
- session.exec(account_id, fn)         # 在账号会话内执行函数
- login.fetch_qrcode(account_id)        # 返回 base64 二维码 + 是否已登录
- login.wait_for_login(account_id)      # 阻塞等扫码完成
- login.check_login_status(account_id)  # 单次查询
- login.delete_cookies(account_id)      # 退出登录
- publish.publish_image(account_id, ...)
- publish.publish_video(account_id, ...)
"""
from . import session, login, publish

__all__ = ["session", "login", "publish"]
