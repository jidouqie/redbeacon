"""
飞书多维表格 + 消息推送。
直接复用 dengta/xhs-publisher 的结构，字段名适配 RedBeacon schema。
"""
import base64
import time
from pathlib import Path
import requests
from redbeacon.utils.logger import get_logger

logger = get_logger("feishu")
TIMEOUT = 30
_MAX_RETRY = 3
_RETRY_DELAY = 5

FEISHU_BASE = "https://open.feishu.cn/open-apis"

# ── 飞书多维表格字段名 ─────────────────────────────────────────────────────────
# 只改这里，与模板表格字段一一对应
FIELD_TITLE        = "标题"
FIELD_BODY         = "文案"
FIELD_IMAGES       = "图片"
FIELD_TAGS         = "标签"
FIELD_STATUS       = "状态"
FIELD_SCHEDULE_AT  = "发布时间"   # 用户填写的定时发布时间（毫秒时间戳）

STATUS_PENDING   = "未审核"
STATUS_APPROVED  = "通过"
STATUS_REJECTED  = "驳回"
STATUS_PUBLISHED = "已发布"
STATUS_FAILED    = "发布失败"


def _receive_id_type(user_id: str) -> str:
    """根据 ID 前缀判定 receive_id_type："""
    if user_id.startswith("ou_"):
        return "open_id"
    if user_id.startswith("on_"):
        return "union_id"
    return "user_id"


def _retry(fn, desc: str):
    last_err = None
    for attempt in range(1, _MAX_RETRY + 1):
        try:
            return fn()
        except Exception as e:
            last_err = e
            if attempt < _MAX_RETRY:
                logger.warning(f"[feishu] {desc} 第{attempt}次失败，{_RETRY_DELAY}s 后重试: {e}")
                time.sleep(_RETRY_DELAY)
            else:
                logger.error(f"[feishu] {desc} 已失败 {_MAX_RETRY} 次，放弃: {e}")
    raise last_err


class FeishuAPI:

    def __init__(self, app_id: str, app_secret: str, app_token: str, table_id: str):
        self.app_id = app_id
        self.app_secret = app_secret
        self.app_token = app_token    # 多维表格 app token
        self.table_id = table_id      # 数据表 ID
        self._tenant_token: str = ""

    # ── Token ─────────────────────────────────────────────────────────────────

    def _get_tenant_token(self) -> str:
        resp = requests.post(
            f"{FEISHU_BASE}/auth/v3/tenant_access_token/internal",
            json={"app_id": self.app_id, "app_secret": self.app_secret},
            timeout=TIMEOUT,
        )
        resp.raise_for_status()
        return resp.json()["tenant_access_token"]

    def _auth(self) -> dict:
        if not self._tenant_token:
            self._tenant_token = self._get_tenant_token()
        return {"Authorization": f"Bearer {self._tenant_token}"}

    def _refresh_token(self) -> None:
        self._tenant_token = self._get_tenant_token()

    # ── 多维表格操作 ───────────────────────────────────────────────────────────

    def add_record(self, fields: dict) -> str:
        """新增一行，返回 record_id。"""
        def _do():
            resp = requests.post(
                f"{FEISHU_BASE}/bitable/v1/apps/{self.app_token}/tables/{self.table_id}/records",
                headers=self._auth(),
                json={"fields": fields},
                timeout=TIMEOUT,
            )
            if resp.status_code == 401:
                self._refresh_token()
                raise Exception("token 过期，已刷新")
            resp.raise_for_status()
            body = resp.json()
            if body.get("code", 0) != 0:
                raise Exception(f"飞书错误 {body.get('code')}: {body.get('msg')} — {body}")
            return body["data"]["record"]["record_id"]
        return _retry(_do, "add_record")

    def update_record(self, record_id: str, fields: dict) -> None:
        def _do():
            resp = requests.put(
                f"{FEISHU_BASE}/bitable/v1/apps/{self.app_token}/tables/{self.table_id}/records/{record_id}",
                headers=self._auth(),
                json={"fields": fields},
                timeout=TIMEOUT,
            )
            if resp.status_code == 401:
                self._refresh_token()
                raise Exception("token 过期，已刷新")
            resp.raise_for_status()
        _retry(_do, f"update_record({record_id})")

    def get_approved_records(self) -> list[dict]:
        """拉取状态为「通过」的待发布内容（自动翻页）。"""
        def _do():
            url = f"{FEISHU_BASE}/bitable/v1/apps/{self.app_token}/tables/{self.table_id}/records"
            items = []
            page_token = None
            while True:
                params = {
                    "filter": f'CurrentValue.[{FIELD_STATUS}]="{STATUS_APPROVED}"',
                    "page_size": 100,
                }
                if page_token:
                    params["page_token"] = page_token
                resp = requests.get(url, headers=self._auth(), params=params, timeout=TIMEOUT)
                if resp.status_code == 401:
                    self._refresh_token()
                    raise Exception("token 过期，已刷新")
                resp.raise_for_status()
                body = resp.json()
                if body.get("code", 0) != 0:
                    raise Exception(f"飞书错误 {body.get('code')}: {body.get('msg')}")
                data = body.get("data", {})
                items.extend(data.get("items") or [])
                if not data.get("has_more"):
                    break
                page_token = data.get("page_token")
            return items
        return _retry(_do, "get_approved_records")

    def upload_image(self, image_path: str) -> str:
        """上传图片到飞书，返回 file_token。"""
        def _do():
            with open(image_path, "rb") as f:
                data = f.read()
            resp = requests.post(
                f"{FEISHU_BASE}/drive/v1/medias/upload_all",
                headers=self._auth(),
                data={
                    "file_name": Path(image_path).name,
                    "parent_type": "bitable_image",
                    "parent_node": self.app_token,
                    "size": str(len(data)),
                },
                files={"file": (Path(image_path).name, data)},
                timeout=60,
            )
            resp.raise_for_status()
            return resp.json()["data"]["file_token"]
        return _retry(_do, f"upload_image({image_path})")

    def download_image(self, file_token: str, save_path: str) -> None:
        """从飞书下载附件到本地文件。"""
        import json as _json
        def _do():
            resp = requests.get(
                f"{FEISHU_BASE}/drive/v1/medias/{file_token}/download",
                headers=self._auth(),
                timeout=60,
                stream=True,
            )
            resp.raise_for_status()
            with open(save_path, "wb") as f:
                for chunk in resp.iter_content(chunk_size=8192):
                    f.write(chunk)
        _retry(_do, f"download_image({file_token})")

    # ── 消息推送 ───────────────────────────────────────────────────────────────

    def send_text_message(self, user_id: str, text: str) -> None:
        """发文本消息。receive_id_type 由 user_id 前缀自动判定（ou_ → open_id, on_ → union_id, 否则 user_id）。"""
        import json as _json
        id_type = _receive_id_type(user_id)
        def _do():
            resp = requests.post(
                f"{FEISHU_BASE}/im/v1/messages?receive_id_type={id_type}",
                headers=self._auth(),
                json={
                    "receive_id": user_id,
                    "msg_type": "text",
                    "content": _json.dumps({"text": text}),
                },
                timeout=TIMEOUT,
            )
            resp.raise_for_status()
        _retry(_do, "send_text_message")

    # ── 凭证与目录操作（供 CLI 工具命令使用） ─────────────────────────────────

    @staticmethod
    def verify_credentials(app_id: str, app_secret: str) -> None:
        """验证 app_id/secret 能否换出 tenant_access_token；失败抛异常。"""
        resp = requests.post(
            f"{FEISHU_BASE}/auth/v3/tenant_access_token/internal",
            json={"app_id": app_id, "app_secret": app_secret},
            timeout=TIMEOUT,
        )
        resp.raise_for_status()
        body = resp.json()
        if body.get("code", 0) != 0:
            raise RuntimeError(f"飞书认证失败：{body.get('msg')}")

    def list_contact_users(self, page_size: int = 50) -> list[dict]:
        """列出通讯录用户（open_id）。需要 contact:user:readonly 权限。"""
        resp = requests.get(
            f"{FEISHU_BASE}/contact/v3/users",
            headers=self._auth(),
            params={"page_size": page_size, "user_id_type": "open_id"},
            timeout=TIMEOUT,
        )
        resp.raise_for_status()
        body = resp.json()
        if body.get("code", 0) != 0:
            raise RuntimeError(f"飞书错误：{body.get('msg')}（需要 contact:user:readonly 权限）")
        return [
            {"user_id": u.get("open_id", ""), "name": u.get("name", "")}
            for u in (body.get("data", {}).get("items") or [])
            if u.get("open_id")
        ]

    def copy_bitable_template(self, template_app_token: str, name: str = "RedBeacon 内容审核") -> str:
        """复制多维表格模板，返回新的 app_token。失败返回原模板 token（共享模板）。"""
        # 先试 drive/v1 files copy
        try:
            cr = requests.post(
                f"{FEISHU_BASE}/drive/v1/files/{template_app_token}/copy",
                headers=self._auth(),
                json={"name": name, "type": "bitable", "folder_token": ""},
                timeout=TIMEOUT,
            )
            cd = cr.json() if cr.status_code == 200 else {}
            if cd.get("code") == 0:
                token = (cd.get("data", {}).get("file", {}) or {}).get("token")
                if token:
                    return token
        except Exception:
            pass
        # 回退 bitable/v1 apps copy
        try:
            cr2 = requests.post(
                f"{FEISHU_BASE}/bitable/v1/apps/{template_app_token}/copy",
                headers=self._auth(),
                json={"name": name, "time_zone": "Asia/Shanghai"},
                timeout=TIMEOUT,
            )
            cd2 = cr2.json() if cr2.status_code == 200 else {}
            token = (cd2.get("data", {}).get("app", {}) or {}).get("app_token")
            if token:
                return token
        except Exception:
            pass
        return template_app_token

    def share_bitable_to_user(self, app_token: str, user_id: str) -> dict:
        """把复制出来的多维表授权给用户并转移所有权。

        模板是用 tenant(应用)身份复制的，表默认归"应用"所有、用户进不去。
        需补两步：① 把用户加为 full_access 协作者 ② 把所有权转给用户。
        两步均尽力而为、失败不抛（不阻断绑表主流程）；返回各步 {ok,msg} 便于诊断
        （失败多为应用缺「管理云文档权限」scope，需在开放平台补权限并发版）。
        """
        member_type = (
            "openid"  if user_id.startswith("ou_") else
            "unionid" if user_id.startswith("on_") else
            "userid"
        )

        def _post(path: str, extra_params: dict, payload: dict, desc: str) -> dict:
            try:
                r = requests.post(
                    f"{FEISHU_BASE}{path}",
                    headers=self._auth(),
                    params={"type": "bitable", **extra_params},
                    json=payload,
                    timeout=TIMEOUT,
                )
                data = r.json() if "application/json" in r.headers.get("content-type", "") else {}
                if data.get("code") == 0:
                    return {"ok": True, "msg": "ok"}
                msg = data.get("msg") or f"HTTP {r.status_code}"
                logger.warning(f"[feishu] {desc}失败：code={data.get('code')} msg={msg}")
                return {"ok": False, "msg": msg}
            except Exception as e:
                logger.warning(f"[feishu] {desc}异常（非致命）：{e}")
                return {"ok": False, "msg": str(e)}

        member = _post(
            f"/drive/v1/permissions/{app_token}/members", {},
            {"member_type": member_type, "member_id": user_id, "perm": "full_access"},
            "加协作者",
        )
        time.sleep(0.5)
        owner = _post(
            f"/drive/v1/permissions/{app_token}/members/transfer_owner",
            {"remove_old_owner": "false", "stay_put": "true"},
            {"member_type": member_type, "member_id": user_id,
             "perm": "full_access", "perm_type": "set_owner", "type": "bitable"},
            "转移所有权",
        )
        return {"member": member, "owner": owner}

    def list_tables(self, app_token: str) -> list[dict]:
        resp = requests.get(
            f"{FEISHU_BASE}/bitable/v1/apps/{app_token}/tables",
            headers=self._auth(),
            timeout=TIMEOUT,
        )
        if resp.status_code != 200:
            return []
        return (resp.json().get("data", {}) or {}).get("items") or []

    def write_test_record_and_cleanup(self, app_token: str | None = None,
                                       table_id: str | None = None) -> dict:
        """写入一条测试记录然后删除，用于校验表格读写。"""
        at = app_token or self.app_token
        tid = table_id or self.table_id
        wr = requests.post(
            f"{FEISHU_BASE}/bitable/v1/apps/{at}/tables/{tid}/records",
            headers=self._auth(),
            json={"fields": {FIELD_TITLE: "[测试] RedBeacon 连通性检测，请忽略",
                              FIELD_STATUS: STATUS_PENDING}},
            timeout=TIMEOUT,
        )
        wb = wr.json() if wr.status_code == 200 else {}
        if wb.get("code") != 0:
            raise RuntimeError(f"写入失败：{wb.get('msg', wr.text[:120])}")
        rid = wb["data"]["record"]["record_id"]
        requests.delete(
            f"{FEISHU_BASE}/bitable/v1/apps/{at}/tables/{tid}/records/{rid}",
            headers=self._auth(), timeout=TIMEOUT,
        )
        return {"record_id": rid}
