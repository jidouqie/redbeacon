"""授权 / 解锁：免费版单账号，付费解锁多账号矩阵。解锁码绑定机器码。

强制点必须在 CLI（用户改不了），不能放 skill（提示词层用户可改）。

加密方案：Ed25519 非对称签名（离线可验、绑机器、换机失效、无私钥无法伪造）。
  - 云端（只有你）持**私钥**，对用户的 machine_code 签名，得到解锁码。
  - CLI 内置**公钥**（下方 _PUBLIC_KEY_HEX），离线验签，验签对象 = 本机现算的 machine_code。
  - 公钥即使被逆向也无害；没有私钥造不出任何有效解锁码。

解锁码格式：base32(无填充, 大写) 编码的 64 字节 Ed25519 签名。用户输入时大小写、
空格、连字符都会被规范化，容错友好。

发码端怎么签：见仓库根目录 `tools/sign_license.py` 和 `LICENSE_SERVER.md`。

⚠️ 当前内置的是**开发用公钥**。正式版上线前：在服务端生成一对全新密钥，
把下方 _PUBLIC_KEY_HEX 换成正式公钥，私钥只留在你的发码服务器，绝不进客户端仓库。
"""
from __future__ import annotations

import base64

from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey
from cryptography.exceptions import InvalidSignature

from redbeacon import config as cfg
from redbeacon.config_keys import CK_LICENSE_KEY
from redbeacon.utils.machine import machine_code  # noqa: F401  (re-export，调用方习惯 license.machine_code)

FREE_MAX_ACCOUNTS = 1     # 免费版：单账号
PRO_MAX_ACCOUNTS = 99     # 解锁后：多账号矩阵

# 正式公钥（hex，2026-06-03 启用）。配对私钥只在 tools/prod_private_key.hex（gitignore）
# 与发码服务器的 REDBEACON_PRIV_HEX。换密钥会令旧密钥签发的解锁码全部失效。
_PUBLIC_KEY_HEX = "4d538cfbdb4104f17be4c1dc31cfe7a05b591be243b540da9f937e268fd02420"


def _normalize(code: str) -> str:
    """规范化用户输入的解锁码：去空格/连字符、大写、补回 base32 填充。"""
    s = "".join(code.split()).replace("-", "").upper()
    pad = (-len(s)) % 8
    return s + ("=" * pad)


def _verify(code: str, mc: str) -> bool:
    """用内置公钥验证解锁码对本机 machine_code 的签名是否有效。"""
    try:
        sig = base64.b32decode(_normalize(code))
    except Exception:
        return False
    pub = Ed25519PublicKey.from_public_bytes(bytes.fromhex(_PUBLIC_KEY_HEX))
    try:
        pub.verify(sig, mc.encode("utf-8"))
        return True
    except InvalidSignature:
        return False
    except Exception:
        return False


def is_unlocked() -> bool:
    key = cfg.get(CK_LICENSE_KEY).strip()
    return bool(key) and _verify(key, machine_code())


def activate(code: str) -> bool:
    """验证解锁码并持久化。成功返回 True。"""
    code = code.strip()
    if not _verify(code, machine_code()):
        return False
    cfg.set(CK_LICENSE_KEY, code)
    return True


def max_accounts() -> int:
    return PRO_MAX_ACCOUNTS if is_unlocked() else FREE_MAX_ACCOUNTS


def tier() -> str:
    return "pro" if is_unlocked() else "free"
