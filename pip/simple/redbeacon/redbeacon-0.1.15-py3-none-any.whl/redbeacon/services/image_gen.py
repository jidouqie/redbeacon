"""
AI 图片生成服务。
支持两种模式：
  1. 纯文生图：只传 prompt
  2. 图生图（多模态）：传 items 列表，每项含 image_path（本地路径或 base64 data URL）+ prompt
"""
import base64
import re
import time
from pathlib import Path

from redbeacon import config as cfg
from redbeacon.config_keys import CK_AI_API_KEY, CK_AI_BASE_URL, CK_IMAGE_MODEL
from redbeacon.utils.logger import get_logger

logger = get_logger("image_gen")


def generate(
    prompt: str,
    save_dir: str,
    model: str | None = None,
    count: int = 1,
    reference_items: list[dict] | None = None,
) -> list[str]:
    """
    生成图片，保存为 JPG，返回已保存文件的绝对路径列表。

    reference_items: list of {"image_path": str, "prompt": str}
      - image_path 为空 → 纯文生图
      - image_path 非空 → 图生图，把图片 base64 编码后随 prompt 一起发送
      - 多个 item → 所有图片拼入同一条消息，各项 prompt 按顺序拼接
    """
    import httpx
    from openai import OpenAI

    api_key  = cfg.get(CK_AI_API_KEY)
    base_url = cfg.get(CK_AI_BASE_URL)
    model    = model or cfg.get(CK_IMAGE_MODEL)

    if not api_key:
        logger.warning("[image_gen] AI API Key 未配置，跳过图片生成")
        return []
    if not model:
        logger.warning("[image_gen] 图片模型未配置，跳过图片生成")
        return []

    client = OpenAI(
        api_key=api_key,
        base_url=base_url,
        max_retries=0,
        http_client=httpx.Client(trust_env=False, timeout=180),
    )

    messages = _build_messages(prompt, reference_items)

    # 参考图本地绝对路径（图生图素材）：chat 走多模态、Images API 走 images.edit 都要用到
    ref_paths: list[str] = []
    for it in (reference_items or []):
        ip = it.get("image_path")
        if ip:
            rp = _resolve_image_path(ip)
            if rp.exists():
                ref_paths.append(str(rp))
    has_ref = bool(ref_paths)
    logger.info(f"[image_gen] 生成图片 x{count}，model={model}，有参考图={has_ref}")

    results: list[str] = []
    # 统一入口 + 能力试探择路：两套协议（chat 多模态 / Images API）互为兜底，
    # 哪套先出图就用哪套并记住。模型名只用来定"先试哪套"的顺序，不决定能不能用。
    # 加新 OpenAI 兼容图模型 = 零适配代码。
    text_prompt = _flatten_text_prompt(prompt, reference_items)
    order = ["images", "chat"] if _looks_like_images_api(model) else ["chat", "images"]
    # 下载托管 URL 形式图片用的独立 client（中转站返回 http(s) 图片链接时走这里）
    with httpx.Client(trust_env=False, timeout=180, follow_redirects=True) as dl:
        for i in range(count):
            last_err = None
            for attempt in range(3):  # 最多重试 2 次（共 3 次）
                try:
                    imgs, order = _generate_one(
                        client, model, messages, text_prompt, ref_paths, dl, order
                    )
                    for b in imgs:
                        results.append(_save_bytes(b, save_dir))
                    last_err = None
                    break
                except Exception as e:
                    last_err = e
                    if attempt < 2:
                        logger.warning(f"[image_gen] 第{i+1}张第{attempt+1}次失败，5s 后重试：{e}")
                        time.sleep(5)
            if last_err is not None:
                logger.warning(f"[image_gen] 第{i+1}张生成失败，跳过：{last_err}")

    return results


# ── 双接口择路（chat 多模态 / Images API）──────────────────────────────────────

def _looks_like_images_api(model: str) -> bool:
    """按模型名预判是否为 Images API 模型（gpt-image / dall-e 系）。"""
    m = (model or "").lower()
    return ("gpt-image" in m) or ("dall-e" in m) or ("dalle" in m)


def _is_modalities_unsupported(err: Exception) -> bool:
    """识别"该模型不支持 chat 的 image modalities"这类错误（应改走 Images API）。"""
    s = str(err).lower()
    return "modalities" in s and ("image" in s or "supported values" in s)


def _flatten_text_prompt(prompt: str, reference_items: list[dict] | None) -> str:
    """把主 prompt + 模板 item 的文字 prompt 合成一条纯文本（Images API 无多模态，只吃文本）。"""
    item_prompts = [it["prompt"] for it in (reference_items or []) if it.get("prompt")]
    parts = ([prompt] if prompt else []) + item_prompts
    combined = "\n".join(parts) if parts else "小红书封面图"
    return combined + "\n\n竖版构图，3:4比例，小红书封面风格，高质量，精美细腻。"


def _proto_chat(client, model, messages, text_prompt, ref_paths, dl) -> list[bytes]:
    """协议①：chat 多模态（Gemini 系）。参考图已在 messages 里（图生图）。"""
    resp = client.chat.completions.create(
        model=model, messages=messages, modalities=["image", "text"])
    content = resp.choices[0].message.content
    refs = _extract_image_refs(content)
    if not refs:
        raise RuntimeError(f"chat 未返回图片（content类型={type(content).__name__}）")
    out = [b for b in (_ref_to_bytes(r, dl) for r in refs) if b]
    if not out:
        raise RuntimeError("chat 提取到图片引用但全部下载/解码失败")
    return out


def _proto_images(client, model, messages, text_prompt, ref_paths, dl) -> list[bytes]:
    """协议②：Images API（gpt-image / dall-e 系）。有参考图走 edit（图生图）、否则 generate。"""
    if ref_paths:
        resp = _call_images_edit(client, model, text_prompt, ref_paths)
    else:
        resp = client.images.generate(model=model, prompt=text_prompt, n=1)
    out = _extract_images_resp(resp, dl)
    if not out:
        raise RuntimeError("Images API 未返回图片")
    return out


# 协议注册表：加新协议（如某家原生 API）只在这里加一项；模型层零改动。
_PROTOCOLS = {"chat": _proto_chat, "images": _proto_images}


def _generate_one(client, model, messages, text_prompt, ref_paths, dl, order):
    """统一调度：按 order 里的协议依次尝试，谁先出图就用谁，并把它提到队首记住。

    不做任何错误分类——**某协议失败就换下一套**，全失败才抛错（由上层重试整轮）。
    所以加任何 OpenAI 兼容新图模型都零适配：引擎自己试出它走哪套协议。
    """
    last_err: Exception | None = None
    for proto in order:
        try:
            imgs = _PROTOCOLS[proto](client, model, messages, text_prompt, ref_paths, dl)
            return imgs, [proto] + [p for p in order if p != proto]
        except Exception as e:
            last_err = e
            logger.info(f"[image_gen] {model} 协议[{proto}]没出图，换下一套：{str(e)[:80]}")
            continue
    raise last_err or RuntimeError("所有图片协议都未返回图片")


def _call_images_edit(client, model, prompt, ref_paths):
    """用 Images Edit 端点做图生图（gpt-image 系）：把参考图文件随 prompt 一起传进去。"""
    open_files = []
    try:
        for p in ref_paths:
            open_files.append(open(p, "rb"))
        image_arg = open_files if len(open_files) > 1 else open_files[0]
        return client.images.edit(model=model, image=image_arg, prompt=prompt)
    finally:
        for f in open_files:
            try:
                f.close()
            except Exception:
                pass


def _extract_images_resp(resp, dl) -> list[bytes]:
    """从 Images API（generate / edit）响应里取出图片字节：兼容 b64_json 与托管 url。"""
    out: list[bytes] = []
    for d in (getattr(resp, "data", None) or []):
        b64 = getattr(d, "b64_json", None)
        url = getattr(d, "url", None)
        if b64:
            try:
                out.append(base64.b64decode(b64))
            except Exception:
                pass
        elif url:
            b = _ref_to_bytes(url, dl)
            if b:
                out.append(b)
    return out


# ── 图片提取（兼容各家中转站的多种返回格式）─────────────────────────────────────
# 中转站返回图片的方式五花八门，统一抽成「引用」(ref) 再由 _ref_to_bytes 落地：
#   - data URL：   data:image/png;base64,xxxx
#   - 托管链接：    https://.../xxx.png（很多代理 Gemini/DALL-E/flux 的中转站这么回）
#   - markdown 图： ![](https://...) 或 ![](data:image/...)
#   - parts 列表的 image_url.url（值本身可能是 data URL 或 http URL，原样取）
_DATA_URL_RE   = re.compile(r"data:image/[\w.+-]+;base64,[A-Za-z0-9+/=]+", re.I)
_MD_IMG_RE     = re.compile(r"!\[[^\]]*\]\((https?://[^\s)]+)\)")
_BARE_IMG_URL  = re.compile(
    r"https?://[^\s\"'<>)\]]+\.(?:png|jpe?g|webp|gif)(?:\?[^\s\"'<>)\]]*)?", re.I)


def _collect_refs_from_text(text: str) -> list[str]:
    """从一段文本里捞出所有图片引用（data URL / markdown 图链 / 裸图 URL）。"""
    if not text:
        return []
    refs: list[str] = []
    refs += _DATA_URL_RE.findall(text)
    refs += _MD_IMG_RE.findall(text)
    refs += _BARE_IMG_URL.findall(text)
    return refs


def _extract_image_refs(content) -> list[str]:
    """从 chat content 中提取所有图片引用，兼容字符串 / parts 列表两种返回。

    返回归一化的引用字符串列表（data: URL 或 http(s) URL），保序去重。
    """
    if not content:
        return []
    refs: list[str] = []

    if isinstance(content, str):
        refs += _collect_refs_from_text(content)
    elif isinstance(content, list):
        for part in content:
            if isinstance(part, dict):
                ptype = part.get("type")
                if ptype == "image_url":
                    url = (part.get("image_url") or {}).get("url", "") or ""
                    if url:
                        refs.append(url)
                elif ptype == "text":
                    refs += _collect_refs_from_text(part.get("text", "") or "")
                else:
                    # 未知结构：扫描所有字符串字段兜底
                    for v in part.values():
                        if isinstance(v, str):
                            refs += _collect_refs_from_text(v)
            else:
                # pydantic 对象（openai SDK 返回）
                ptype = getattr(part, "type", None)
                if ptype == "image_url":
                    url = getattr(getattr(part, "image_url", None), "url", "") or ""
                    if url:
                        refs.append(url)
                elif ptype == "text":
                    refs += _collect_refs_from_text(getattr(part, "text", "") or "")

    seen: set[str] = set()
    uniq: list[str] = []
    for r in refs:
        if r and r not in seen:
            seen.add(r)
            uniq.append(r)
    return uniq


def _ref_to_bytes(ref: str, http_client) -> bytes | None:
    """把一个图片引用落成原始字节：data URL 直接解码，http(s) URL 下载。"""
    try:
        if ref.startswith("data:"):
            b64 = ref.split(",", 1)[1] if "," in ref else ""
            b64 = re.sub(r"\s", "", b64)
            if not b64:
                return None
            return base64.b64decode(b64 + "=" * (-len(b64) % 4))
        if ref.startswith("http://") or ref.startswith("https://"):
            r = http_client.get(ref)
            r.raise_for_status()
            return r.content
    except Exception as e:
        logger.warning(f"[image_gen] 取图失败 {ref[:80]}：{e}")
    return None


def _extract_b64(content) -> list[str]:
    """[兼容保留] 仅提取 data URL 里的 base64 串。新代码请用 _extract_image_refs。"""
    refs = _extract_image_refs(content)
    out: list[str] = []
    for ref in refs:
        if ref.startswith("data:") and "," in ref:
            out.append(re.sub(r"\s", "", ref.split(",", 1)[1]))
    return out


def _build_messages(prompt: str, reference_items: list[dict] | None) -> list[dict]:
    """把 reference_items + prompt 组装成 OpenAI 多模态 messages。"""
    has_images = reference_items and any(i.get("image_path") for i in reference_items)

    # 无论是否有参考图，都先收集模板 item 的 prompt（避免纯文生图时漏掉 item 提示词）
    item_prompts: list[str] = []
    for item in (reference_items or []):
        ip = item.get("prompt", "")
        if ip:
            item_prompts.append(ip)

    if not has_images:
        # 纯文生图：主提示词 + item prompts 合并
        all_parts = ([prompt] if prompt else []) + item_prompts
        combined = "\n".join(all_parts) if all_parts else ""
        full_prompt = (
            combined + "\n\n竖版构图，3:4比例，小红书封面风格，高质量，精美细腻。"
            if len(combined) < 200 else combined
        )
        return [{"role": "user", "content": full_prompt}]

    # 图生图：先放图片 parts，再放合并后的文本 prompt
    content_parts: list[dict] = []
    for item in (reference_items or []):
        img_path = item.get("image_path", "")
        if not img_path:
            continue
        data_url = _to_data_url(img_path)
        if data_url:
            content_parts.append({
                "type": "image_url",
                "image_url": {"url": data_url},
            })

    all_prompts = ([prompt] if prompt else []) + item_prompts
    final_text = "\n".join(all_prompts) if all_prompts else "按参考图风格生成"
    final_text += "\n\n竖版构图，3:4比例，小红书封面风格，高质量，精美细腻。"

    content_parts.append({"type": "text", "text": final_text})
    return [{"role": "user", "content": content_parts}]


def _resolve_image_path(image_path: str) -> Path:
    """相对路径拼接 data_dir，绝对路径直接用（兼容旧记录）。"""
    import os as _os
    from redbeacon.utils.paths import default_data_dir
    p = Path(image_path)
    if p.is_absolute():
        return p
    data_dir = Path(_os.environ.get("REDBEACON_DATA_DIR", str(default_data_dir()))).resolve()
    return (data_dir / p).resolve()


def _to_data_url(image_path: str) -> str | None:
    if not image_path:
        return None
    if image_path.startswith("data:"):
        return image_path
    try:
        p = _resolve_image_path(image_path)
        if not p.exists():
            logger.warning(f"[image_gen] 参考图片不存在：{image_path}")
            return None
        mime_map = {".jpg": "image/jpeg", ".jpeg": "image/jpeg",
                    ".png": "image/png", ".webp": "image/webp", ".gif": "image/gif"}
        mime = mime_map.get(p.suffix.lower(), "image/jpeg")
        b64 = base64.b64encode(p.read_bytes()).decode()
        return f"data:{mime};base64,{b64}"
    except Exception as e:
        logger.warning(f"[image_gen] 参考图片读取失败 {image_path}：{e}")
        return None


def _save_bytes(data: bytes, save_dir: str) -> str:
    Path(save_dir).mkdir(parents=True, exist_ok=True)
    filename = f"ai_image_{int(time.time() * 1000)}.jpg"
    file_path = Path(save_dir) / filename
    file_path.write_bytes(data)
    logger.info(f"[image_gen] 图片已保存：{file_path}")
    return str(file_path)
