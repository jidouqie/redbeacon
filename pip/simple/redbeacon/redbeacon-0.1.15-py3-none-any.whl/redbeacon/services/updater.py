"""升级服务：版本检查 + skill 刷新 + CLI 自升级。

分发架构（见 memory packaging-plan / release-flow）：
  - CLI 闭源，走阿里云 OSS 私有 pip 源，用 `uv tool upgrade redbeacon` 升级。
  - skill 开源在 GitHub，升级 = 从 raw 重新拉 markdown 覆盖到 AI 助手命令目录。
  - 官网静态托管 latest.json 当版本清单（单一事实源），形如：
      {
        "version": "0.2.0",
        "notes": "本次更新说明（人话，给用户看）",
        "skill_raw_base": "https://raw.githubusercontent.com/jidouqie/redbeacon-skill/main/.claude/commands",
        "skill_files": ["redbeacon.md", "redbeacon-accounts.md", ...]
      }

设计要点：
  - 所有联网都**有超时、失败静默**：拉不到清单绝不能卡住正常使用，最多就是"查不到新版"。
  - readiness 走**缓存优先 + 每日一次紧超时刷新**，不在热路径上做阻塞网络调用。
  - 自升级用子进程调 uv；非 uv 安装（开发态 / pip -e）时优雅降级，给出手动指引而非报错。
"""
from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
import time
from pathlib import Path
from typing import Optional

import httpx

from redbeacon import __version__
from redbeacon import config as cfg
from redbeacon.config_keys import CK_UPDATE_MANIFEST_URL, CK_SKILL_INSTALL_DIR
from redbeacon.utils.logger import get_logger
from redbeacon.utils.paths import default_data_dir

log = get_logger("service.updater")

_CACHE_TTL = 24 * 3600          # readiness 自动刷新间隔：24h
_CACHE_NAME = "update_check.json"
_LIVE_TIMEOUT = 6.0             # 用户主动 update --check 的超时
_BG_TIMEOUT = 2.5              # readiness 后台刷新的紧超时（不拖慢热路径）


# ── 版本号比较 ──────────────────────────────────────────────────────────────

def _parse_ver(s: str) -> tuple:
    """宽松解析 'a.b.c' → (a, b, c)；非数字段按 0，缺段补 0。"""
    parts = (s or "").strip().lstrip("vV").split(".")
    out = []
    for p in parts[:3]:
        num = "".join(ch for ch in p if ch.isdigit())
        out.append(int(num) if num else 0)
    while len(out) < 3:
        out.append(0)
    return tuple(out)


def is_newer(latest: str, current: str) -> bool:
    return _parse_ver(latest) > _parse_ver(current)


# ── 清单获取 ────────────────────────────────────────────────────────────────

def _manifest_url() -> str:
    # 环境变量优先（测试 / 临时切源用），其次配置，最后内置默认
    return (
        os.environ.get("REDBEACON_UPDATE_URL")
        or cfg.get(CK_UPDATE_MANIFEST_URL)
        or CK_UPDATE_MANIFEST_URL.default
    )


def fetch_manifest(timeout: float = _LIVE_TIMEOUT) -> Optional[dict]:
    """拉版本清单。任何异常都返回 None（失败静默，绝不抛给上层）。"""
    url = _manifest_url()
    try:
        r = httpx.get(url, timeout=timeout, follow_redirects=True)
        r.raise_for_status()
        data = r.json()
        if isinstance(data, dict) and data.get("version"):
            return data
        log.warning("版本清单格式异常：%s", url)
    except Exception as e:
        log.info("拉取版本清单失败（静默忽略）：%s", e)
    return None


# ── 检查结果缓存 ────────────────────────────────────────────────────────────

def _cache_path() -> Path:
    base = Path(os.environ.get("REDBEACON_DATA_DIR", str(default_data_dir())))
    return base / _CACHE_NAME


def _write_cache(result: dict) -> None:
    try:
        p = _cache_path()
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(json.dumps(result, ensure_ascii=False), encoding="utf-8")
    except Exception as e:
        log.info("写升级缓存失败（忽略）：%s", e)


def _read_cache() -> Optional[dict]:
    try:
        return json.loads(_cache_path().read_text(encoding="utf-8"))
    except Exception:
        return None


def _result_from_manifest(manifest: dict) -> dict:
    latest = str(manifest.get("version", "")).strip()
    return {
        "current": __version__,
        "latest": latest,
        "update_available": bool(latest) and is_newer(latest, __version__),
        "notes": manifest.get("notes", ""),
        "checked_at": int(time.time()),
    }


def check(timeout: float = _LIVE_TIMEOUT) -> dict:
    """主动检查（用户触发）。联网拉清单 → 比对 → 写缓存 → 返回结果。

    联网失败时返回 `available=None` 语义：current 已知，latest 为空，error 说明。
    """
    manifest = fetch_manifest(timeout=timeout)
    if manifest is None:
        return {
            "current": __version__,
            "latest": "",
            "update_available": False,
            "notes": "",
            "checked_at": int(time.time()),
            "error": "查不到版本信息（网络不通或官网未部署），稍后再试即可，不影响使用。",
        }
    result = _result_from_manifest(manifest)
    _write_cache(result)
    return result


def readiness_update_info() -> Optional[dict]:
    """供 readiness 用：缓存优先，缓存过期则做一次紧超时刷新；全程不抛异常。

    返回精简字段 {update_available, latest, notes} 或 None（无任何可用信息时）。
    """
    cached = _read_cache()
    fresh = bool(cached) and (time.time() - cached.get("checked_at", 0) < _CACHE_TTL)
    if not fresh:
        manifest = fetch_manifest(timeout=_BG_TIMEOUT)
        if manifest is not None:
            cached = _result_from_manifest(manifest)
            _write_cache(cached)
    if not cached:
        return None
    return {
        "update_available": bool(cached.get("update_available")),
        "latest": cached.get("latest", ""),
        "notes": cached.get("notes", ""),
    }


# ── skill 刷新 ──────────────────────────────────────────────────────────────

def find_skill_dir() -> Optional[Path]:
    """定位 skill 命令目录：配置优先（install.sh 写入），否则探测 ~/.claude/commands。"""
    configured = cfg.get(CK_SKILL_INSTALL_DIR).strip()
    if configured:
        return Path(os.path.expanduser(configured))
    guess = Path(os.path.expanduser("~")) / ".claude" / "commands"
    return guess if guess.exists() else None


# ── Codex 端桥接（双宿主一致）────────────────────────────────────────────────
# Claude Code 用 .claude/commands/<name>.md（单文件斜杠命令）；Codex 用
# ~/.codex/skills/<name>/SKILL.md（文件夹式）。正文 harness 无关、可直接复用，
# 只需转 frontmatter + 给中文名 skill 一个 ASCII 别名（Codex 文件夹/名用 ASCII 最稳）。
# 真源始终是 .claude/commands 的 markdown；这里只是从真源派生 Codex bridge。
_CODEX_NAME_MAP = {           # Claude 文件名(去.md) → Codex skill 名（ASCII）
    "redbeacon-定位": "redbeacon-locate",
    "redbeacon-策略": "redbeacon-strategy",
    "redbeacon-诊断": "redbeacon-diagnose",
    "redbeacon-选题": "redbeacon-topics",
    "redbeacon-面板": "redbeacon-panel",
}


def codex_skill_name(claude_stem: str) -> str:
    """Claude 命令名（已去 .md）→ Codex skill 名（中文名走 ASCII 别名，其余原样）。"""
    return _CODEX_NAME_MAP.get(claude_stem, claude_stem)


def find_codex_skill_dir() -> Optional[Path]:
    """定位 Codex 用户级 skill 目录：~/.codex/skills（存在才返回，没装 Codex 就跳过）。"""
    guess = Path(os.path.expanduser("~")) / ".codex" / "skills"
    return guess if guess.exists() else None


def _yaml_escape(s: str) -> str:
    return '"' + s.replace("\\", "\\\\").replace('"', '\\"') + '"'


def claude_md_to_codex_skill(claude_stem: str, md_text: str) -> tuple[str, str]:
    """把一份 Claude 命令 markdown 转成 Codex SKILL.md 文本。
    返回 (codex_skill_name, skill_md)。正文原样保留（CLI 调用 harness 无关）。"""
    name = codex_skill_name(claude_stem)
    desc, body = "", md_text
    # 拆 YAML frontmatter（首段 --- … ---）
    if md_text.startswith("---"):
        parts = md_text.split("\n---", 1)
        if len(parts) == 2:
            head = parts[0].lstrip("-\n")
            body = parts[1].lstrip("\n")
            for line in head.splitlines():
                if line.strip().startswith("description:"):
                    desc = line.split("description:", 1)[1].strip().strip('"').strip("'")
                    break
    desc = desc or f"RedBeacon 能力：{name}"
    short = desc.split("—")[0].split(" — ")[0].strip()[:60] or name
    # 正文交叉引用重写：把中文名 skill 的斜杠引用换成 Codex 的 ASCII 别名，消除悬空引用
    # （如 `/redbeacon-定位` → `/redbeacon-locate`）。ASCII 名的 7 个本就一致，无需改。
    for zh_stem, ascii_name in _CODEX_NAME_MAP.items():
        body = body.replace("/" + zh_stem, "/" + ascii_name)
    fm = (
        "---\n"
        f"name: {name}\n"
        f"description: {_yaml_escape(desc)}\n"
        "metadata:\n"
        f"  short-description: {_yaml_escape(short)}\n"
        "---\n\n"
    )
    return name, fm + body


def _write_codex_bridge(claude_stem: str, md_text: str) -> Optional[str]:
    """把一份真源 markdown 派生写入 Codex skill 文件夹。返回写入的 skill 名或 None（没装 Codex）。"""
    cdir = find_codex_skill_dir()
    if cdir is None:
        return None
    name, skill_md = claude_md_to_codex_skill(claude_stem, md_text)
    folder = cdir / name
    folder.mkdir(parents=True, exist_ok=True)
    (folder / "SKILL.md").write_text(skill_md, encoding="utf-8")
    return name


def refresh_skill(manifest: dict, timeout: float = _LIVE_TIMEOUT) -> dict:
    """按清单的 skill_raw_base + skill_files 从 GitHub 拉最新 markdown 覆盖到本地。
    Claude 端写 .claude/commands/<name>.md；若本机装了 Codex，同时派生写
    ~/.codex/skills/<name>/SKILL.md，做到双宿主一致（真源仍是同一份 markdown）。"""
    base = (manifest.get("skill_raw_base") or "").rstrip("/")
    files = manifest.get("skill_files") or []
    if not base or not files:
        return {"ok": False, "reason": "版本清单缺 skill_raw_base / skill_files，跳过 skill 刷新"}

    target = find_skill_dir()
    if target is None:
        return {"ok": False, "reason": "未找到 skill 命令目录（~/.claude/commands 不存在）；可能尚未安装到 AI 助手"}
    target.mkdir(parents=True, exist_ok=True)
    codex_dir = find_codex_skill_dir()   # 没装 Codex 就是 None，整段跳过

    updated, failed, codex_updated = [], [], []
    with httpx.Client(timeout=timeout, follow_redirects=True) as client:
        for name in files:
            try:
                r = client.get(f"{base}/{name}")
                r.raise_for_status()
                (target / name).write_text(r.text, encoding="utf-8")
                updated.append(name)
                if codex_dir is not None:
                    try:
                        cn = _write_codex_bridge(name[:-3] if name.endswith(".md") else name, r.text)
                        if cn:
                            codex_updated.append(cn)
                    except Exception as e:
                        log.warning("写 Codex bridge 失败 %s：%s", name, e)
            except Exception as e:
                log.warning("刷新 skill 文件失败 %s：%s", name, e)
                failed.append(name)
    result = {
        "ok": not failed,
        "target_dir": str(target),
        "updated": updated,
        "failed": failed,
    }
    if codex_dir is not None:
        result["codex_dir"] = str(codex_dir)
        result["codex_updated"] = codex_updated
    return result


# ── CLI 自升级 ──────────────────────────────────────────────────────────────

def _has_uv() -> bool:
    return shutil.which("uv") is not None


def self_upgrade(timeout: float = 600.0) -> dict:
    """用 uv 升级闭源 CLI 包。非 uv 安装环境优雅降级（给手动指引，不报错）。"""
    if not _has_uv():
        return {
            "ok": False,
            "skipped": True,
            "reason": "未检测到 uv，跳过 CLI 自升级（开发态或非标准安装）。",
            "hint": "正式安装由 install.sh 用 uv tool install；如需手动升级请重跑安装脚本。",
        }
    try:
        proc = subprocess.run(
            ["uv", "tool", "upgrade", "redbeacon"],
            capture_output=True, text=True, timeout=timeout,
        )
        ok = proc.returncode == 0
        tail = (proc.stdout + proc.stderr).strip().splitlines()[-3:]
        return {"ok": ok, "skipped": False, "log": "\n".join(tail)}
    except Exception as e:
        return {"ok": False, "skipped": False, "reason": f"uv 升级执行失败：{e}"}


def run_update() -> dict:
    """一键升级：拉清单 → 自升级 CLI → 刷新 skill。汇总结果给 skill 端讲人话。"""
    manifest = fetch_manifest()
    if manifest is None:
        return {
            "ok": False,
            "current": __version__,
            "error": "拉不到版本清单（网络不通或官网未部署），本次升级中止，当前版本仍可正常使用。",
        }
    latest = str(manifest.get("version", "")).strip()
    available = is_newer(latest, __version__)

    cli_res = self_upgrade()
    skill_res = refresh_skill(manifest)
    _write_cache(_result_from_manifest(manifest))

    return {
        "ok": True,
        "current": __version__,
        "latest": latest,
        "was_outdated": available,
        "notes": manifest.get("notes", ""),
        "cli": cli_res,
        "skill": skill_res,
    }
