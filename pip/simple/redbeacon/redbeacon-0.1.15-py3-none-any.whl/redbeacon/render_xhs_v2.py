#!/usr/bin/env python3
"""
小红书卡片渲染脚本 V2 - 智能分页版
将 Markdown 文件渲染为小红书风格的图片卡片

新特性：
1. 智能分页：自动检测内容高度，超出时自动拆分到多张卡片
2. 多种样式：支持多种预设样式主题
3. 字数预估：基于字数预分配内容，减少渲染次数

使用方法:
    python render_xhs_v2.py <markdown_file> [options]

依赖安装:
    pip install markdown pyyaml playwright
    playwright install chromium
"""

import argparse
import asyncio
import os
import re
import sys
import tempfile
from pathlib import Path
from typing import List, Dict, Tuple

try:
    import markdown
    import yaml
    from playwright.async_api import async_playwright, Page
except ImportError as e:
    print(f"缺少依赖: {e}")
    print("请运行: pip install markdown pyyaml playwright && playwright install chromium")
    sys.exit(1)


# 获取脚本所在目录（assets 与本脚本同在 redbeacon 包内）
SCRIPT_DIR = Path(__file__).parent
ASSETS_DIR = SCRIPT_DIR / "assets"

# 设计好的命名主题（CSS 在 assets/themes/，由上游精修，覆盖 card.html 的基础样式）
VALID_THEMES = ["default", "botanical", "professional", "retro",
                "sketch", "terminal", "neo-brutalism", "playful-geometric",
                "macaron", "inkwash", "latte", "skyblue",
                "lavender", "midnight-gold", "cyber", "morandi"]


# 封面配色：主题 → (内层面板底色, 标题色, 副标题/正文色)。封面外框统一中性灰，与正文卡一致。
THEME_COVER = {
    "default":           ("#ffffff", "#6366f1", "#475569"),
    "botanical":         ("#f9faf6", "#4a7c59", "#2d3b36"),
    "professional":      ("#ffffff", "#2563eb", "#1a202c"),
    "retro":             ("#fdf6e3", "#d35400", "#5c4033"),
    "sketch":            ("#fffef9", "#e74c3c", "#333333"),
    "terminal":          ("#0d1117", "#39d353", "#c9d1d9"),
    "neo-brutalism":     ("#fffdf5", "#ff4757", "#1a1a1a"),
    "playful-geometric": ("#fffdf5", "#7c3aed", "#1e293b"),
    "macaron":           ("#fff6f9", "#e8849b", "#6b5b66"),
    "inkwash":           ("#f6f3ea", "#b03a2e", "#2b2b2b"),
    "latte":             ("#f5efe6", "#a9744f", "#4a3f35"),
    "skyblue":           ("#f0f7ff", "#3b82f6", "#33475b"),
    "lavender":          ("#f7f5fc", "#8b6fc7", "#4a4458"),
    "midnight-gold":     ("#1c1f2e", "#d4af6a", "#e6e3da"),
    "cyber":             ("#14111f", "#00e5ff", "#dfe0f0"),
    "morandi":           ("#ece9e3", "#97a08f", "#57534d"),
}


def _load_asset(name: str) -> str:
    """读 assets 下的模板/样式文件；缺失返回空串（让调用方降级到内置 CSS）。"""
    try:
        return (ASSETS_DIR / name).read_text(encoding="utf-8")
    except Exception:
        return ""


def _load_theme_css(theme: str) -> str:
    """加载某主题的 CSS（覆盖层）。未知主题回落 default。"""
    if theme not in VALID_THEMES:
        theme = "default"
    return _load_asset(f"themes/{theme}.css")

# 卡片尺寸配置 (3:4 比例)
CARD_WIDTH = 1080
CARD_HEIGHT = 1440

# 内容区域安全高度（考虑 padding 和 margin）
# card-inner padding: 60px * 2 = 120px
# card-container padding: 50px * 2 = 100px  
# 页码区域: ~80px
# 安全边距: ~40px
SAFE_HEIGHT = CARD_HEIGHT - 120 - 100 - 80 - 40  # ~1100px

# 样式配置
STYLES = {
    "purple": {
        "name": "紫韵",
        "cover_bg": "linear-gradient(180deg, #3450E4 0%, #D266DA 100%)",
        "card_bg": "linear-gradient(135deg, #667eea 0%, #764ba2 100%)",
        "accent_color": "#6366f1",
    },
    "xiaohongshu": {
        "name": "小红书红",
        "cover_bg": "linear-gradient(180deg, #FF2442 0%, #FF6B81 100%)",
        "card_bg": "linear-gradient(135deg, #FF2442 0%, #FF6B81 100%)",
        "accent_color": "#FF2442",
    },
    "mint": {
        "name": "清新薄荷",
        "cover_bg": "linear-gradient(180deg, #43e97b 0%, #38f9d7 100%)",
        "card_bg": "linear-gradient(135deg, #43e97b 0%, #38f9d7 100%)",
        "accent_color": "#43e97b",
    },
    "sunset": {
        "name": "日落橙",
        "cover_bg": "linear-gradient(180deg, #fa709a 0%, #fee140 100%)",
        "card_bg": "linear-gradient(135deg, #fa709a 0%, #fee140 100%)",
        "accent_color": "#fa709a",
    },
    "ocean": {
        "name": "深海蓝",
        "cover_bg": "linear-gradient(180deg, #4facfe 0%, #00f2fe 100%)",
        "card_bg": "linear-gradient(135deg, #4facfe 0%, #00f2fe 100%)",
        "accent_color": "#4facfe",
    },
    "elegant": {
        "name": "优雅白",
        "cover_bg": "linear-gradient(180deg, #f5f5f5 0%, #e0e0e0 100%)",
        "card_bg": "linear-gradient(135deg, #f5f5f5 0%, #e8e8e8 100%)",
        "accent_color": "#333333",
        "text_light": "#555555",
    },
    "dark": {
        "name": "暗黑模式",
        "cover_bg": "linear-gradient(180deg, #1a1a2e 0%, #16213e 100%)",
        "card_bg": "linear-gradient(135deg, #1a1a2e 0%, #16213e 100%)",
        "accent_color": "#e94560",
    },
}


def parse_markdown_file(file_path: str) -> dict:
    """解析 Markdown 文件，提取 YAML 头部和正文内容"""
    with open(file_path, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # 解析 YAML 头部
    yaml_pattern = r'^---\s*\n(.*?)\n---\s*\n'
    yaml_match = re.match(yaml_pattern, content, re.DOTALL)
    
    metadata = {}
    body = content
    
    if yaml_match:
        try:
            metadata = yaml.safe_load(yaml_match.group(1)) or {}
        except yaml.YAMLError:
            metadata = {}
        body = content[yaml_match.end():]
    
    return {
        'metadata': metadata,
        'body': body.strip()
    }


def split_content_by_separator(body: str) -> list:
    """按照 --- 分隔符拆分正文为多张卡片内容"""
    parts = re.split(r'\n---+\n', body)
    return [part.strip() for part in parts if part.strip()]


def estimate_content_height(content: str) -> int:
    """预估内容高度（基于字数和元素类型）"""
    lines = content.split('\n')
    total_height = 0
    
    for line in lines:
        line = line.strip()
        if not line:
            total_height += 20  # 空行
            continue
            
        # 标题
        if line.startswith('# '):
            total_height += 130  # h1: font-size 72 + margin
        elif line.startswith('## '):
            total_height += 110  # h2
        elif line.startswith('### '):
            total_height += 90   # h3
        # 代码块
        elif line.startswith('```'):
            total_height += 80   # 代码块起始/结束
        # 列表
        elif line.startswith(('- ', '* ', '+ ')):
            total_height += 85   # li: line-height ~1.6, font-size 42
        # 引用
        elif line.startswith('>'):
            total_height += 100  # blockquote padding
        # 图片
        elif line.startswith('!['):
            total_height += 300  # 图片高度估计
        # 普通段落
        else:
            # 估算字数
            char_count = len(line)
            # 一行约25-30个中文字，行高1.7，字体42px
            lines_needed = max(1, char_count / 28)
            total_height += int(lines_needed * 42 * 1.7) + 35  # + margin-bottom
    
    return total_height


def smart_split_content(content: str, max_height: int = SAFE_HEIGHT) -> List[str]:
    """
    智能拆分内容到多张卡片
    基于预估高度进行拆分，尽量保持段落完整
    """
    # 首先尝试识别内容块（以标题或空行分隔）
    blocks = []
    current_block = []
    
    lines = content.split('\n')
    i = 0
    while i < len(lines):
        line = lines[i]
        
        # 新标题开始新块（除非是第一个）
        if line.strip().startswith('#') and current_block:
            blocks.append('\n'.join(current_block))
            current_block = [line]
        # 分隔线
        elif line.strip() == '---':
            if current_block:
                blocks.append('\n'.join(current_block))
                current_block = []
        else:
            current_block.append(line)
        
        i += 1
    
    if current_block:
        blocks.append('\n'.join(current_block))
    
    # 如果没有明显的块边界，按段落拆分
    if len(blocks) <= 1:
        blocks = [b for b in content.split('\n\n') if b.strip()]
    
    # 均匀分页：先估总高算出需要几张卡，再按"每张目标高度"分布，
    # 而不是贪心塞满前几张、把零头甩到末页（那正是末页空荡的根因）。
    import math as _math
    block_heights = [estimate_content_height(b) for b in blocks]
    total_h = sum(block_heights)
    n_cards = max(1, _math.ceil(total_h / max_height))
    target_h = total_h / n_cards if n_cards else max_height

    cards = []
    current_card = []
    current_height = 0

    for block, block_height in zip(blocks, block_heights):
        # 单块就超过整卡：先收掉当前卡，再把大块按行拆
        if block_height > max_height:
            if current_card:
                cards.append('\n\n'.join(current_card))
                current_card = []
                current_height = 0

            lines = block.split('\n')
            sub_block = []
            sub_height = 0
            for line in lines:
                line_height = estimate_content_height(line)
                if sub_height + line_height > max_height and sub_block:
                    cards.append('\n'.join(sub_block))
                    sub_block = [line]
                    sub_height = line_height
                else:
                    sub_block.append(line)
                    sub_height += line_height
            if sub_block:
                cards.append('\n'.join(sub_block))

        # 当前卡已到"均匀目标"就翻页（每张 ≤ target ≤ 整卡上限，自然均衡）
        elif current_card and current_height + block_height > target_h:
            cards.append('\n\n'.join(current_card))
            current_card = [block]
            current_height = block_height

        else:
            current_card.append(block)
            current_height += block_height

    # 保存最后一个卡片
    if current_card:
        cards.append('\n\n'.join(current_card))

    # 后处理：合并非末尾的瘦卡片，避免中间出现几乎空白的页面
    # 末尾卡片内容少是可以接受的，中间卡片不行
    MIN_FILL = max_height // 3  # ≈367px，约 4 行正文
    i = 0
    while i < len(cards) - 1:  # 不处理最后一张
        if estimate_content_height(cards[i]) < MIN_FILL:
            # 优先向前合并（内容语义上更连贯）
            if i > 0:
                merged = cards[i - 1] + '\n\n' + cards[i]
                if estimate_content_height(merged) <= max_height:
                    cards[i - 1] = merged
                    cards.pop(i)
                    i = max(0, i - 1)
                    continue
            # 向前不行则向后合并
            merged = cards[i] + '\n\n' + cards[i + 1]
            if estimate_content_height(merged) <= max_height:
                cards[i] = merged
                cards.pop(i + 1)
                continue  # 重新检查当前位置
        i += 1

    # 末尾瘦卡也并回前一张：避免最后一页只有一两行（居中后仍显空）
    if len(cards) >= 2 and estimate_content_height(cards[-1]) < MIN_FILL:
        merged = cards[-2] + '\n\n' + cards[-1]
        if estimate_content_height(merged) <= max_height:
            cards[-2] = merged
            cards.pop()

    return cards if cards else [content]


def balance_thin_cards(cards: List[str], max_height: int = SAFE_HEIGHT) -> List[str]:
    """全局兜底：跨内容块合并"中间的瘦卡"，让中间页都填满；最后一页内容少可接受。

    smart_split 的均匀分布/合并只在单个内容块内生效；当正文被 `---`/小标题切成多个块、
    其中某个短块单独成卡时，就会在中间出现一张几乎空白的卡。这里在所有卡切完后再全局扫一遍。
    """
    if len(cards) <= 1:
        return cards
    MIN_FILL = max_height // 3   # 低于约 1/3 卡高（≈4 行）视为"瘦卡"
    i = 0
    while i < len(cards) - 1:     # 不动最后一张（末页允许少）
        if estimate_content_height(cards[i]) < MIN_FILL:
            # 优先并入前一张（语义更连贯），并后不超卡高才并
            if i > 0:
                merged = cards[i - 1] + '\n\n' + cards[i]
                if estimate_content_height(merged) <= max_height:
                    cards[i - 1] = merged
                    cards.pop(i)
                    i = max(0, i - 1)
                    continue
            merged = cards[i] + '\n\n' + cards[i + 1]
            if estimate_content_height(merged) <= max_height:
                cards[i] = merged
                cards.pop(i + 1)
                continue
        i += 1

    # 第二轮兜底：合并并不掉的中间瘦卡（两边都接近满，合进去会超高）→ 从前一张「匀几行」过来填，
    # 让两张都不至于太空/太满。只动中间卡，末页允许少。
    MIN_FILL = max_height // 3
    i = 1
    while i < len(cards) - 1:
        if estimate_content_height(cards[i]) < MIN_FILL:
            prev_lines = cards[i - 1].split('\n')
            thin = cards[i]
            moved = False
            # 从前一张末尾逐行下移到瘦卡开头，直到瘦卡填够、或前一张不能再瘦
            while estimate_content_height(thin) < MIN_FILL and len(prev_lines) > 1:
                cand = prev_lines[-1]
                if estimate_content_height('\n'.join(prev_lines[:-1])) < MIN_FILL:
                    break  # 别把前一张也搞瘦
                thin = cand + '\n' + thin
                prev_lines = prev_lines[:-1]
                moved = True
            if moved:
                cards[i - 1] = '\n'.join(prev_lines)
                cards[i] = thin
        i += 1
    return cards


def convert_markdown_to_html(md_content: str) -> str:
    """将 Markdown 转换为 HTML（标签用 class，由主题 CSS 着色）。"""

    # 处理 tags（以 # 开头的标签）
    tags_pattern = r'((?:#[\w\u4e00-\u9fa5]+\s*)+)$'
    tags_match = re.search(tags_pattern, md_content, re.MULTILINE)
    tags_html = ""
    
    if tags_match:
        tags_str = tags_match.group(1)
        md_content = md_content[:tags_match.start()].strip()
        tags = re.findall(r'#([\w\u4e00-\u9fa5]+)', tags_str)
        if tags:
            tags_html = '<div class="tags-container">'
            for tag in tags:
                tags_html += f'<span class="tag">#{tag}</span>'
            tags_html += '</div>'
    
    # 有序列表起始号：跨卡片拆分后续页要接着原编号，不能从 1 重来
    #   读源 markdown 里第一条有序项的数字 N，渲染时让自定义计数器从 N 起
    first_ol = re.search(r'^\s*(\d+)\.\s', md_content, re.MULTILINE)
    ol_start = int(first_ol.group(1)) if first_ol else 1

    # 转换 Markdown 为 HTML
    html = markdown.markdown(
        md_content,
        extensions=['extra', 'codehilite', 'tables', 'nl2br']
    )

    # 用原生 start 属性让续页有序列表接着原编号（主题 ::marker 会沿用）
    if ol_start != 1:
        html = re.sub(r'<ol(\s[^>]*)?>', f'<ol start="{ol_start}">', html, count=1)

    return html + tags_html


def generate_cover_html(metadata: dict, style_key: str = "default") -> str:
    """生成封面 HTML（用 cover.html 模板，长标题自动缩小字号）。"""
    emoji = metadata.get('emoji', '📝')
    title = metadata.get('title', '标题')
    subtitle = metadata.get('subtitle', '')

    title_len = len(title)
    if title_len <= 6:
        title_size = 150
    elif title_len <= 10:
        title_size = 130
    elif title_len <= 18:
        title_size = 100
    elif title_len <= 30:
        title_size = 80
    else:
        title_size = 60

    tpl = _load_asset("cover.html")
    if not tpl:
        return f"<html><body><h1>{title}</h1><p>{subtitle}</p></body></html>"
    # 封面按主题上色：内层面板=主题底色，标题=主题主色，强调条=主色，副标题=主题正文色；外框统一中性灰
    inner_bg, title_color, sub_color = THEME_COVER.get(style_key, THEME_COVER["default"])
    # emoji 徽标底：浅色主题用深色微透明，暗色主题用浅色微透明
    is_dark = style_key in ("terminal", "cyber", "midnight-gold")
    badge_bg = "rgba(255,255,255,0.08)" if is_dark else "rgba(0,0,0,0.05)"
    # 副标题为空时隐藏（连同上间距），避免标题下吊着一段空白
    sub_css = f".cover-subtitle{{color:{sub_color} !important;}}" if subtitle.strip() \
        else ".cover-subtitle{display:none !important;}"
    override = (
        "<style>"
        ".cover-container{background:linear-gradient(180deg,#f3f3f3 0%,#f9f9f9 100%);}"
        f".cover-inner{{background:{inner_bg};}}"
        f".cover-emoji{{background:{badge_bg} !important;}}"
        f".cover-title{{font-size:{title_size}px !important;"
        f"background:none !important;-webkit-text-fill-color:{title_color} !important;color:{title_color} !important;}}"
        f".cover-bar{{background:{title_color} !important;}}"
        f"{sub_css}"
        "</style>"
    )
    html = tpl.replace("</head>", override + "</head>")
    return (html.replace("{{EMOJI}}", emoji)
                .replace("{{TITLE}}", title)
                .replace("{{SUBTITLE}}", subtitle))


def generate_card_html(content: str, page_number: int = 1, total_pages: int = 1,
                       style_key: str = "default") -> str:
    """正文卡片 HTML：card.html 模板 + 主题 CSS 覆盖 + 垂直居中。"""
    html_content = convert_markdown_to_html(content)
    page_text = f"{page_number}/{total_pages}" if total_pages > 1 else ""

    tpl = _load_asset("card.html")
    if not tpl:
        return f"<html><body><div class='card-content'>{html_content}</div></body></html>"

    theme_css = _load_theme_css(style_key)
    # 主题 CSS 覆盖基础样式；再叠加本地优化：
    #   1) 外框用中性灰（避免紫色边框跳主题） 2) 内容垂直居中 3) 页码中性灰
    override = (
        "<style>\n" + theme_css + "\n"
        ".card-container{background:linear-gradient(180deg,#f3f3f3 0%,#f9f9f9 100%);}\n"
        ".card-inner{display:flex;flex-direction:column;justify-content:center;}\n"
        ".page-number{color:rgba(0,0,0,0.30);}\n"
        # 清掉基础模板 .tag 的渐变底图，让各主题自己的标签纯色生效
        ".tag{background-image:none;}\n"
        "</style>"
    )
    html = tpl.replace("</head>", override + "</head>")
    return (html.replace("{{CONTENT}}", html_content)
                .replace("{{PAGE_NUMBER}}", page_text))


async def measure_content_height(page: Page, html_content: str) -> int:
    """使用 Playwright 测量实际内容高度"""
    await page.set_content(html_content, wait_until='networkidle')
    await page.wait_for_timeout(300)  # 等待字体渲染
    
    height = await page.evaluate('''() => {
        const inner = document.querySelector('.card-inner');
        if (inner) {
            return inner.scrollHeight;
        }
        const container = document.querySelector('.card-container');
        return container ? container.scrollHeight : document.body.scrollHeight;
    }''')
    
    return height


async def render_html_to_image(html_content: str, output_path: str, 
                                width: int = CARD_WIDTH, height: int = CARD_HEIGHT):
    """使用 Playwright 将 HTML 渲染为图片"""
    async with async_playwright() as p:
        browser = await p.chromium.launch()
        page = await browser.new_page(viewport={'width': width, 'height': height})
        
        try:
            await page.set_content(html_content, wait_until='networkidle')
            await page.wait_for_timeout(300)
            
            # 截图固定尺寸
            await page.screenshot(
                path=output_path,
                clip={'x': 0, 'y': 0, 'width': width, 'height': height},
                type='png'
            )
            
            print(f"  ✅ 已生成: {output_path}")
            
        finally:
            await browser.close()


async def process_and_render_cards(card_contents: List[str], output_dir: str, 
                                   style_key: str) -> List[str]:
    """
    处理卡片内容，检测高度并自动分页，然后渲染
    返回最终生成的所有卡片文件路径
    """
    async with async_playwright() as p:
        browser = await p.chromium.launch()
        page = await browser.new_page(viewport={'width': CARD_WIDTH, 'height': CARD_HEIGHT})
        
        all_cards = []

        # 全局分页：把按 `---` 切出的内容块先拼回一个整流，再统一智能分页。
        # 这样均匀分布在整篇生效（每张≈等高、只末张可少），避免某个短块单独成卡 → 中间留大白。
        merged_body = '\n\n'.join(c for c in card_contents if c.strip())
        contents_to_process = [merged_body] if merged_body.strip() else card_contents

        try:
            for content in contents_to_process:
                # 预估内容高度
                estimated_height = estimate_content_height(content)

                # 如果预估高度超过安全高度，尝试拆分
                if estimated_height > SAFE_HEIGHT:
                    split_contents = smart_split_content(content, SAFE_HEIGHT)
                else:
                    split_contents = [content]
                
                # 验证每个拆分后的内容
                for split_content in split_contents:
                    # 生成临时 HTML 测量
                    temp_html = generate_card_html(split_content, 1, 1, style_key)
                    actual_height = await measure_content_height(page, temp_html)
                    
                    # 如果仍然超出，按行再拆——但要「真实高度均分」，不要贪心填满前几张、把余量甩成一张瘦卡。
                    # 先按真实高度算需要几张、每张奔着均值 target 去填；这样中间页都接近等高、只末页可少。
                    hard_cap = CARD_HEIGHT - 100
                    if actual_height > hard_cap:
                        import math as _math
                        n_sub = max(2, _math.ceil(actual_height / hard_cap))
                        target = actual_height / n_sub   # 均分目标高度（≤ hard_cap）
                        lines = split_content.split('\n')
                        sub_contents = []
                        sub_lines = []
                        for line in lines:
                            test_lines = sub_lines + [line]
                            test_html = generate_card_html('\n'.join(test_lines), 1, 1, style_key)
                            test_height = await measure_content_height(page, test_html)
                            # 已到均分目标就翻页（但若还没到最后一张的份额、且没超硬上限，继续填，避免拆太碎）
                            over_target = test_height > target and sub_lines and len(sub_contents) < n_sub - 1
                            over_cap = test_height > hard_cap and sub_lines
                            if over_target or over_cap:
                                sub_contents.append('\n'.join(sub_lines))
                                sub_lines = [line]
                            else:
                                sub_lines = test_lines
                        if sub_lines:
                            sub_contents.append('\n'.join(sub_lines))
                        all_cards.extend(sub_contents)
                    else:
                        all_cards.append(split_content)
        
        finally:
            await browser.close()

    # 全局兜底：跨内容块把"中间的瘦卡"并掉，中间页不留大白（末页可少）
    all_cards = balance_thin_cards(all_cards, SAFE_HEIGHT)
    return all_cards


async def render_markdown_to_cards(md_file: str, output_dir: str, style_key: str = "default"):
    """主渲染函数：将 Markdown 文件渲染为多张卡片图片"""
    # random 在此一次性定下，保证整篇所有卡片同一主题
    if style_key == "random":
        import random as _r
        style_key = _r.choice(VALID_THEMES)
    if style_key not in VALID_THEMES:
        style_key = "default"
    print(f"\n🎨 开始渲染: {md_file}")
    print(f"🎨 使用主题: {style_key}")

    # 确保输出目录存在
    os.makedirs(output_dir, exist_ok=True)
    
    # 解析 Markdown 文件
    data = parse_markdown_file(md_file)
    metadata = data['metadata']
    body = data['body']
    
    # 分割正文内容（基于用户手动分隔符）
    card_contents = split_content_by_separator(body)
    print(f"  📄 检测到 {len(card_contents)} 个内容块")
    
    # 处理内容，智能分页
    print("  🔍 分析内容高度并智能分页...")
    processed_cards = await process_and_render_cards(card_contents, output_dir, style_key)
    total_cards = len(processed_cards)
    print(f"  📄 将生成 {total_cards} 张卡片")
    
    # 生成封面
    if metadata.get('emoji') or metadata.get('title'):
        print("  📷 生成封面...")
        cover_html = generate_cover_html(metadata, style_key)
        cover_path = os.path.join(output_dir, 'cover.png')
        await render_html_to_image(cover_html, cover_path)
    
    # 生成正文卡片
    async with async_playwright() as p:
        browser = await p.chromium.launch()
        page = await browser.new_page(viewport={'width': CARD_WIDTH, 'height': CARD_HEIGHT})
        
        try:
            for i, content in enumerate(processed_cards, 1):
                print(f"  📷 生成卡片 {i}/{total_cards}...")
                card_html = generate_card_html(content, i, total_cards, style_key)
                card_path = os.path.join(output_dir, f'card_{i}.png')
                
                await page.set_content(card_html, wait_until='networkidle')
                await page.wait_for_timeout(300)
                
                await page.screenshot(
                    path=card_path,
                    clip={'x': 0, 'y': 0, 'width': CARD_WIDTH, 'height': CARD_HEIGHT},
                    type='png'
                )
                print(f"  ✅ 已生成: {card_path}")
        
        finally:
            await browser.close()
    
    print(f"\n✨ 渲染完成！共生成 {total_cards} 张卡片，保存到: {output_dir}")
    return total_cards


def list_styles():
    """列出所有可用主题"""
    print("\n📋 可用主题列表：")
    print("-" * 40)
    for key in VALID_THEMES + ["random"]:
        print(f"  {key}")
    print("-" * 40)


def main():
    parser = argparse.ArgumentParser(
        description='将 Markdown 文件渲染为小红书风格的图片卡片（智能分页版）',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog='''
示例:
  python render_xhs_v2.py note.md
  python render_xhs_v2.py note.md -o ./output --style xiaohongshu
  python render_xhs_v2.py --list-styles
        '''
    )
    parser.add_argument(
        'markdown_file',
        nargs='?',
        help='Markdown 文件路径'
    )
    parser.add_argument(
        '--output-dir', '-o',
        default=os.getcwd(),
        help='输出目录（默认为当前工作目录）'
    )
    parser.add_argument(
        '--style', '-s',
        default='default',
        choices=VALID_THEMES + ['random'],
        help='主题（默认: default）'
    )
    parser.add_argument(
        '--list-styles',
        action='store_true',
        help='列出所有可用样式'
    )
    
    args = parser.parse_args()
    
    if args.list_styles:
        list_styles()
        return
    
    if not args.markdown_file:
        parser.print_help()
        sys.exit(1)
    
    if not os.path.exists(args.markdown_file):
        print(f"❌ 错误: 文件不存在 - {args.markdown_file}")
        sys.exit(1)
    
    asyncio.run(render_markdown_to_cards(args.markdown_file, args.output_dir, args.style))


if __name__ == '__main__':
    main()
