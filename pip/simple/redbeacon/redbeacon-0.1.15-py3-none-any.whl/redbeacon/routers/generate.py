"""generate: 取选题 → AI 生成文案/图片 → 入库（阻塞）。

支持：
  - 单账号单篇（默认，兼容旧 shape {"ok":true,"content_id":N}）
  - --count N        连续生成 N 篇（每篇取下一个未用选题）
  - --all-accounts   对所有账号各生成（与 --count 叠加）
"""
from __future__ import annotations

import json
import sys

from redbeacon import database
from redbeacon.utils.logger import get_logger
from ._runtime import out, err

log = get_logger("router.generate")


def _resolve_account_ids(args) -> list[int]:
    if getattr(args, "all_accounts", False):
        with database.cursor() as c:
            ids = [r["id"] for r in c.execute("SELECT id FROM account ORDER BY id").fetchall()]
        if not ids:
            err("没有任何账号", next="redbeacon accounts create")
        return ids
    if not getattr(args, "account_id", None):
        err("请用 --account-id 指定账号，或加 --all-accounts 对所有账号生成")
    return [args.account_id]


def dispatch(args) -> None:
    from redbeacon.tasks.generate import run_generate

    account_ids = _resolve_account_ids(args)
    count = max(1, getattr(args, "count", 1) or 1)
    topic = getattr(args, "topic", None)

    if topic and (count > 1 or len(account_ids) > 1):
        err("--topic 只能用于单账号单篇；批量生成（--count>1 / --all-accounts）请从选题库取题")

    def _progress(step: int, data: dict):
        print(json.dumps({"progress": step, **data}, ensure_ascii=False), file=sys.stderr)
        sys.stderr.flush()

    # 单账号单篇：保留旧返回 shape，skill 端不受影响
    if len(account_ids) == 1 and count == 1:
        try:
            content_id = run_generate(
                account_id=account_ids[0],
                topic_override=topic,
                content_type_override=args.content_type,
                image_mode=args.image_mode,
                pillar_override=args.pillar,
                user_idea=getattr(args, "idea", None),
                progress_cb=_progress,
            )
            out({"ok": True, "content_id": content_id})
        except Exception as e:
            log.error(f"generate 失败：{e}", exc_info=True)
            err(f"生成失败：{e}")
        return

    # 批量：逐账号逐篇，单篇失败不打断整体；某账号选题耗尽则跳到下一个账号
    results: list[dict] = []
    for aid in account_ids:
        for i in range(count):
            try:
                cid = run_generate(
                    account_id=aid,
                    topic_override=None,
                    content_type_override=args.content_type,
                    image_mode=args.image_mode,
                    pillar_override=args.pillar,
                    progress_cb=_progress,
                )
                results.append({"account_id": aid, "content_id": cid})
            except Exception as e:
                msg = str(e)
                log.warning(f"generate 账号 {aid} 第 {i+1} 篇失败：{msg}")
                results.append({"account_id": aid, "error": msg})
                if "选题" in msg:  # 选题耗尽：该账号不再继续，转下一个
                    break
    ok_n = sum(1 for r in results if "content_id" in r)
    out({"ok": ok_n > 0, "generated": ok_n, "results": results})
