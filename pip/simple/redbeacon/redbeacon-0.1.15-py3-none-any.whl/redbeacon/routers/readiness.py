"""readiness: 集中判定系统配置阶段，供 /redbeacon skill 路由用。

输出：
  {
    "stage": "stage1" | "stage2" | "stage3" | "stage4" | "stage5" | "ready",
    "checks": {
      "ai_ok": bool,
      "feishu_ok": bool,       // 凭证可用；可选 → 不阻断 ready
      "has_account": bool,
      "has_login": bool,
      "niche_ok": bool,
    },
    "reasons": [str, ...],     // 人类可读的"缺什么"列表
    "next": "...",             // 下一步建议执行的 cli 命令
    "feishu_required": false,  // 飞书可选
  }

stage 含义（onboarding 链路：配置 → 账号 → 登录 → 飞书绑表 → 定位）：
  stage1 — AI 或飞书凭证未配置 → /config（AI + 飞书全局凭证都在配置阶段搞定）
  stage2 — 没有账号 → cli accounts create
  stage3 — 账号未登录 → cli login start（建号后先扫码让账号落地）
  stage4 — 账号未绑飞书表 → cli feishu setup（登录后先绑表，审核/发布数据源）
  stage5 — 账号未做定位 → /定位 或 cli strategy patch（绑表后做定位+选题）
  ready  — 全部就绪；定位+选题之后还有「面板调样式 → 反馈迭代 → 二次确认」的收尾，由 /定位 skill 负责
"""
from __future__ import annotations

import json

from redbeacon import config as cfg
from redbeacon.config_keys import (
    CK_AI_API_KEY, CK_AI_BASE_URL, CK_AI_MODEL, CK_IMAGE_MODEL,
    CK_FEISHU_APP_ID, CK_FEISHU_APP_SECRET,
)
from redbeacon import database
from ._runtime import out


def dispatch(args=None) -> None:
    # 可选 --account-id：只看「这一个账号」的 onboarding 进度（用于多账号逐个开号，
    # 因为不带 id 时各项是「任一账号满足即 ok」的全局聚合，账号1配好后加账号2不会被自动发现）。
    target_id = getattr(args, "account_id", None) if args is not None else None

    ai_ok = bool(
        cfg.get(CK_AI_BASE_URL).strip()
        and cfg.get(CK_AI_API_KEY).strip()
        and cfg.get(CK_AI_MODEL).strip()
    )
    # 图片模型是生成的硬门槛（配图必需），并入 AI 配置阶段一起判定
    image_ok = bool(cfg.get(CK_IMAGE_MODEL).strip())
    ai_ready = ai_ok and image_ok
    feishu_ok = bool(cfg.get(CK_FEISHU_APP_ID).strip() and cfg.get(CK_FEISHU_APP_SECRET).strip())

    with database.cursor() as c:
        accs = c.execute(
            "SELECT id, login_status, feishu_app_token, feishu_table_id FROM account ORDER BY id"
        ).fetchall()
        # 指定了账号就只判定这一个；不存在则按"无账号"处理（让上层去建/选号）
        if target_id is not None:
            accs = [a for a in accs if a["id"] == target_id]
        logged_acc_ids = [a["id"] for a in accs if a["login_status"] == "logged_in"]
        # 账号级飞书绑表：app_token + table_id 都有才算真能审/能发
        bound_acc_ids = [
            a["id"] for a in accs
            if (a["feishu_app_token"] or "").strip() and (a["feishu_table_id"] or "").strip()
        ]

        # 定位（niche）不依赖登录态，按账号本身判定——登录排在定位之前（先扫码落地再定位）
        niche_ok = False
        for a in accs:
            row = c.execute(
                "SELECT data FROM strategy WHERE account_id=? ORDER BY version DESC LIMIT 1",
                (a["id"],),
            ).fetchone()
            if not row:
                continue
            try:
                data = json.loads(row["data"] or "{}")
            except Exception:
                continue
            if (data.get("niche") or "").strip():
                niche_ok = True
                break

    has_account  = bool(accs)
    has_login    = bool(logged_acc_ids)
    feishu_bound = bool(bound_acc_ids)

    # 绑表提示用的账号：优先已登录但还没绑表的那个，否则第一个账号
    bind_aid = next((i for i in logged_acc_ids if i not in bound_acc_ids),
                    accs[0]["id"] if accs else None)

    reasons: list[str] = []
    if not ai_ok:        reasons.append("AI 服务未配置（缺 base_url / api_key / ai_model）")
    if not image_ok:     reasons.append("图片生成模型未配置（image_model 为空，配图必需）")
    if not feishu_ok:    reasons.append("飞书凭证未配置（审核面板与发布数据源都在飞书，必需）")
    if not has_account:  reasons.append("尚未创建账号")
    if not has_login:    reasons.append("账号未登录小红书")
    if feishu_ok and has_account and not feishu_bound:
        reasons.append("账号未绑定飞书多维表格（生成的内容无处审核 / 发布）")
    if not niche_ok and has_account: reasons.append("账号未做定位（strategy.niche 为空）")

    if   not ai_ready:              stage, nxt = "stage1", "redbeacon config set ai_api_key <KEY>"
    elif not feishu_ok:             stage, nxt = "stage1", "redbeacon config set feishu_app_id <ID>"
    elif not has_account:           stage, nxt = "stage2", "redbeacon accounts create"
    elif not has_login:             aid = accs[0]["id"]; stage, nxt = "stage3", f"redbeacon login start --account-id {aid}"
    elif not feishu_bound:          stage, nxt = "stage4", f"redbeacon feishu setup --account-id {bind_aid}"
    elif not niche_ok:              aid = accs[0]["id"]; stage, nxt = "stage5", f"redbeacon strategy patch --account-id {aid} --data '{{\"niche\": \"...\"}}'"
    else:                           stage, nxt = "ready", ""

    # 升级提示：缓存优先 + 每日一次紧超时刷新，失败静默，绝不阻塞就绪判定
    try:
        from redbeacon.services import updater
        update_info = updater.readiness_update_info()
    except Exception:
        update_info = None

    out({
        "stage": stage,
        "target_account": target_id,   # None=全局聚合判定；有值=只看这个账号的 onboarding 进度
        "checks": {
            "ai_ok": ai_ok,
            "image_ok": image_ok,
            "feishu_ok": feishu_ok,
            "feishu_bound": feishu_bound,
            "has_account": has_account,
            "has_login": has_login,
            "niche_ok": niche_ok,
        },
        "reasons": reasons,
        "next": nxt,
        "feishu_required": True,
        "update": update_info,
    })
