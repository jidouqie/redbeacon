"""accounts list / get / create / delete / patch"""
from __future__ import annotations

import json

from redbeacon import database
from redbeacon.services import xhs, license
from ._runtime import out, err, now_iso, update_account, account_row


_DEFAULT_IMG_PROMPT = (
    "小红书封面图，{niche}领域，主题：{title}，"
    "色彩明亮，竖版3:4比例，小红书风格，高质量精美"
)
_DEFAULT_IMG_TEMPLATE_ITEMS = json.dumps([{
    "image_path": "",
    "prompt": (
        "小红书封面，主题关键词突出，色彩明亮饱和，构图精美，"
        "竖版3:4比例，高质量细腻，无文字叠加，背景简洁，主体清晰"
    ),
}], ensure_ascii=False)

_PATCH_ALLOWED = {
    "display_name", "proxy", "feishu_app_token", "feishu_table_id",
    "feishu_user_id", "auto_generate_enabled",
    "generate_schedule_json",
}


def dispatch(args) -> None:
    if args.sub == "list":
        with database.cursor() as c:
            rows = c.execute("SELECT * FROM account ORDER BY id").fetchall()
        result = []
        for r in rows:
            d = dict(r)
            d["session_running"] = xhs.session.is_running(r["id"])
            result.append(d)
        out(result)

    elif args.sub == "get":
        out(account_row(args.account_id))

    elif args.sub == "create":
        with database.cursor(commit=True) as c:
            count = c.execute("SELECT COUNT(*) FROM account").fetchone()[0]
            limit = license.max_accounts()
            if count >= limit:
                if license.is_unlocked():
                    err(f"账号数量已达上限 {limit}", kind="ACCOUNT_LIMIT")
                err(
                    "免费版仅支持单账号；多账号矩阵为付费能力，需解锁后使用",
                    next="redbeacon license activate <解锁码>",
                    kind="ACCOUNT_LIMIT",
                )
            proxy = getattr(args, "proxy", None) or None
            now = now_iso()
            c.execute(
                "INSERT INTO account (proxy, created_at, updated_at) VALUES (?, ?, ?)",
                (proxy, now, now),
            )
            account_id = c.execute("SELECT last_insert_rowid()").fetchone()[0]
            # 备注名：用户给了就用；没给则留「{id}号小红书」做兜底（编号=id，备注后续可起或按定位自动生成）
            name = (getattr(args, "name", None) or "").strip() or f"{account_id}号小红书"
            c.execute("UPDATE account SET display_name=? WHERE id=?",
                      (name, account_id))
            c.execute(
                "INSERT OR IGNORE INTO image_strategy "
                "(account_id, mode, prompt_template, card_theme, reference_images, ai_model, updated_at) "
                "VALUES (?, 'cards', ?, 'default', '[]', NULL, ?)",
                (account_id, _DEFAULT_IMG_PROMPT, now),
            )
            c.execute(
                "INSERT INTO image_template (account_id, name, is_active, items, created_at, updated_at) "
                "VALUES (?, '默认文生图', 0, ?, ?, ?)",
                (account_id, _DEFAULT_IMG_TEMPLATE_ITEMS, now, now),
            )
            row = c.execute("SELECT * FROM account WHERE id=?", (account_id,)).fetchone()
        d = dict(row)
        d["session_running"] = False
        out(d)

    elif args.sub == "delete":
        xhs.session.stop(args.account_id)
        with database.cursor(commit=True) as c:
            for tbl in ("publish_log", "content_queue", "prompt", "strategy",
                        "topic", "content_type", "image_template", "image_strategy"):
                c.execute(f"DELETE FROM {tbl} WHERE account_id=?", (args.account_id,))
            c.execute("DELETE FROM account WHERE id=?", (args.account_id,))
        out({"ok": True})

    elif args.sub == "patch":
        data = json.loads(args.data)
        updates = {k: v for k, v in data.items() if k in _PATCH_ALLOWED}
        update_account(args.account_id, **updates)
        out(account_row(args.account_id))

    else:
        err(f"未知 accounts 子命令：{args.sub}")
