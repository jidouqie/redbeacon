"""strategy get / patch（账号定位）
       prompt-list / prompt-get / prompt-set / prompt-reset（文案预设：content_type.prompt_template）
       image-get / image-set（图片预设：image_strategy）

文案预设 = 每个内容类型(content_type)的提示词骨架；空字符串表示用内置默认 DEFAULT_PROMPT。
图片预设 = image_strategy 单行（mode / prompt_template / card_theme / ai_model / template_mode）。
"""
from __future__ import annotations

import json
import sys

from redbeacon import database
from ._runtime import out, err, now_iso, require_account


# image_strategy 允许通过 image-set 修改的字段（白名单）
_IMAGE_FIELDS = {"mode", "prompt_template", "card_theme", "ai_model",
                 "template_mode", "reference_images"}
_IMAGE_MODES = {"cards", "ai", "both"}


def dispatch(args) -> None:
    if args.sub == "get":
        _get(args)
    elif args.sub == "patch":
        _patch(args)
    elif args.sub == "prompt-list":
        _prompt_list(args)
    elif args.sub == "prompt-get":
        _prompt_get(args)
    elif args.sub == "prompt-set":
        _prompt_set(args)
    elif args.sub == "prompt-reset":
        _prompt_reset(args)
    elif args.sub == "image-get":
        _image_get(args)
    elif args.sub == "image-set":
        _image_set(args)
    elif args.sub == "image-ref-add":
        _image_ref_add(args)
    elif args.sub == "image-ref-list":
        _image_ref_list(args)
    elif args.sub == "image-ref-clear":
        _image_ref_clear(args)
    else:
        err(f"未知 strategy 子命令：{args.sub}")


# ── 账号定位 ──────────────────────────────────────────────────────────────────

def _get(args) -> None:
    with database.cursor() as c:
        row = c.execute(
            "SELECT * FROM strategy WHERE account_id=? ORDER BY version DESC LIMIT 1",
            (args.account_id,),
        ).fetchone()
    out(dict(row) if row else {})


def _patch(args) -> None:
    require_account(args.account_id)
    fields = json.loads(args.data)
    with database.cursor(commit=True) as c:
        row = c.execute(
            "SELECT id, data FROM strategy WHERE account_id=? ORDER BY version DESC LIMIT 1",
            (args.account_id,),
        ).fetchone()
        data: dict = {}
        if row:
            try:
                data = json.loads(row["data"])
            except Exception:
                pass
        data.update(fields)
        now = now_iso()
        if row is None:
            c.execute(
                "INSERT INTO strategy (account_id, version, data, niche, posting_freq, created_at, updated_at) "
                "VALUES (?, 1, ?, ?, ?, ?, ?)",
                (args.account_id, json.dumps(data, ensure_ascii=False),
                 data.get("niche", ""), data.get("posting_frequency", ""), now, now),
            )
        else:
            c.execute(
                "UPDATE strategy SET data=?, niche=?, posting_freq=?, updated_at=? WHERE id=?",
                (json.dumps(data, ensure_ascii=False),
                 data.get("niche", ""), data.get("posting_frequency", ""),
                 now, row["id"]),
            )
    out({"ok": True, "fields": list(fields.keys())})


# ── 文案预设（content_type.prompt_template）────────────────────────────────────

def _prompt_list(args) -> None:
    with database.cursor() as c:
        rows = c.execute(
            "SELECT id, name, prompt_template, is_active, sort_order "
            "FROM content_type WHERE account_id=? ORDER BY sort_order, id",
            (args.account_id,),
        ).fetchall()
    result = []
    for r in rows:
        d = dict(r)
        tpl = (d.get("prompt_template") or "").strip()
        d["using_default"] = (tpl == "")          # 空=用内置默认提示词
        d["preview"] = tpl[:80]
        del d["prompt_template"]
        result.append(d)
    out(result)


def _find_content_type(c, account_id: int, name: str):
    return c.execute(
        "SELECT * FROM content_type WHERE account_id=? AND name=?",
        (account_id, name),
    ).fetchone()


def _prompt_get(args) -> None:
    with database.cursor() as c:
        row = _find_content_type(c, args.account_id, args.type)
    if not row:
        err(f"内容类型不存在：{args.type}",
            next=f"redbeacon topics types --account-id {args.account_id}")
    d = dict(row)
    tpl = (d.get("prompt_template") or "")
    out({
        "name": d["name"],
        "prompt_template": tpl,
        "using_default": tpl.strip() == "",
    })


def _prompt_set(args) -> None:
    require_account(args.account_id)
    text = args.text if args.text is not None else sys.stdin.read()
    with database.cursor(commit=True) as c:
        row = _find_content_type(c, args.account_id, args.type)
        if not row:
            err(f"内容类型不存在：{args.type}",
                next=f"redbeacon topics types --account-id {args.account_id}")
        c.execute(
            "UPDATE content_type SET prompt_template=?, updated_at=? WHERE id=?",
            (text, now_iso(), row["id"]),
        )
    out({"ok": True, "name": args.type, "using_default": text.strip() == ""})


def _prompt_reset(args) -> None:
    require_account(args.account_id)
    with database.cursor(commit=True) as c:
        row = _find_content_type(c, args.account_id, args.type)
        if not row:
            err(f"内容类型不存在：{args.type}",
                next=f"redbeacon topics types --account-id {args.account_id}")
        c.execute(
            "UPDATE content_type SET prompt_template='', updated_at=? WHERE id=?",
            (now_iso(), row["id"]),
        )
    out({"ok": True, "name": args.type, "using_default": True})


# ── 图片预设（image_strategy + image_template 只读列出）────────────────────────

def _image_get(args) -> None:
    with database.cursor() as c:
        row = c.execute(
            "SELECT * FROM image_strategy WHERE account_id=?", (args.account_id,)
        ).fetchone()
        templates = c.execute(
            "SELECT id, name, is_active, items FROM image_template WHERE account_id=? ORDER BY id",
            (args.account_id,),
        ).fetchall()
    strat = dict(row) if row else {}
    tpls = []
    for t in templates:
        d = dict(t)
        try:
            d["item_count"] = len(json.loads(d.get("items") or "[]"))
        except Exception:
            d["item_count"] = 0
        del d["items"]
        tpls.append(d)
    out({"strategy": strat, "templates": tpls})


# ── 参考图落库（图生图素材：把用户给的图拷进数据目录，存固定路径）──────────────

def _ref_dir() -> "Path":
    """参考图存放目录：<data_dir>/ref_images/，随数据目录走、跨会话稳定。"""
    import os
    from pathlib import Path
    from redbeacon.utils.paths import default_data_dir
    data_dir = Path(os.environ.get("REDBEACON_DATA_DIR", str(default_data_dir()))).resolve()
    d = data_dir / "ref_images"
    d.mkdir(parents=True, exist_ok=True)
    return d


def _get_ref_list(c, account_id: int) -> list:
    row = c.execute("SELECT reference_images FROM image_strategy WHERE account_id=?",
                    (account_id,)).fetchone()
    if not row or not row["reference_images"]:
        return []
    try:
        v = json.loads(row["reference_images"])
        return v if isinstance(v, list) else []
    except Exception:
        return []


def _ensure_image_strategy(c, account_id: int) -> None:
    row = c.execute("SELECT account_id FROM image_strategy WHERE account_id=?",
                    (account_id,)).fetchone()
    if row is None:
        c.execute(
            "INSERT INTO image_strategy (account_id, mode, prompt_template, card_theme, "
            "reference_images, ai_model, updated_at) VALUES (?, 'cards', '', 'default', '[]', NULL, ?)",
            (account_id, now_iso()),
        )


def _image_ref_add(args) -> None:
    """把一张本地图片拷进数据目录，登记为该账号的图生图参考图。"""
    import shutil
    from pathlib import Path
    require_account(args.account_id)
    src = Path(args.file).expanduser()
    if not src.is_file():
        err(f"找不到图片文件：{args.file}", next="确认路径是否正确（可拖拽文件到终端获取路径）")
    ext = src.suffix.lower() if src.suffix.lower() in (".jpg", ".jpeg", ".png", ".webp") else ".jpg"
    dest = _ref_dir() / f"ref_{args.account_id}_{int(__import__('time').time()*1000)}{ext}"
    try:
        shutil.copyfile(src, dest)
    except Exception as e:
        err(f"参考图拷贝失败：{e}")
    with database.cursor(commit=True) as c:
        _ensure_image_strategy(c, args.account_id)
        refs = _get_ref_list(c, args.account_id)
        if getattr(args, "replace", False):
            refs = []
        refs.append(str(dest))
        c.execute("UPDATE image_strategy SET reference_images=?, updated_at=? WHERE account_id=?",
                  (json.dumps(refs, ensure_ascii=False), now_iso(), args.account_id))
    out({"ok": True, "stored": str(dest), "count": len(refs)})


def _image_ref_list(args) -> None:
    with database.cursor() as c:
        refs = _get_ref_list(c, args.account_id)
    out({"reference_images": refs, "count": len(refs)})


def _image_ref_clear(args) -> None:
    """清空参考图登记（默认连文件一起删，--keep-files 只清登记）。"""
    import os
    require_account(args.account_id)
    with database.cursor(commit=True) as c:
        refs = _get_ref_list(c, args.account_id)
        if not getattr(args, "keep_files", False):
            for p in refs:
                try:
                    if p and os.path.isfile(p):
                        os.remove(p)
                except Exception:
                    pass
        c.execute("UPDATE image_strategy SET reference_images='[]', updated_at=? WHERE account_id=?",
                  (now_iso(), args.account_id))
    out({"ok": True, "cleared": len(refs)})


def _image_set(args) -> None:
    require_account(args.account_id)
    fields = json.loads(args.data)
    bad = set(fields) - _IMAGE_FIELDS
    if bad:
        err(f"不支持的图片预设字段：{', '.join(sorted(bad))}",
            next="允许：" + ", ".join(sorted(_IMAGE_FIELDS)))
    if "mode" in fields and fields["mode"] not in _IMAGE_MODES:
        err(f"mode 取值非法：{fields['mode']}（只能 cards / ai / both）")
    if "reference_images" in fields and not isinstance(fields["reference_images"], str):
        fields["reference_images"] = json.dumps(fields["reference_images"], ensure_ascii=False)
    now = now_iso()
    with database.cursor(commit=True) as c:
        row = c.execute(
            "SELECT account_id FROM image_strategy WHERE account_id=?", (args.account_id,)
        ).fetchone()
        if row is None:
            c.execute(
                "INSERT INTO image_strategy (account_id, mode, prompt_template, card_theme, "
                "reference_images, ai_model, updated_at) VALUES (?, 'cards', '', 'default', '[]', NULL, ?)",
                (args.account_id, now),
            )
        sets = ", ".join(f"{k}=?" for k in fields)
        vals = list(fields.values()) + [now, args.account_id]
        c.execute(f"UPDATE image_strategy SET {sets}, updated_at=? WHERE account_id=?", vals)
        out_row = c.execute(
            "SELECT * FROM image_strategy WHERE account_id=?", (args.account_id,)
        ).fetchone()
    out({"ok": True, "strategy": dict(out_row), "fields": list(fields.keys())})
