"""所有 settings 表的 key 集中定义。

新增 key 必须在此声明（key 名、默认值、是否加密、说明）。
读取统一走 `cfg.get(CK_*)`，不再传字符串。
"""
from __future__ import annotations

from typing import NamedTuple

from redbeacon.utils.paths import default_data_dir


class Key(NamedTuple):
    name: str
    default: str
    encrypted: bool
    desc: str


# ── AI ────────────────────────────────────────────────────────────────────────
CK_AI_API_KEY  = Key("ai_api_key",  "", True,  "OpenAI 兼容 API Key（加密）")
CK_AI_BASE_URL = Key("ai_base_url", "https://api.openai.com/v1", False, "OpenAI 兼容 Base URL")
CK_AI_MODEL    = Key("ai_model",    "gpt-4o-mini", False, "文案生成默认模型")
CK_IMAGE_MODEL = Key("image_model", "", False, "图片生成默认模型")

# ── 飞书 ──────────────────────────────────────────────────────────────────────
CK_FEISHU_APP_ID     = Key("feishu_app_id",     "", False, "飞书应用 App ID")
CK_FEISHU_APP_SECRET = Key("feishu_app_secret", "", True,  "飞书应用 App Secret（加密）")
CK_FEISHU_USER_ID    = Key("feishu_user_id",    "", False, "默认通知接收 user ID（账号级覆盖此值）")
# 注：feishu_app_token / feishu_table_id 已迁移到 account 表，此处不再列出

# ── 发布全局开关 ──────────────────────────────────────────────────────────────
CK_PUBLISH_IS_ORIGINAL     = Key("publish_is_original",     "false",  False, "默认是否勾选原创声明")
CK_PUBLISH_IS_AI_GENERATED = Key("publish_is_ai_generated", "true",   False, "默认是否勾选 AI 生成声明")
CK_PUBLISH_VISIBILITY      = Key("publish_visibility",      "公开可见", False, "默认可见范围")

# ── 浏览器 / 代理 ─────────────────────────────────────────────────────────────
CK_BROWSER_VISIBLE    = Key("browser_visible",    "true",  False, "发布时浏览器可见（默认显示，便于用户看到自动化过程；设 false 则后台 headless）")
CK_PROXY_AUTO_ROTATE  = Key("proxy_auto_rotate",  "false", False, "每次发布前自动换 IP")
CK_PROXY_API_URL      = Key("proxy_api_url",      "",      False, "代理获取 API URL")
CK_PROXY_SPEED_TEST   = Key("proxy_speed_test",   "false", False, "代理 IP 测速过滤")

# ── 授权 / 解锁 ───────────────────────────────────────────────────────────────
# 解锁码公开可验证（绑机器码），不加密。校验逻辑见 services/license.py。
CK_LICENSE_KEY = Key("license_key", "", False, "多账号解锁码（绑定机器码，由云端发码系统签发）")

# ── 升级 ──────────────────────────────────────────────────────────────────────
# 版本清单 latest.json（含最新版本号 + 更新说明 + skill 文件清单）。
# 默认走 GitHub raw：发版只需 git push，无需部署官网/上传 OSS。
CK_UPDATE_MANIFEST_URL = Key("update_manifest_url", "https://raw.githubusercontent.com/jidouqie/redbeacon/main/latest.json", False, "版本清单 URL（升级检查用，默认 GitHub raw）")
# skill markdown 安装目录（个人 AI 助手的命令目录）。空 = 自动探测 ~/.claude/commands。
# install.sh 拷完 skill 后会把真实目录写进此键，供 redbeacon update 刷新用。
CK_SKILL_INSTALL_DIR = Key("skill_install_dir", "", False, "skill 命令目录（空=自动探测 ~/.claude/commands）")

# ── 路径 ──────────────────────────────────────────────────────────────────────
CK_DATA_DIR = Key("data_dir", str(default_data_dir()), False, "数据目录（被 REDBEACON_DATA_DIR 环境变量覆盖）")


ALL_KEYS: tuple[Key, ...] = (
    CK_AI_API_KEY, CK_AI_BASE_URL, CK_AI_MODEL, CK_IMAGE_MODEL,
    CK_FEISHU_APP_ID, CK_FEISHU_APP_SECRET, CK_FEISHU_USER_ID,
    CK_PUBLISH_IS_ORIGINAL, CK_PUBLISH_IS_AI_GENERATED, CK_PUBLISH_VISIBILITY,
    CK_BROWSER_VISIBLE, CK_PROXY_AUTO_ROTATE, CK_PROXY_API_URL, CK_PROXY_SPEED_TEST,
    CK_LICENSE_KEY, CK_UPDATE_MANIFEST_URL, CK_SKILL_INSTALL_DIR, CK_DATA_DIR,
)

ENCRYPTED_KEY_NAMES: frozenset[str] = frozenset(k.name for k in ALL_KEYS if k.encrypted)
