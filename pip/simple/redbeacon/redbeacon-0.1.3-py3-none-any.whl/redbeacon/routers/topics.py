"""topics list / add / batch / inspire / stats / reset / types / types-init"""
from __future__ import annotations

import json
import sys

from redbeacon import config as cfg
from redbeacon.config_keys import CK_AI_API_KEY, CK_AI_BASE_URL, CK_AI_MODEL
from redbeacon import database
from ._runtime import out, err, now_iso, require_account


def dispatch(args) -> None:
    if args.sub == "list":     _list(args)
    elif args.sub == "add":    _add(args)
    elif args.sub == "batch":  _batch(args)
    elif args.sub == "inspire": _inspire(args)
    elif args.sub == "stats":  _stats(args)
    elif args.sub == "reset":  _reset(args)
    elif args.sub == "types":  _types(args)
    elif args.sub == "types-init": _types_init(args)
    else:                      err(f"未知 topics 子命令：{args.sub}")


def _list(args) -> None:
    wheres = ["account_id=?"]
    params: list = [args.account_id]
    if args.type:
        wheres.append("content_type=?")
        params.append(args.type)
    if args.used is not None:
        wheres.append("is_used=?")
        params.append(args.used)
    where_sql = " AND ".join(wheres)
    with database.cursor() as c:
        rows = c.execute(
            f"SELECT * FROM topic WHERE {where_sql} ORDER BY is_used, id DESC LIMIT ? OFFSET ?",
            params + [args.limit, args.offset],
        ).fetchall()
    out([dict(r) for r in rows])


def _add(args) -> None:
    require_account(args.account_id)
    with database.cursor(commit=True) as c:
        c.execute(
            "INSERT INTO topic (account_id, content_type, content, created_at) VALUES (?, ?, ?, ?)",
            (args.account_id, args.type, args.content.strip(), now_iso()),
        )
        row = c.execute("SELECT * FROM topic WHERE rowid=last_insert_rowid()").fetchone()
    out(dict(row))


def _batch(args) -> None:
    require_account(args.account_id)
    text = args.text or sys.stdin.read()
    lines = [l.strip() for l in text.splitlines() if l.strip()]
    if not lines:
        out({"inserted": 0, "total": 0})
    now = now_iso()
    inserted = 0
    with database.cursor(commit=True) as c:
        for line in lines:
            exists = c.execute(
                "SELECT id FROM topic WHERE account_id=? AND content_type=? AND content=?",
                (args.account_id, args.type, line),
            ).fetchone()
            if not exists:
                c.execute(
                    "INSERT INTO topic (account_id, content_type, content, created_at) VALUES (?, ?, ?, ?)",
                    (args.account_id, args.type, line, now),
                )
                inserted += 1
    out({"inserted": inserted, "total": len(lines)})


def _inspire(args) -> None:
    require_account(args.account_id)
    import httpx
    from openai import OpenAI
    api_key  = cfg.get(CK_AI_API_KEY)
    base_url = cfg.get(CK_AI_BASE_URL)
    model    = cfg.get(CK_AI_MODEL)
    if not api_key:
        err("AI API Key 未配置", next="redbeacon config set ai_api_key <KEY>")
    with database.cursor() as c:
        row = c.execute(
            "SELECT data FROM strategy WHERE account_id=? ORDER BY version DESC LIMIT 1",
            (args.account_id,),
        ).fetchone()
    niche = "通用"
    if row:
        try:
            niche = json.loads(row["data"]).get("niche", "通用")
        except Exception:
            pass
    prompt = (
        f"你是一个{niche}领域的小红书内容策划专家。\n\n"
        f"用户有以下灵感：\n\"{args.text}\"\n\n"
        "请基于这个灵感，生成5个具体的小红书笔记选题标题。\n\n"
        "要求：\n"
        "- 每条选题都是完整的笔记标题，不超过25字\n"
        "- 有吸引力，适合小红书风格（口语化、有共鸣、可加数字）\n"
        f'- 与"{niche}"领域相关\n'
        "- 5条选题要有差异性，覆盖不同角度\n\n"
        "只输出5条标题，每行一条，不要编号，不要任何额外说明。"
    )
    try:
        client = OpenAI(
            api_key=api_key, base_url=base_url,
            http_client=httpx.Client(trust_env=False, timeout=30),
        )
        resp = client.chat.completions.create(
            model=model,
            messages=[{"role": "user", "content": prompt}],
            temperature=0.9,
            max_tokens=500,
        )
        raw = resp.choices[0].message.content.strip()
        options = [l.strip() for l in raw.splitlines() if l.strip()][:6]
        out({"options": options})
    except Exception as e:
        err(f"AI 生成失败：{e}")


def _stats(args) -> None:
    with database.cursor() as c:
        total  = c.execute("SELECT COUNT(*) FROM topic WHERE account_id=?", (args.account_id,)).fetchone()[0]
        unused = c.execute("SELECT COUNT(*) FROM topic WHERE account_id=? AND is_used=0",
                           (args.account_id,)).fetchone()[0]
        by_type = c.execute(
            "SELECT content_type, COUNT(*) as total, SUM(CASE WHEN is_used=0 THEN 1 ELSE 0 END) as unused "
            "FROM topic WHERE account_id=? GROUP BY content_type",
            (args.account_id,),
        ).fetchall()
    out({"total": total, "unused": unused, "used": total - unused,
         "by_type": [dict(r) for r in by_type]})


def _reset(args) -> None:
    with database.cursor(commit=True) as c:
        if args.type:
            c.execute(
                "UPDATE topic SET is_used=0, used_at=NULL WHERE account_id=? AND content_type=?",
                (args.account_id, args.type),
            )
        else:
            c.execute("UPDATE topic SET is_used=0, used_at=NULL WHERE account_id=?", (args.account_id,))
    out({"ok": True})


def _types(args) -> None:
    with database.cursor() as c:
        rows = c.execute(
            "SELECT * FROM content_type WHERE account_id=? ORDER BY sort_order, id",
            (args.account_id,),
        ).fetchall()
    out([dict(r) for r in rows])


_DEFAULT_TYPES = ["干货科普", "痛点解析", "经验分享"]


def _types_init(args) -> None:
    require_account(args.account_id)
    with database.cursor(commit=True) as c:
        count = c.execute("SELECT COUNT(*) FROM content_type WHERE account_id=?",
                          (args.account_id,)).fetchone()[0]
        if count > 0:
            rows = c.execute("SELECT * FROM content_type WHERE account_id=? ORDER BY sort_order",
                             (args.account_id,)).fetchall()
            out([dict(r) for r in rows])
        now = now_iso()
        for i, name in enumerate(_DEFAULT_TYPES):
            c.execute(
                "INSERT INTO content_type (account_id, name, prompt_template, sort_order, created_at, updated_at) "
                "VALUES (?, ?, '', ?, ?, ?)",
                (args.account_id, name, i, now, now),
            )
        rows = c.execute("SELECT * FROM content_type WHERE account_id=? ORDER BY sort_order",
                         (args.account_id,)).fetchall()
    out([dict(r) for r in rows])
