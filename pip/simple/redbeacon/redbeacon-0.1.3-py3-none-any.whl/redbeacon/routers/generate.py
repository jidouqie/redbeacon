"""generate: 取选题 → AI 生成文案/图片 → 入库（阻塞）"""
from __future__ import annotations

import json
import sys

from redbeacon.utils.logger import get_logger
from ._runtime import out, err

log = get_logger("router.generate")


def dispatch(args) -> None:
    from redbeacon.tasks.generate import run_generate

    # image_mode 未指定时透传 None，由 run_generate 读账号 image_strategy.mode
    # （面板/策略里设的"配图方式"）。不再在路由层读 strategy.default_image_mode——
    # 那是早期遗留的错字段，与 image_strategy 打架，空值时会误报错。
    def _progress(step: int, data: dict):
        print(json.dumps({"progress": step, **data}, ensure_ascii=False), file=sys.stderr)
        sys.stderr.flush()

    try:
        content_id = run_generate(
            account_id=args.account_id,
            topic_override=args.topic,
            content_type_override=args.content_type,
            image_mode=args.image_mode,
            pillar_override=args.pillar,
            progress_cb=_progress,
        )
        out({"ok": True, "content_id": content_id})
    except Exception as e:
        log.error(f"generate 失败：{e}", exc_info=True)
        err(f"生成失败：{e}")
