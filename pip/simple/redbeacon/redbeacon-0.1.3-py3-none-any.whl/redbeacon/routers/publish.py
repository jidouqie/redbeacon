"""publish: 从飞书读「通过」记录 → 浏览器自动化发布。

唯一发布数据源是飞书多维表格（审核全部在飞书完成），无本地审核路径。
"""
from __future__ import annotations

from redbeacon import config as cfg
from redbeacon.config_keys import CK_FEISHU_APP_ID, CK_FEISHU_APP_SECRET
from redbeacon import database
from redbeacon.utils.logger import get_logger
from ._runtime import out, err

log = get_logger("router.publish")


def dispatch(args) -> None:
    from redbeacon.tasks.publish import run_publish

    # 发布唯一数据源是飞书；凭证 / 表格未配齐 → 硬报错，不回落任何本地路径
    app_id     = cfg.get(CK_FEISHU_APP_ID)
    app_secret = cfg.get(CK_FEISHU_APP_SECRET)
    with database.cursor() as c:
        acc = c.execute(
            "SELECT feishu_app_token, feishu_table_id FROM account WHERE id=?",
            (args.account_id,),
        ).fetchone()
    app_token = acc["feishu_app_token"] if acc else None
    table_id  = acc["feishu_table_id"]  if acc else None
    if not all([app_id, app_secret, app_token, table_id]):
        err("发布需要先配置飞书审核表格（审核与发布数据源均在飞书）",
            next=f"redbeacon feishu setup --account-id {args.account_id}")

    # 发布前预览：列出即将发布的内容 + 全局发布配置，不发布（供 skill 做发布前确认）
    if getattr(args, "dry_run", False):
        from redbeacon.tasks.publish import preview_publish
        try:
            out(preview_publish(account_id=args.account_id))
        except Exception as e:
            log.error(f"publish 预览失败：{e}", exc_info=True)
            err(f"发布预览失败：{e}")
        return

    try:
        published = run_publish(account_id=args.account_id)
        out({"ok": True, "published": published})
    except Exception as e:
        log.error(f"publish 失败：{e}", exc_info=True)
        err(f"发布失败：{e}")
