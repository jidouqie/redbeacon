"""status: 系统总览"""
from __future__ import annotations

from pathlib import Path

from redbeacon import config as cfg
from redbeacon.config_keys import (
    CK_AI_API_KEY, CK_AI_BASE_URL, CK_AI_MODEL, CK_IMAGE_MODEL,
    CK_FEISHU_APP_ID, CK_FEISHU_APP_SECRET,
)
from redbeacon import database
from ._runtime import out, DATA_DIR, LOG_DIR


def dispatch(_args) -> None:
    import json as _json
    with database.cursor() as c:
        accounts = c.execute(
            "SELECT id, display_name, login_status, nickname FROM account ORDER BY id"
        ).fetchall()
        contents = c.execute(
            "SELECT status, COUNT(*) as cnt FROM content_queue GROUP BY status"
        ).fetchall()
        # 每账号「运营驾驶舱」摘要：定位 / 未用选题 / 待审 / 已发 / 最近发布标题
        acc_list = []
        for a in accounts:
            aid = a["id"]
            srow = c.execute(
                "SELECT data FROM strategy WHERE account_id=? ORDER BY version DESC LIMIT 1", (aid,)
            ).fetchone()
            niche = ""
            if srow:
                try:
                    niche = (_json.loads(srow["data"] or "{}").get("niche") or "").strip()
                except Exception:
                    niche = ""
            unused = c.execute(
                "SELECT COUNT(*) FROM topic WHERE account_id=? AND is_used=0", (aid,)
            ).fetchone()[0]
            cc = {r["status"]: r["cnt"] for r in c.execute(
                "SELECT status, COUNT(*) cnt FROM content_queue WHERE account_id=? GROUP BY status", (aid,)
            )}
            last_pub = c.execute(
                "SELECT title FROM content_queue WHERE account_id=? AND status='published' "
                "AND title IS NOT NULL ORDER BY published_at DESC, id DESC LIMIT 1", (aid,)
            ).fetchone()
            acc_list.append({
                **dict(a),
                "niche": niche,
                "unused_topics": unused,
                "topics_low": unused < 5,
                "pending_review": cc.get("pending_review", 0),
                "published": cc.get("published", 0),
                "failed": cc.get("failed", 0),
                "last_published_title": (last_pub["title"] if last_pub else ""),
            })
    out({
        "accounts": acc_list,
        "content_counts": {r["status"]: r["cnt"] for r in contents},
        "paths": {
            "data_dir":  DATA_DIR,
            "log_dir":   LOG_DIR,
            "db":        str(database.DB_PATH),
            "profiles":  str(Path(DATA_DIR) / "cb_profiles"),
            "images":    str(Path(DATA_DIR) / "images"),
        },
        "ai_base_url":       cfg.get(CK_AI_BASE_URL),
        "ai_api_key":        "__SET__" if cfg.get(CK_AI_API_KEY) else "",
        "ai_model":          cfg.get(CK_AI_MODEL),
        "image_model":       cfg.get(CK_IMAGE_MODEL),
        "feishu_app_id":     cfg.get(CK_FEISHU_APP_ID),
        "feishu_app_secret": "__SET__" if cfg.get(CK_FEISHU_APP_SECRET) else "",
    })
