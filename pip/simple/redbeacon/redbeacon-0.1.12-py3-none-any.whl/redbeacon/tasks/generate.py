"""
内容生成任务：从选题库取题 → AI 生成 JSON 文案 → AI 生成图片 → 写入内容队列。

调用入口：
  - APScheduler 定时触发：run_generate()
  - API 手动触发：run_generate()
"""
import json
import os
import re
import subprocess
import sys
import tempfile
import time
from datetime import datetime, timezone
from pathlib import Path

from redbeacon import database
from redbeacon import config as cfg
from redbeacon.config_keys import (
    CK_AI_API_KEY, CK_AI_BASE_URL, CK_AI_MODEL,
    CK_FEISHU_APP_ID, CK_FEISHU_APP_SECRET, CK_FEISHU_USER_ID,
    CK_DATA_DIR,
)
from redbeacon.utils.logger import get_logger

DEFAULT_PROMPT = """\
你是一个专注于{niche}领域的小红书博主。

目标受众：{target_audience}
语气风格：{tone}
开场方式：{opening_style}
行文格式：{format_style}
Emoji 用量：{emoji_usage}
正文字数：{content_length}
内容方向：{content_pillars}
差异化优势：{competitive_advantage}
目标痛点：{pain_points}
禁止词汇：{forbidden_words}
本次内容类型：{content_type}
这类内容的写作要求：{content_type_guide}

请以【{topic}】为主题，创作一篇小红书笔记。

创作要求：
1. 标题：**不超过18字**（硬上限，超了会被系统截断），有吸引力，可加数字或疑问句形式（不要用 Markdown 符号）
2. 笔记正文（content 字段，直接发布到小红书）：**严格控制在 888 字以内**（硬上限——小红书图文正文+话题合计有长度限制，超了发不出去），并遵守上方语气、格式等要求。
   - **只能用换行和空格排版**：小红书不识别 Markdown，正文里绝对不要出现 #、*、**、>、- 这类符号
   - 用空行分段、每段别太长，保持呼吸感
   - 用 emoji 点缀和分隔（数量严格按上面「Emoji 用量」的档位），可用 emoji 当小标题或要点前缀（如 ✨ 📌 1️⃣ ✅）
3. 卡片文案（card_content 字段，仅用于渲染成精美图文卡片图片，不直接发布）：
   把同一篇内容改写成带「轻量 Markdown」结构的版本，让卡片排版更有层次：
   - 用 1~2 个「## 小标题」切分；关键结论/数字/戳心句用 **加粗**；并列要点用「- 」、有先后步骤用「1. 2.」；可选「> 」放金句
   - 内容与 content 保持一致，只是换成带格式的呈现；同样可以带 emoji
4. 封面：给一个贴合主题的单个 emoji（cover_emoji），和一句不超过12字的封面副标题（cover_subtitle，点出价值或钩子，如「新手必看·亲测有效」）
5. 标签：9个相关话题标签（如 #职场干货 的格式）

禁止：正文中不要出现"关注/点赞/收藏"等引导词，不要出现广告推销语。

严格按以下 JSON 格式输出，不要有任何额外文字：
```json
{
  "title": "标题",
  "cover_emoji": "贴合主题的单个emoji",
  "cover_subtitle": "≤12字封面副标题",
  "content": "纯文字+emoji 的小红书笔记正文（发布用）",
  "card_content": "带 Markdown 排版的卡片版正文（渲染图片用）",
  "tags": ["#标签1", "#标签2", "#标签3", "#标签4", "#标签5", "#标签6", "#标签7", "#标签8", "#标签9"]
}
```"""


# 硬限长（小红书图文笔记）：标题上限、正文上限。正文+话题合计须 < 1000，正文卡 888 仍给话题留足余量。
_MAX_TITLE_LEN = 18
_MAX_BODY_LEN = 888


def _truncate_title(title: str) -> str:
    t = title.strip()
    return t if len(t) <= _MAX_TITLE_LEN else t[:_MAX_TITLE_LEN].rstrip()


def _truncate_body(body: str) -> str:
    """正文超长时优先在句末标点处收尾，避免半句；找不到就硬截。不加省略号（发布正文）。"""
    b = body.rstrip()
    if len(b) <= _MAX_BODY_LEN:
        return b
    cut = b[:_MAX_BODY_LEN]
    for i in range(len(cut) - 1, max(0, len(cut) - 120), -1):
        if cut[i] in "。！？!?…\n":
            return cut[: i + 1].rstrip()
    return cut.rstrip()


# emoji 用量三档（面板下拉）→ 给 AI 的具体指令；旧的自由文本原样透传（兼容）
_EMOJI_USAGE_MAP = {
    "较少": "很克制，几乎不用 emoji，全文最多 1~2 个，整体素净",
    "适量": "适量，每段 1~2 个，增加亲切感，不堆砌",
    "丰富": "丰富活泼，多用 emoji 做分隔、要点前缀和点缀，营造小红书氛围感",
}


def _emoji_usage_text(level: str) -> str:
    level = (level or "适量").strip()
    return _EMOJI_USAGE_MAP.get(level, level)


# ── 提示词拼装（generate 与面板「查看最终提示词」共用，保证显示=实际发送）─────────

def build_filled_prompt(strategy: dict, topic: str, content_type: str,
                        content_type_guide: str = "", pillar_override: str | None = None,
                        prompt_template: str | None = None) -> str:
    """把定位 + 选题 + 内容类型填进文案母模板 → 最终发给 AI 的完整文案提示词。"""
    prompt_template = prompt_template or DEFAULT_PROMPT
    pillars = strategy.get("content_pillars", [])
    if pillar_override:
        matched = next((p for p in pillars if p.get("name") == pillar_override), None)
        pillar_val = (f"{pillar_override}（{matched['description']}）"
                      if matched and matched.get("description") else pillar_override)
    else:
        pillar_val = "、".join(
            p["name"] + (f"（{p['description']}）" if p.get("description") else "")
            for p in pillars if p.get("name"))
    # 文案写作要求 = 全局文案提示词（账号级，改一次全类型通用）+ 该内容类型的可选微调
    global_guide = (strategy.get("copy_guide") or "").strip()
    per_type = (content_type_guide or "").strip()
    merged_guide = "\n".join(g for g in (global_guide, per_type) if g) \
        or "紧扣这类内容的角度，自然贴合账号定位即可"
    return (
        prompt_template
        .replace("{niche}",                 strategy.get("niche", "通用"))
        .replace("{target_audience}",       strategy.get("target_audience", "普通用户"))
        .replace("{content_type}",          content_type)
        .replace("{content_type_guide}",    merged_guide)
        .replace("{topic}",                 topic)
        .replace("{tone}",                  strategy.get("tone", "亲切自然，专业但不刻板，像朋友分享而非说教"))
        .replace("{competitive_advantage}", strategy.get("competitive_advantage", ""))
        .replace("{opening_style}",         strategy.get("opening_style", "提问式或数字列举，前两行必须抓住读者注意力"))
        .replace("{format_style}",          strategy.get("format_style", "分段清晰，多用短句，每段2-3行，重点内容单独成行"))
        .replace("{emoji_usage}",           _emoji_usage_text(strategy.get("emoji_usage", "适量")))
        .replace("{content_length}",        strategy.get("content_length", "300-500字"))
        .replace("{pain_points}",           " / ".join(strategy.get("pain_points", [])))
        .replace("{forbidden_words}",       " ".join(strategy.get("forbidden_words", [])))
        .replace("{content_pillars}",       pillar_val)
    )


# 参考图（图生图）默认指令——可被账号级 strategy.ref_instruction 覆盖（面板里用户可改）。
DEFAULT_REF_INSTRUCTION = (
    "【重要】所给的是一张参考图。若参考图里有人物：封面里的人必须是参考图中的"
    "同一个人、同一张脸，严格保持其五官、发型、性别、年龄、气质完全一致，"
    "绝对不要替换成另一个人；让这个人作为封面主体自然出现在画面中。"
    "若参考图是风格图（无人物）：贴合其视觉风格、配色与构图。"
)


def build_cover_prompt(strategy: dict, img_cfg: dict, title: str) -> str:
    """把视觉风格 + 标题填成最终发给图片模型的封面提示词（大字报）。

    有参考图时自动补一句图生图指令（账号级 ref_instruction，用户可改）；除非用户已在
    封面提示词里自己提了「参考图」就不重复补。
    """
    niche = strategy.get("niche", "")
    pt = (img_cfg.get("prompt_template") or "").strip()

    refs = img_cfg.get("reference_images") or []
    if isinstance(refs, str):
        try:
            refs = json.loads(refs)
        except Exception:
            refs = []
    has_ref = bool([p for p in refs if p])

    if any(ph in pt for ph in ("{标题}", "{title}", "{niche}")):
        base = pt.replace("{标题}", title).replace("{title}", title).replace("{niche}", niche)
    elif pt:
        base = (f"小红书竖版封面图，3:4 比例。整体视觉风格：{pt}。"
                f"在画面醒目位置用清晰、有冲击力的大字写出标题文案：「{title}」，"
                "文字排版舒展、主次分明，高质量、精美。")
    else:
        base = (f"小红书竖版大字报封面，3:4 比例，{niche}领域。"
                f"画面上方用醒目大字清晰写出标题文案：「{title}」，"
                "背景简洁有高级感、色彩协调，高质量、精美。")

    if has_ref and "参考图" not in pt:
        ref_instr = (strategy.get("ref_instruction") or DEFAULT_REF_INSTRUCTION).strip()
        if ref_instr:
            base = ref_instr + "\n" + base
    return base


def _pop_next_topic(account_id: int, content_type: str | None = None) -> dict | None:
    from datetime import datetime, timezone
    now = datetime.now(timezone.utc).isoformat()
    c = database.conn()
    try:
        c.execute("BEGIN IMMEDIATE")
        if content_type:
            row = c.execute(
                "SELECT * FROM topic WHERE account_id=? AND content_type=? AND is_used=0 ORDER BY id LIMIT 1",
                (account_id, content_type),
            ).fetchone()
        else:
            row = c.execute(
                "SELECT * FROM topic WHERE account_id=? AND is_used=0 ORDER BY id LIMIT 1",
                (account_id,),
            ).fetchone()
        if row is None:
            c.execute("ROLLBACK")
            return None
        c.execute("UPDATE topic SET is_used=1, used_at=? WHERE id=?", (now, row["id"]))
        c.commit()
        return dict(row)
    except Exception:
        c.execute("ROLLBACK")
        return None
    finally:
        c.close()

logger = get_logger("tasks.generate")

# ── 渲染器路径 ─────────────────────────────────────────────────────────────────
# frozen（生产）：使用同目录的 RedBeaconRenderer 二进制
# 开发：使用 backend/render_xhs_v2.py（通过系统 Python 调用）
if os.environ.get("REDBEACON_RENDERER"):
    _RENDERER = Path(os.environ["REDBEACON_RENDERER"])
elif getattr(sys, "frozen", False):
    _RENDERER = Path(sys.executable).parent / "RedBeaconRenderer"
else:
    _RENDERER = Path(__file__).parent.parent / "render_xhs_v2.py"

_THEME_MAP = {
    "default":           "elegant",
    "neo-brutalism":     "dark",
    "botanical":         "mint",
    "professional":      "ocean",
    "retro":             "sunset",
    "terminal":          "dark",
    "sketch":            "purple",
    "playful-geometric": "xiaohongshu",
}


def _chromium_ready() -> bool | None:
    """图文卡片渲染依赖 playwright 的 chromium 内核。

    返回：
      True  — 内核就位，可渲染
      False — playwright 可导入但内核没装（首装常见，应提示 `redbeacon setup`）
      None  — 判定不了（如 frozen CLI 未打包 playwright），交给实际渲染兜底，别误拦
    """
    try:
        from playwright.sync_api import sync_playwright
    except Exception:
        return None
    try:
        with sync_playwright() as p:
            exe = p.chromium.executable_path
        return bool(exe) and os.path.exists(exe)
    except Exception:
        return False


# ── 主入口 ─────────────────────────────────────────────────────────────────────

def run_generate(
    account_id: int = 1,
    topic_override: str | None = None,
    content_type_override: str | None = None,
    image_mode: str | None = None,   # None = 从图片策略读取; 或手动指定 "cards"|"ai"|"both"
    pillar_override: str | None = None,  # 指定内容方向名称，None = AI 自行覆盖所有方向
    progress_cb=None,  # callable(step: int, data: dict)，每步完成时回调
) -> int:
    """
    为指定账号执行一次内容生成。
    image_mode 为 None 时从 image_strategy 表读取账号配置。
    """
    def _progress(step: int, data: dict | None = None):
        if progress_cb:
            try:
                progress_cb(step, data or {})
            except Exception:
                pass

    _progress(0)  # 准备选题

    # ── 读取账号策略
    with database.cursor() as c:
        strategy_row = c.execute(
            "SELECT data FROM strategy WHERE account_id=? ORDER BY version DESC LIMIT 1",
            (account_id,),
        ).fetchone()
        img_strategy_row = c.execute(
            "SELECT * FROM image_strategy WHERE account_id=?", (account_id,)
        ).fetchone()

    strategy: dict = {}
    if strategy_row:
        try:
            strategy = json.loads(strategy_row["data"])
        except Exception:
            pass

    # 图片策略：优先使用参数，否则读账号配置
    img_cfg: dict = {}
    if img_strategy_row:
        img_cfg = {
            "mode": img_strategy_row["mode"],
            "prompt_template": img_strategy_row["prompt_template"],
            "card_theme": img_strategy_row["card_theme"],
            "reference_images": json.loads(img_strategy_row["reference_images"] or "[]"),
            "ai_model": img_strategy_row["ai_model"],
        }
    else:
        img_cfg = {"mode": "cards", "card_theme": "default",
                   "prompt_template": "", "reference_images": [], "ai_model": None}

    # 读取图片模板：specific=用激活模板，random=从所有模板中随机取一个
    import random as _random_mod
    template_mode = img_cfg.get("template_mode", "specific") if img_cfg else "specific"
    active_template_items: list[dict] | None = None
    with database.cursor() as c3:
        if template_mode == "random":
            all_tpls = c3.execute(
                "SELECT * FROM image_template WHERE account_id=?", (account_id,)
            ).fetchall()
            if all_tpls:
                chosen = _random_mod.choice(all_tpls)
                active_template_items = json.loads(chosen["items"] or "[]")
                logger.info(f"[generate] 随机模板：{chosen['name']}")
        else:
            active_tpl_row = c3.execute(
                "SELECT * FROM image_template WHERE account_id=? AND is_active=1 LIMIT 1",
                (account_id,),
            ).fetchone()
            if active_tpl_row:
                active_template_items = json.loads(active_tpl_row["items"] or "[]")

    # 外部 image_mode 参数优先（来自生成面板手动选择）
    resolved_mode = image_mode or img_cfg["mode"]

    # 纯卡片模式没有 AI 图兜底：内核缺失会让渲染必然失败。提前给人话提示，
    # 别等写完文案、烧完 token 才崩出一句英文报错。
    if resolved_mode == "cards" and _chromium_ready() is False:
        raise RuntimeError(
            "浏览器内核未安装，无法渲染图文卡片。请先运行 `redbeacon setup` "
            "下载内核（约 150MB，一次性即可），或改用「AI 生图」配图方式重试。"
        )

    # ── 选取内容类型
    if content_type_override:
        with database.cursor() as c2:
            ct_row = c2.execute(
                "SELECT * FROM content_type WHERE account_id=? AND name=? AND is_active=1",
                (account_id, content_type_override),
            ).fetchone()
        content_type_row = dict(ct_row) if ct_row else None
    else:
        content_type_row = _pick_content_type(account_id)

    if content_type_row is None:
        # 没有配置内容类型时用空模板（仍可生成，提示词用默认）
        content_type_row = {
            "name": content_type_override or "通用",
            "prompt_template": DEFAULT_PROMPT,
        }

    # ── 选题
    if topic_override:
        topic_text = topic_override.strip()
        ct_name = content_type_row["name"]
        logger.info(f"[generate] 手动指定选题：{topic_text}")
    else:
        topic_row = _pop_next_topic(account_id, content_type=content_type_row["name"])
        if topic_row is None:
            topic_row = _pop_next_topic(account_id)   # 跨类型兜底
        if topic_row is None:
            logger.warning("[generate] 选题库已耗尽，请在「策略」页面补充选题")
            _notify_topics_low(account_id, remaining=0)
            raise RuntimeError("选题库已耗尽，请在「选题库」页面补充选题后重试")
        topic_text = topic_row["content"]
        ct_name    = topic_row["content_type"]
        logger.info(f"[generate] 从选题库取题：{topic_text}（类型：{ct_name}）")
        # 检查剩余未用选题数，不足 5 条时飞书提醒
        _check_topics_and_notify(account_id)

    # ── 提示词模板恒为程序内置的 DEFAULT_PROMPT（含 JSON 输出契约、占位符、格式骨架，用户不可见）
    #    用户在「文案风格」框里写的是一句人话写作指引，作为 {content_type_guide} 注入，不替换整模板
    content_type_guide = (content_type_row.get("prompt_template") or "").strip() \
        or "紧扣这类内容的角度，自然贴合账号定位即可"

    # 查重素材：本账号最近生成过的标题，喂给 AI 以避开同质化
    with database.cursor() as c_recent:
        recent_titles = [
            r["title"] for r in c_recent.execute(
                "SELECT title FROM content_queue WHERE account_id=? AND title IS NOT NULL "
                "ORDER BY id DESC LIMIT 12",
                (account_id,),
            ).fetchall() if r["title"]
        ]

    _progress(1)  # AI 生成文案

    # ── AI 生成文案（JSON）
    try:
        result = _ai_generate(
            strategy=strategy,
            topic=topic_text,
            content_type=ct_name,
            # 文案母模板：账号若在面板里改过就用账号的，否则用内置默认（用户可改、不藏）
            prompt_template=(strategy.get("copy_template") or DEFAULT_PROMPT),
            content_type_guide=content_type_guide,
            account_id=account_id,
            pillar_override=pillar_override,
            recent_titles=recent_titles,
        )
    except Exception as e:
        logger.error(f"[generate] AI 文案生成失败：{e}")
        raise RuntimeError(f"AI 文案生成失败：{e}")

    title       = result.get("title", "").strip()
    content_body = result.get("content", "").strip()
    # 卡片文案：带 Markdown 排版的版本，仅用于渲染图文卡片；缺失则回退用正文
    card_body   = (result.get("card_content") or "").strip() or content_body
    tags        = result.get("tags", [])
    # 封面素材：贴题 emoji + 副标题（钩子）；缺失时给兜底，避免封面寒酸
    cover_emoji    = (result.get("cover_emoji") or "").strip() or "📌"
    cover_subtitle = (result.get("cover_subtitle") or "").strip() or strategy.get("niche", "")

    if not title or not content_body:
        logger.error("[generate] AI 返回的 title/content 为空")
        raise RuntimeError("AI 返回内容为空，请检查 AI 模型配置或提示词模板")

    # ── 硬限长（兜底，不靠模型自觉）：标题 ≤18 字，正文 ≤888 字。
    #    小红书图文正文+话题合计有长度上限，超了发布时才报错且白传一遍图——在源头卡死。
    #    card_body 不限（卡片是图片，不受小红书文本限制）。
    if len(title) > _MAX_TITLE_LEN:
        logger.info(f"[generate] 标题超 {_MAX_TITLE_LEN} 字（{len(title)}），截断")
        title = _truncate_title(title)
    if len(content_body) > _MAX_BODY_LEN:
        logger.info(f"[generate] 正文超 {_MAX_BODY_LEN} 字（{len(content_body)}），按句末截断")
        content_body = _truncate_body(content_body)

    # ── 确定图片保存目录
    data_dir = os.environ.get("REDBEACON_DATA_DIR") or cfg.get(CK_DATA_DIR)
    img_save_dir = str(Path(data_dir).resolve() / "images")

    _progress(2)  # 生成配图

    # ── 图片生成（根据 image_mode）
    visual_theme = strategy.get("visual_theme", "default")
    ai_images: list[str] = []
    card_paths: list[str] = []

    want_ai    = resolved_mode in ("ai", "both")
    want_cards = resolved_mode in ("cards", "both") or not want_ai

    # 封面提示词：默认产出「小红书大字报封面」——标题大字直接画进图。
    #   account 存的 prompt_template 有两种写法：
    #     1) 结构化封面指令（含 {标题}/{title}/{niche} 占位符）→ 直接套，用户/定位完全掌控文字/风格/版式/比例；
    #     2) 纯风格描述（无占位符）→ 程序补「大字报骨架 + 标题大字 + 竖版3:4」。
    #   宽高比按用户要求全部在提示词里控制（不依赖接口 size 参数）。
    effective_img_prompt = build_cover_prompt(strategy, img_cfg, title) if want_ai else ""

    # 确定图片生成使用的模型（策略 ai_model 优先，否则全局 image_model）
    img_model = img_cfg.get("ai_model") or cfg.get("image_model")

    # 图生图参考图：优先用图片模板(image_template)，否则用账号视觉档案里存的参考图
    #   (image_strategy.reference_images)。有参考图 → 图生图（按参考图人物/风格生成）；无 → 文生图。
    resolved_items = None
    reference_items = None
    if want_ai and img_model:
        try:
            from redbeacon.services.image_gen import generate as gen_image
            if active_template_items:
                # 对模板 items 的 prompt 做变量替换（{标题}/{title}/{niche} 此时已知）
                resolved_items = []
                for item in active_template_items:
                    item_copy = dict(item)
                    if item_copy.get("prompt"):
                        item_copy["prompt"] = (
                            item_copy["prompt"]
                            .replace("{标题}", title)
                            .replace("{title}", title)
                            .replace("{niche}", strategy.get("niche", ""))
                        )
                    resolved_items.append(item_copy)
                reference_items = resolved_items
            else:
                ref_paths = img_cfg.get("reference_images") or []
                if isinstance(ref_paths, str):
                    try:
                        ref_paths = json.loads(ref_paths)
                    except Exception:
                        ref_paths = []
                ref_paths = [p for p in ref_paths if p]
                if ref_paths:
                    # 参考图作为图生图素材；具体"参照这个人/这种风格"的指令已在 effective_img_prompt 里
                    reference_items = [{"image_path": p, "prompt": ""} for p in ref_paths]
            ai_images = gen_image(
                effective_img_prompt,
                img_save_dir,
                model=img_model,
                reference_items=reference_items,
            )
        except Exception as e:
            logger.warning(f"[generate] AI 图片生成失败（跳过）：{e}")

    # 计算实际写入 DB 的 image_prompt：主提示词 + 模板 item 提示词（与 image_gen._build_messages 一致）
    actual_img_prompt = effective_img_prompt
    if want_ai and resolved_items:
        item_prompts = [it["prompt"] for it in resolved_items if it.get("prompt")]
        if item_prompts:
            parts = ([actual_img_prompt] if actual_img_prompt else []) + item_prompts
            actual_img_prompt = "\n".join(parts)

    card_theme = img_cfg.get("card_theme", "default") if want_cards else "default"
    if want_cards and _RENDERER.exists():
        try:
            # 用带 Markdown 排版的卡片文案渲染（笔记正文 content_body 保持纯文字另存）
            # 把标签拼到卡片文案末尾（先去掉文案里可能已有的尾部标签，避免重复），让卡片底部显示标签 chip
            import re as _re_tags
            card_md = _re_tags.sub(r'\s*(#[^\s#]+\s*)+$', '', card_body).rstrip()
            if tags:
                card_md += "\n\n" + " ".join(t if t.startswith("#") else f"#{t}" for t in tags)
            card_paths = _render_cards(title, card_md, visual_theme, card_theme,
                                       save_dir=img_save_dir, skip_cover=want_ai and bool(ai_images),
                                       cover_emoji=cover_emoji, cover_subtitle=cover_subtitle)
        except Exception as e:
            logger.warning(f"[generate] 卡片渲染失败（跳过）：{e}")

    # AI 封面在前，图文卡片在后
    all_images: list[str] = [*ai_images, *card_paths]

    if not all_images:
        if resolved_mode == "cards":
            # 纯卡片模式渲染失败：渲染器可能未就绪，中止而非产生无图内容
            logger.error(
                "[generate] 卡片渲染失败，已中止入库。请检查渲染器路径是否正确。"
            )
            raise RuntimeError("图文卡片渲染失败，请重试或切换为「AI生图」模式")
        # ai / both 模式：图片失败降级处理，文案仍入库，图片为空，审核时手动补图
        logger.warning(
            f"[generate] 图片生成失败（mode={resolved_mode}），降级入库（图片为空），请在审核时手动补图。"
        )

    _progress(3)  # 加入审核队列

    # ── 写入内容队列
    content_id = _save_to_queue(
        account_id=account_id,
        topic=topic_text,
        content_type=ct_name,
        pillar_name=pillar_override or ct_name,
        title=title,
        body=content_body,
        tags=tags,
        image_prompt=actual_img_prompt,
        image_paths=all_images,
        visual_theme=visual_theme,
    )
    logger.info(f"[generate] 入队成功 id={content_id}  title={title}")
    _progress(4, {"content_id": content_id})  # 完成

    # ── 配图缺失告警：AI 生图模式重试后仍无图，content 已入库，提醒用户去飞书补图
    img_warning = None
    if want_ai and not ai_images:
        img_warning = "本篇 AI 配图生成失败（已自动重试），暂无配图，请在飞书补图后再发布"
        logger.warning(f"[generate] {img_warning}（content_id={content_id}）")

    # ── 推送飞书（同步，CLI 进程退出前完成）
    try:
        _push_to_feishu(content_id, account_id, extra_note=img_warning)
    except Exception as e:
        logger.warning(f"[generate] 飞书推送失败（不影响生成结果）：{e}")

    return content_id


# ── AI 文案生成 ────────────────────────────────────────────────────────────────

def _ai_generate(
    strategy: dict,
    topic: str,
    content_type: str,
    prompt_template: str,
    content_type_guide: str = "",
    account_id: int = 1,
    pillar_override: str | None = None,
    recent_titles: list[str] | None = None,
) -> dict:
    """
    调用 AI API，返回解析后的 dict：{title, content, tags}。
    """
    import httpx
    from openai import OpenAI

    api_key  = cfg.get(CK_AI_API_KEY)
    base_url = cfg.get(CK_AI_BASE_URL)
    model    = cfg.get(CK_AI_MODEL)

    if not api_key:
        raise ValueError("AI API Key 未配置，请在「设置」中填写")

    client = OpenAI(
        api_key=api_key,
        base_url=base_url,
        http_client=httpx.Client(trust_env=False, timeout=60),
    )

    # 填充提示词模板占位符（抽到 build_filled_prompt，与面板「查看最终提示词」共用）
    filled_prompt = build_filled_prompt(
        strategy, topic, content_type, content_type_guide, pillar_override, prompt_template)

    logger.info(f"[generate] AI model={model}，topic={topic}")
    messages = [
        {
            "role": "system",
            "content": (
                "你是小红书文案专家。输出格式：严格合法的JSON对象。"
                "JSON字符串值内部禁止使用英文双引号（\"），"
                "如需引用，使用「」或""（弯引号）替代。"
            ),
        },
        {"role": "user", "content": filled_prompt},
    ]
    # 内容查重：把本账号最近已写的标题塞进上下文，要求换应用域/角度，别换汤不换药（对齐规则04）
    if recent_titles:
        avoid = "\n".join(f"- {t}" for t in recent_titles[:12] if t)
        if avoid:
            messages.append({
                "role": "user",
                "content": (
                    "【避免同质化】本账号最近已经发过下面这些标题，"
                    "请在切入的应用域 / 角度 / 问题类型上明显区别于它们，"
                    "不要重复同一个观点或论证，写出新东西：\n" + avoid
                ),
            })
    # 重试循环：兜住模型间歇返回空 content（NoneType）、非法 JSON、瞬时网络抖动。
    # 任一原因失败都退避重试；连试都不成才整条失败（不静默存坏数据）。
    max_attempts = 3
    last_err: Exception | None = None
    for attempt in range(1, max_attempts + 1):
        try:
            response = client.chat.completions.create(
                model=model,
                messages=messages,
                temperature=0.85,
                max_tokens=4000,   # 双字段(content+card_content)+9标签，1500 会截断导致 JSON 不闭合
            )
            raw = (response.choices[0].message.content or "").strip()
            if not raw:
                raise ValueError("AI 返回空内容（content 为 null 或空）")
            return _parse_json_output(raw)
        except Exception as e:
            last_err = e
            logger.warning(f"[generate] AI 文案第 {attempt}/{max_attempts} 次失败：{e}")
            if attempt < max_attempts:
                time.sleep(0.8 * attempt)
    raise RuntimeError(f"AI 连试 {max_attempts} 次仍失败：{last_err}")


def _fix_embedded_quotes(text: str) -> str:
    """Escape unescaped ASCII double quotes inside JSON string values."""
    result = []
    in_string = False
    i = 0
    while i < len(text):
        ch = text[i]
        if ch == '\\' and in_string:
            result.append(ch)
            i += 1
            if i < len(text):
                result.append(text[i])
            i += 1
            continue
        if ch == '"':
            if not in_string:
                in_string = True
                result.append(ch)
            else:
                # Look ahead to decide: structural closing quote or embedded quote
                rest = text[i + 1:].lstrip(' \t')
                next_ch = rest[0] if rest else ''
                if next_ch in (',', '}', ']', ':'):
                    in_string = False
                    result.append(ch)
                else:
                    result.append('\\"')
        else:
            result.append(ch)
        i += 1
    return ''.join(result)


def _parse_json_output(raw: str) -> dict:
    """
    从 AI 输出中提取 JSON。
    支持：纯 JSON、```json ... ``` 代码块、或文字包裹中的 JSON。
    """
    def _try(text: str) -> dict | None:
        # strict=False：容忍 AI 在字符串值里塞裸换行/制表符等控制字符（常见且合法语义）
        try:
            return json.loads(text, strict=False)
        except Exception:
            pass
        try:
            return json.loads(_fix_embedded_quotes(text), strict=False)
        except Exception:
            pass
        return None

    # 尝试直接解析
    r = _try(raw)
    if r is not None:
        return r

    # 提取 ```json ... ``` 代码块（贪婪匹配确保捕获完整 JSON）
    m = re.search(r"```(?:json)?\s*(\{[\s\S]*\})\s*```", raw)
    if m:
        r = _try(m.group(1))
        if r is not None:
            return r

    # 最宽松：找第一个 { 到最后一个 }
    start = raw.find("{")
    end   = raw.rfind("}")
    if start != -1 and end != -1 and end > start:
        r = _try(raw[start:end + 1])
        if r is not None:
            return r

    # 解析彻底失败：抛错，而不是返回降级垃圾。
    # 旧逻辑会把原始 JSON 当正文、标题存成「无标题」静默入库（id=2 损坏的根因）；
    # 抛出后由 _ai_generate 的重试循环接住重试，最终仍失败则整条生成失败、不存坏数据。
    raise ValueError(f"AI 输出无法解析为 JSON（前200字：{raw[:200]}）")


# ── 图文卡片渲染 ───────────────────────────────────────────────────────────────

def _render_cards(title: str, body: str, visual_theme: str, card_theme: str = "default", save_dir: str | None = None, skip_cover: bool = False, cover_emoji: str = "", cover_subtitle: str = "") -> list[str]:
    import shutil
    # card_theme 直接就是主题名（与渲染器 VALID_THEMES 对齐）；
    # random / 未知值都交给渲染器内部处理（random 会一次性定一个主题）
    style = card_theme or "default"

    # 封面 frontmatter：emoji + subtitle（YAML 值含特殊字符时加引号最稳）
    fm = [f"title: {title}"]
    if cover_emoji:
        fm.append(f'emoji: "{cover_emoji}"')
    if cover_subtitle:
        fm.append(f'subtitle: "{cover_subtitle}"')
    frontmatter = "\n".join(fm)

    with tempfile.NamedTemporaryFile(
        mode="w", suffix=".md", delete=False, encoding="utf-8"
    ) as f:
        md_path = f.name
        f.write(f"---\n{frontmatter}\n---\n\n{body}")

    tmp_dir = Path(tempfile.mkdtemp(prefix="redbeacon_render_"))
    try:
        # frozen: _RENDERER 是独立二进制，直接执行；开发: 用 sys.executable 运行 .py
        if getattr(sys, "frozen", False) or not str(_RENDERER).endswith(".py"):
            cmd = [str(_RENDERER), md_path, "--output-dir", str(tmp_dir), "--style", style]
        else:
            cmd = [sys.executable, str(_RENDERER), md_path, "--output-dir", str(tmp_dir), "--style", style]
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=120)
        if result.returncode != 0:
            raise RuntimeError(f"渲染器退出码 {result.returncode}: {result.stderr[-300:]}")

        all_pngs = sorted(tmp_dir.glob("*.png"), key=lambda p: (p.name != "cover.png", p.name))
        tmp_images = [p for p in all_pngs if not (skip_cover and p.name == "cover.png")]

        # 移动到持久化目录，避免重启后 /tmp 被清空
        if save_dir:
            out_dir = Path(save_dir) / f"cards_{int(time.time())}"
            out_dir.mkdir(parents=True, exist_ok=True)
            final = []
            for p in tmp_images:
                dest = out_dir / p.name
                shutil.move(str(p), str(dest))
                final.append(str(dest))
            return final

        return [str(p) for p in tmp_images]
    finally:
        # 清理临时文件和目录，防止磁盘泄漏
        try:
            Path(md_path).unlink(missing_ok=True)
        except Exception:
            pass
        try:
            shutil.rmtree(tmp_dir, ignore_errors=True)
        except Exception:
            pass


# ── 数据库写入 ─────────────────────────────────────────────────────────────────

def _save_to_queue(
    account_id: int,
    topic: str,
    content_type: str,
    title: str,
    body: str,
    tags: list,
    image_prompt: str,
    image_paths: list[str],
    visual_theme: str,
    pillar_name: str | None = None,
) -> int:
    now = datetime.now(timezone.utc).isoformat()
    with database.cursor(commit=True) as c:
        c.execute(
            """INSERT INTO content_queue
               (account_id, topic, content_type, pillar_name, title, body,
                tags, image_prompt, images, visual_theme, status, created_at, updated_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending_review', ?, ?)""",
            (
                account_id, topic, content_type, pillar_name or content_type,
                title, body,
                json.dumps(tags, ensure_ascii=False),
                image_prompt,
                json.dumps(image_paths, ensure_ascii=False),
                visual_theme, now, now,
            ),
        )
        content_id = c.execute("SELECT last_insert_rowid()").fetchone()[0]
    return content_id


# ── 选题库低余量飞书提醒 ────────────────────────────────────────────────────────

def _notify_topics_low(account_id: int, remaining: int) -> None:
    app_id     = cfg.get(CK_FEISHU_APP_ID)
    app_secret = cfg.get(CK_FEISHU_APP_SECRET)
    if not all([app_id, app_secret]):
        return
    with database.cursor() as c0:
        acc = c0.execute(
            "SELECT feishu_user_id, display_name, nickname FROM account WHERE id=?",
            (account_id,),
        ).fetchone()
    if not acc:
        return
    user_id = acc["feishu_user_id"] or cfg.get(CK_FEISHU_USER_ID)
    if not user_id:
        return
    acc_name = acc["display_name"] or acc["nickname"] or f"账号 {account_id}"
    if remaining == 0:
        msg = f"[{acc_name}] 选题库已耗尽，无法继续生成内容，请尽快补充选题。"
    else:
        msg = f"[{acc_name}] 选题库仅剩 {remaining} 条，建议尽快补充，避免内容断更。"
    from redbeacon.services.feishu_api import FeishuAPI
    feishu = FeishuAPI(app_id, app_secret, "", "")
    try:
        feishu.send_text_message(user_id, msg)
        logger.info(f"[generate] 飞书选题低余量提醒已发送（账号 {account_id}，剩余 {remaining}）")
    except Exception as e:
        logger.warning(f"[generate] 飞书选题提醒发送失败：{e}")


def _check_topics_and_notify(account_id: int) -> None:
    with database.cursor() as c:
        row = c.execute(
            "SELECT COUNT(*) AS cnt FROM topic WHERE account_id=? AND is_used=0",
            (account_id,),
        ).fetchone()
    remaining = row["cnt"] if row else 0
    if remaining < 5:
        import threading
        threading.Thread(
            target=_notify_topics_low,
            args=(account_id, remaining),
            daemon=True,
        ).start()


# ── 飞书推送 ───────────────────────────────────────────────────────────────────

# 飞书多维表格模板（固定，所有用户共用同一张表结构）
_FEISHU_APP_TOKEN = "Wf0WbW4R0a9pcJs4bm6cGEuKn7e"
_FEISHU_TABLE_ID  = "tblGEBTJoqK6snYP"


def _push_to_feishu(content_id: int, account_id: int = 1, extra_note: str | None = None) -> None:
    app_id     = cfg.get(CK_FEISHU_APP_ID)
    app_secret = cfg.get(CK_FEISHU_APP_SECRET)

    if not all([app_id, app_secret]):
        logger.warning("[generate] 飞书推送跳过：app_id 或 app_secret 未配置")
        return

    # 从 account 表读取该账号的飞书表格配置（已从 settings 迁移到 account）
    with database.cursor() as c0:
        acc = c0.execute(
            "SELECT feishu_app_token, feishu_table_id, feishu_user_id FROM account WHERE id=?",
            (account_id,),
        ).fetchone()
    app_token = (acc["feishu_app_token"] if acc else None) or _FEISHU_APP_TOKEN
    table_id  = (acc["feishu_table_id"]  if acc else None) or _FEISHU_TABLE_ID
    user_id   = (acc["feishu_user_id"]   if acc else None) or cfg.get(CK_FEISHU_USER_ID)

    from redbeacon.services.feishu_api import FeishuAPI

    with database.cursor() as c:
        row = c.execute(
            "SELECT title, body, tags, images FROM content_queue WHERE id=?",
            (content_id,),
        ).fetchone()
    if row is None:
        return

    feishu = FeishuAPI(app_id, app_secret, app_token, table_id)
    from redbeacon.services.feishu_api import (
        FIELD_TITLE, FIELD_BODY, FIELD_TAGS, FIELD_IMAGES,
    )
    try:
        images = json.loads(row["images"] or "[]")
        image_tokens = []
        for img_path in images:
            try:
                token = feishu.upload_image(img_path)
                image_tokens.append({"file_token": token})
            except Exception as e:
                logger.warning(f"[generate] 飞书图片上传失败 {img_path}：{e}")

        # 标签列表 → "、"分隔的字符串
        try:
            tags_list = json.loads(row["tags"] or "[]")
        except Exception:
            tags_list = []
        tags_str = "、".join(t.lstrip("#") for t in tags_list if t)

        fields = {
            FIELD_TITLE:  row["title"] or "",
            FIELD_BODY:   row["body"] or "",
        }
        if tags_str:
            fields[FIELD_TAGS] = tags_str
        if image_tokens:
            fields[FIELD_IMAGES] = image_tokens

        record_id = feishu.add_record(fields)
        with database.cursor(commit=True) as c2:
            c2.execute("UPDATE content_queue SET feishu_record_id=? WHERE id=?", (record_id, content_id))
        logger.info(f"[generate] 飞书推送成功：content_id={content_id} record_id={record_id}")

        if user_id:
            try:
                table_url = f"https://feishu.cn/base/{app_token}"
                note = f"\n\n⚠️ {extra_note}" if extra_note else ""
                feishu.send_text_message(
                    user_id,
                    f"📝 新文案已生成，等待审核\n《{row['title']}》{note}\n\n点击审核：{table_url}"
                )
            except Exception as e:
                logger.warning(f"[generate] 飞书消息通知失败：{e}")
    except Exception as e:
        logger.error(f"[generate] 飞书推送失败：{e}")


# ── 工具函数 ───────────────────────────────────────────────────────────────────

def _pick_content_type(account_id: int) -> dict | None:
    """轮询选取激活的内容类型：选最近生成次数最少的那个。"""
    with database.cursor() as c:
        types = c.execute(
            "SELECT * FROM content_type WHERE account_id=? AND is_active=1 ORDER BY sort_order, id",
            (account_id,),
        ).fetchall()
        if not types:
            return None
        counts = {}
        for t in types:
            row = c.execute(
                "SELECT COUNT(*) as n FROM content_queue WHERE account_id=? AND content_type=?",
                (account_id, t["name"]),
            ).fetchone()
            counts[t["name"]] = row["n"] if row else 0

    best = min(types, key=lambda t: counts.get(t["name"], 0))
    return dict(best)
